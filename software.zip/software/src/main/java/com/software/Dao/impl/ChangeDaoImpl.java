package com.software.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.software.Dao.ChangeDao;
import com.software.Pojo.Notice;

public class ChangeDaoImpl implements ChangeDao{
	
//用户对话题的操作
	//话题发表
	public void postTalk(String title, String context, int select, int id, Connection con) throws SQLException {
		String sql = "insert talk(title, user_id, content) VALUES(?, ?, ?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, title);
		pstmt.setInt(2, id);
		pstmt.setString(3, context);
		pstmt.execute();
		
		sql = "insert relationtalk(talk_id, topic_id) VALUES((select id from talk where title=? and user_id=? and content=?), ?)";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, title);
		pstmt.setInt(2, id);
		pstmt.setString(3, context);
		pstmt.setInt(4, select);
		pstmt.execute();
	}
	//添加话题的一级回复
	public void addLevel1(Connection con, int id, int me, String content) throws SQLException {
		String sql="INSERT level1(talk_id, user_id, content) VALUES(?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, me);
		pstmt.setString(3, content);
		pstmt.execute();
		
		sql = "UPDATE talk set reply=(select count(*) from level1 where level1.talk_id=?) where id=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, id);
		pstmt.execute();
	}
	//添加话题的二级回复
	public void addLevel2(Connection con, int id, int me, String content) throws SQLException {
		String sql="INSERT level2(level_id, user_id, content) VALUES(?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, me);
		pstmt.setString(3, content);
		pstmt.execute();
		
		sql = "UPDATE level1 set reply=(select count(*) from level2 where level2.level_id=?) where id=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, id);
		pstmt.execute();
	}
	//添加话题的三级回复
	public void addLevel3(Connection con, int id, int me, String you, String content) throws SQLException {
		String sql="INSERT level3(level_id, user_id, to_id, content) VALUES(?,?,(select id from person where nickname=?),?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, me);
		pstmt.setString(3, you);
		pstmt.setString(4, content);
		pstmt.execute();
		
		sql = "UPDATE level2 set reply=(select count(*) from level3 where level3.level_id=?) where id=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, id);
		pstmt.execute();
	}

//用户对资源的操作	
	//用户删除自己已通过资源
	public void delePassMywork(Connection con, int id) throws SQLException {
		String sql="DELETE from software where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
	}
	//用户删除自己未通过资源
	public void deleNotPassMywork(Connection con, int id) throws SQLException {
		String sql="DELETE from delework where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
	}
	//用户删除自己待审核资源
	public void deleTemMywork(Connection con, int id) throws SQLException {
		String sql="DELETE from temwork where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
	}
	//用户删除自己待更新资源
	public void deleUpdateMywork(Connection con, int id) throws SQLException {
		String sql="DELETE from updatework where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
	}
	//删除用户下载记录
	public void deleDownRecord(int recordId, Connection con) throws SQLException {
		String sql = "DELETE from download where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, recordId);
		pstmt.execute();
	}
	//删除用户收藏记录
	public void deleLoveRecord(int recordId, Connection con) throws SQLException {
		String sql = "DELETE from collection where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, recordId);
		pstmt.execute();
	}
	//添加资源二级回复
	public void addSubComment(int commentId, int userId, String toUser, String content, Connection con) throws SQLException {
		String sql = "INSERT into subcomment(comment_id, user_id, to_id, content) VALUES(?,?,(SELECT id from person where nickname=?), ?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, commentId);
		pstmt.setInt(2, userId);
		pstmt.setString(3, toUser);
		pstmt.setString(4, content);
		pstmt.execute();
	}
	//添加资源一级回复
	public void addComment(int workId, int userId, String content, Connection con) throws SQLException {
		String sql = "INSERT INTO comment(user_id, work_id, content) VALUES(?,?,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, userId);
		pstmt.setInt(2, workId);
		pstmt.setString(3, content);
		pstmt.execute();
	}
	//用户收藏该资源
	public void changeGoodnum (int id, int num, int userId, Connection con) throws SQLException {
		String sql;
		sql = "update software set goodnum=? where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, num);
		pstmt.setInt(2, id);
		pstmt.execute();
		
		sql = "insert collection(user_id, work_id) VALUES(?,?)";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, userId);
		pstmt.setInt(2, id);
		pstmt.execute();
	}
	//用户下载该资源
	public void changeDownnum (int id, int num, int userId, Connection con) throws SQLException {
		String sql;
		int cnt = 0;
		sql = "update software set downnum=? where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, num);
		pstmt.setInt(2, id);
		pstmt.execute();
		
		sql = "select count(*) cnt from download where user_id=? and work_id=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, userId);
		pstmt.setInt(2, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			cnt = rs.getInt("cnt");
		}
		
		if(cnt <= 0) {
			sql = "insert download(user_id, work_id) VALUES(?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, userId);
			pstmt.setInt(2, id);
			pstmt.execute();
			
			sql = "insert mark(work_id, user_id) VALUES(?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.setInt(2, userId);
			pstmt.execute();
		}
	}
	//用户对已下载资源评分
	public void workGrade (int userId, int workId, int grade, Connection con) throws SQLException {
		String sql = "update mark set grade=? where work_id=? and user_id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, grade);
		pstmt.setInt(2, workId);
		pstmt.setInt(3, userId);
		pstmt.execute();
		
		int sum = 0, cnt = 0;
		sql = "select sum(grade) sum, count(*) cnt from mark where work_id=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, workId);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			sum = rs.getInt("sum");
			cnt = rs.getInt("cnt");
		}
		
		float fin = (float) (sum*1.0 / cnt*1.0);
		sql = "update software set grade=? where id=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setFloat(1, fin);
		pstmt.setInt(2, workId);
		pstmt.execute();
		
		return ;
	}

//管理员对公告的操作		
	//添加公告
	public void addNotice(Connection con, Notice notice) throws SQLException {
		String sql = "insert notices(title, content, writer) VALUES(?, ?, ?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, notice.getTitle());
		pstmt.setString(2, notice.getContent());
		pstmt.setInt(3, notice.getId());
		pstmt.execute();
		
		return ;
	}	
	//删除公告
	public void deleNotice(Connection con, int id) throws SQLException {
		String sql = "delete from notices where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
		
		return ;
	}

//管理员对标签的操作	
	//添加资源一级标签
	public void addBWorkTag(Connection con, String value) throws SQLException {
		String sql = "INSERT blable(tag) VALUES(?) ";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, value);
		pstmt.execute();
		
		return ;
	}
	//添加资源二级标签
	public void addWorkTag(Connection con, String value, int id) throws SQLException {
		String sql = "INSERT lable(tag, Bid) VALUES(?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, value);
		pstmt.setInt(2, id);
		pstmt.execute();
		
		return ;
	}
	//添加话题标签
	public void addTalkTag(Connection con, String value) throws SQLException {
		String sql = "INSERT topic(value, img) VALUES(?, 'tem.jpg')";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, value);
		pstmt.execute();
		
		return ;
	}
	//修改资源一级标签
	public void changeBWorkTag(Connection con, int id, String value) throws SQLException {
		String sql = "update blable set tag=? where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, value);
		pstmt.setInt(2, id);
		pstmt.execute();
		
		return ;
	}
	//修改资源二级标签
	public void changeWorkTag(Connection con, int id, String value) throws SQLException {
		String sql = "update lable set tag=? where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, value);
		pstmt.setInt(2, id);
		pstmt.execute();
		
		return ;
	}
	//修改话题标签
	public void changeTalkTag(Connection con, int id, String value) throws SQLException {
		String sql = "update topic set tag=? where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, value);
		pstmt.setInt(2, id);
		pstmt.execute();
		
		return ;
	}
}
