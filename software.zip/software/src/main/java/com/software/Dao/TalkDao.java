package com.software.Dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.software.Pojo.Discuss;
import com.software.Pojo.Talk;

public interface TalkDao {
	
	//**用户端
	//*用户个人页面
	//展示我的话题
	public List<Talk> showMyTalk(Connection con, int id, int page) throws SQLException;
	//删除一个话题
	public void deleTalk(Connection con, int id) throws SQLException; 
	
	//**管理员端
	//加载所有话题
	public List<Talk> loadAllTalk(Connection con, int page) throws SQLException;
	//加载今日话题
	public List<Talk> loadTodayTalk(Connection con, int page) throws SQLException;
	
	//论坛
	//加载该话题中某一级话题（id）的二级话题
	public List<Discuss> loadLevel2(Connection con, int id) throws SQLException;
	//加载该话题中某二级话题（id）的三级话题
	public List<Discuss> loadLevel3(Connection con, int id) throws SQLException;
}
