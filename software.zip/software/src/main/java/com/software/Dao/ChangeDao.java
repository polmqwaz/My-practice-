package com.software.Dao;

import java.sql.Connection;
import java.sql.SQLException;

import com.software.Pojo.Notice;

public interface ChangeDao {
//用户对话题的操作
	//话题发表
	public void postTalk(String title, String context, int select, int id, Connection con) throws SQLException;	
	//添加话题的一级回复
	public void addLevel1(Connection con, int id, int me, String content) throws SQLException;
	//添加话题的二级回复
	public void addLevel2(Connection con, int id, int me, String content) throws SQLException;
	//添加话题的三级回复
	public void addLevel3(Connection con, int id, int me, String you, String content) throws SQLException;

//用户对资源的操作
	//添加资源一级回复
	public void addComment(int workId, int userId, String content, Connection con) throws SQLException;
	//添加资源二级回复
	public void addSubComment(int commentId, int userId, String toUser, String content, Connection con) throws SQLException;
	//用户收藏该资源
	public void changeGoodnum (int id, int num, int userId, Connection con) throws SQLException;
	//用户下载该资源
	public void changeDownnum (int id, int num, int userId, Connection con) throws SQLException;
	//用户对已下载资源评分
	public void workGrade (int userId, int workId, int grade, Connection con) throws SQLException;
	//用户删除自己已通过资源
	public void delePassMywork(Connection con, int id) throws SQLException;
	//用户删除自己待审核资源
	public void deleTemMywork(Connection con, int id) throws SQLException;
	//用户删除自己待更新资源
	public void deleUpdateMywork(Connection con, int id) throws SQLException;
	//用户删除自己未通过资源
	public void deleNotPassMywork(Connection con, int id) throws SQLException;	
	//删除用户下载记录
	public void deleDownRecord(int recordId, Connection con) throws SQLException;
	//删除用户收藏记录
	public void deleLoveRecord(int recordId, Connection con) throws SQLException;

//管理员对公告的操作		
	//添加公告
	public void addNotice(Connection con, Notice notice) throws SQLException;
	//删除公告
	public void deleNotice(Connection con, int id) throws SQLException;

//管理员对标签的操作	
	//添加资源一级标签
	public void addBWorkTag(Connection con, String value) throws SQLException;
	//添加资源二级标签
	public void addWorkTag(Connection con, String value, int id) throws SQLException;
	//添加话题标签
	public void addTalkTag(Connection con, String value) throws SQLException;
	//修改资源一级标签
	public void changeBWorkTag(Connection con, int id, String value) throws SQLException;
	//修改资源二级标签
	public void changeWorkTag(Connection con, int id, String value) throws SQLException;
	//修改话题标签
	public void changeTalkTag(Connection con, int id, String value) throws SQLException;	
}
