package com.software.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.software.Dao.WorkDao;
import com.software.Pojo.Work;
import com.software.Pojo.WorkPic;

public class WorkDaoImpl implements WorkDao{
	
	//获取地址
	public String getAddr(Connection con, int id, int status) throws SQLException {
		String addr = "";
		//1：待审核   2：通过    3：待更新		
		if(status == 1)
		{
			String sql = "select addr from temwork where id=?";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				addr = rs.getString("addr");
			}
			
		} else {
			if(status == 2) {
				String sql = "select addr from software where id=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, id);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					addr = rs.getString("addr");
				}
			} else {
				String sql = "select addr from updatework where id=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, id);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					addr = rs.getString("addr");
				}
			}
		}
		
		return addr;
	}
	
	//待更新作品总量（All）
	public int sumUpdateWork(Connection con) throws SQLException {
		int num = 0;
		String sql = "select count(*) num from updatework";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			num = rs.getInt("num");
		}
		
		return num;
	}
	
	//待通过作品总量（All）
	public int sumWaitWork(Connection con) throws SQLException {
		int num = 0;
		String sql = "select count(*) num from temwork";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			num = rs.getInt("num");
		}
		
		return num;
	}
	
	//已通过作品总量（All）
	public int sumHaveWork(Connection con) throws SQLException {
		int num = 0;
		String sql = "select count(*) num from software";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			num = rs.getInt("num");
		}
		
		return num;
	}
	
	//未通过作品总量（All）
	public int sumNotPassWork(Connection con) throws SQLException {
		int num = 0;
		String sql = "select count(*) num from delework";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			num = rs.getInt("num");
		}
		
		return num;
	}
	
	//所有作品(用于清理)
	public List<Work> loadAllWork(Connection con) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "select * from software";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("id"));
			one.setAddr(rs.getString("addr"));
			one.setWorkimg(rs.getString("img"));
			work.add(one);
		}
		
		return work;
	}
	
	//所有截图(用于清理)
	public List<Work> loadAllPic(Connection con) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "select * from workpic";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("id"));
			one.setAddr(rs.getString("pic"));
			one.setGood(0);
			work.add(one);
		}
		
		sql = "select * from software";
		pstmt = con.prepareStatement(sql);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("id"));
			one.setAddr(rs.getString("img"));
			one.setGood(1);
			work.add(one);
		}
			
		return work;
	}
	
	//删除截图（id）
	public void delePic(Connection con, int id) throws SQLException {
		String sql = "delete from workpic where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
		
		return ;
	}
	
	//展示排行榜
	public List<Work> showRank(Connection con) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "select rank.id, software.work_name, nickname, software.work_describe, software.img workimg, person.img userimg from rank, software, person WHERE person.id=software.user_id and rank.work_id=software.id ORDER BY rank.id LIMIT 0,10";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("id"));
			one.setName(rs.getString("work_name"));
			one.setUser(rs.getString("nickname"));
			one.setDescribe(rs.getString("work_describe"));
			one.setWorkimg(rs.getString("workimg"));
			one.setUserimg(rs.getString("userimg"));
			work.add(one);
		}
		
		return work;
	}
	
	//手动排行
	public Work findWork(Connection con, String name, String user, int num) throws SQLException {
		Work work = new Work();
		work.setDown(0);
		String sql = "SELECT work_name, software.id from software, person WHERE work_name LIKE '%" + name + "%' and person.id=software.id and person.nickname like '%" + user + "%'";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			work.setId(rs.getInt("id"));
			work.setName(rs.getString("work_name"));
			work.setDown(1);
		}
		
		return work;
	}
	
	//更新排行
	public void updateRank(String num[], Connection con) throws SQLException {
		String sql = "truncate table rank";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.execute();
		
		for(int i = 0; i < 10; i++) {
			int id = Integer.parseInt(num[i]);
			sql = "insert rank(work_id) values(?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			pstmt.execute();
		}
		
		return ;
	}
	
	//待审核新作品添加
	public void addwork (Work work, int num, String pic[], String size[], String picdes[], String title[], int id, Connection con) throws SQLException {
		String sql;
		int workid = 0, userid = 0;
		sql = "select id from person where nickname=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, work.getUser());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next())
		{
			userid = rs.getInt("id");
		}
		
		sql = "insert into temwork(work_name,user_id,addr,work_describe,img,lable_id,os,keyword) values(?,?,?,?,?,?,?,?)";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, work.getName());
		pstmt.setInt(2, userid);
		pstmt.setString(3, work.getAddr());
		pstmt.setString(4, work.getDescribe());
		pstmt.setString(5, work.getWorkimg());
		pstmt.setString(6, work.getLable());
		pstmt.setString(7, work.getOs());
		pstmt.setString(8, work.getSelftag());
		pstmt.execute();
		
		sql = "select id from temwork where addr=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, work.getAddr());
		rs=pstmt.executeQuery();
		if(rs.next())
		{
			workid = rs.getInt("id");
		}
		
		for(int i = 1; i < num; i++)
		{
			int picSize = Integer.parseInt(size[i-1]);
			sql = "insert into tempic(pic, picdescribe, work_id, num, size, title) values(?,?,?,?,?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, pic[i]);
			pstmt.setString(2, picdes[i-1]);
			pstmt.setInt(3, workid);
			pstmt.setInt(4, i);
			pstmt.setInt(5, picSize);
			pstmt.setString(6, title[i-1]);
			pstmt.execute();
		}
	}
	
	//待审核更新作品添加
	public void updatework (Work work, int num, String pic[], String size[], String picdes[], String title[], Connection con) throws SQLException {
		String sql;
		int workid = 0;
		sql = "select id from software where work_name=? and user_id=(select id from person where nickname=?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, work.getName());
		pstmt.setString(2, work.getUser());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next())
		{
			workid = rs.getInt("id");
		}
		
		sql = "insert into updatework(work_id,addr,content,os) values(?,?,?,?)";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, workid);
		pstmt.setString(2, work.getAddr());
		pstmt.setString(3, work.getDescribe());
		pstmt.setString(4, work.getOs());
		pstmt.execute();
		
		sql = "select id from updatework where addr=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, work.getAddr());
		rs=pstmt.executeQuery();
		if(rs.next())
		{
			workid = rs.getInt("id");
		}
		
		for(int i = 0; i < num; i++)
		{
			int picSize = Integer.parseInt(size[i]);
			sql = "insert into updatepic(pic, picdescribe, update_id, num, size, title) values(?,?,?,?,?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, pic[i]);
			pstmt.setString(2, picdes[i]);
			pstmt.setInt(3, workid);
			pstmt.setInt(4, i);
			pstmt.setInt(5, picSize);
			pstmt.setString(6, title[i]);
			pstmt.execute();
		}
	}
	
	//新作品通过，作品搬移
	public int allowWork (int id, Connection con) throws SQLException{
		Work work = new Work();
		String sql = "SELECT * from temwork where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		int userId = 0, lableId = 0, workId = 0;
		String tag = "";
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			work.setName(rs.getString("work_name"));
			userId = rs.getInt("user_id");
			work.setAddr(rs.getString("addr"));
			work.setDescribe(rs.getString("work_describe"));
			work.setTime(rs.getString("time"));
			work.setWorkimg(rs.getString("img"));
			lableId = rs.getInt("lable_id");
			work.setOs(rs.getString("os"));
			tag = rs.getString("keyword");
		}
	
		sql = "INSERT into software(work_name, user_id, addr, work_describe, time, img, lable_id, os) VALUES(?,?,?,?,?,?,?,?)";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, work.getName());
		pstmt.setInt(2, userId);
		pstmt.setString(3, work.getAddr());
		pstmt.setString(4, work.getDescribe());
		pstmt.setString(5, work.getTime());
		pstmt.setString(6, work.getWorkimg());
		pstmt.setInt(7, lableId);
		pstmt.setString(8, work.getOs());
		pstmt.execute();
		
		sql = "update person set work=work+1 where id=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, userId);
		pstmt.execute();
		
		sql = "select id from software where addr=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, work.getAddr());
		rs=pstmt.executeQuery();
		while(rs.next()) {
			workId = rs.getInt("id");
		}
		
		String[] item=tag.split(" ");
		int flag = 0;
		for(int i = 0; i < item.length; i++) {
			flag = 0;
			sql = "select id from keyword where tag=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, item[i]);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				flag = rs.getInt("id");
			}
			if(flag == 0) {
				sql = "insert into keyword(tag) VALUES(?)";
				pstmt=con.prepareStatement(sql);
				pstmt.setString(1, item[i]);
				pstmt.execute();
				
				sql = "select id from keyword where tag=?";
				pstmt=con.prepareStatement(sql);
				pstmt.setString(1, item[i]);
				rs=pstmt.executeQuery();
				while(rs.next()) {
					flag = rs.getInt("id");
				}
			}
			
			sql = "insert into relationKey(work_id, tag_id) values(?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, workId);
			pstmt.setInt(2, flag);
			pstmt.execute();
		}
		
		
		return workId;
	}
	//获取该审核通过作品的说明截图和作品图标
	public WorkPic getPic (int id, Connection con) throws SQLException {
		WorkPic workpic = new WorkPic();
		String sql = "SELECT * from tempic where work_id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			workpic.setPic(rs.getString("pic"), count);
			workpic.setTit(rs.getString("title"), count);
			workpic.setDes(rs.getString("picdescribe"), count);
			workpic.setSize(rs.getInt("size"), count);
			count++;
		}
		
		sql = "SELECT img from temwork where id=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			workpic.setPic(rs.getString("img"), count);
			count++;
		}
		workpic.setCount(count);
		
		return workpic;
	}
	//搬移图片到正式图库中
	public void movePic(WorkPic workpic, int workId, Connection con) throws SQLException {
		int count = workpic.getCount() - 1;
		String sql;
		PreparedStatement pstmt;
		
		for(int i = 0; i < count; i++)
		{
			sql = "INSERT INTO workpic (pic, picdescribe, work_id, num, size, title) VALUES(?,?,?,?,?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, workpic.getPic(i));
			pstmt.setString(2, workpic.getDes(i));
			pstmt.setInt(3, workId);
			pstmt.setInt(4, i+1);
			pstmt.setInt(5, workpic.getSize(i));
			pstmt.setString(6, workpic.getTit(i));
			pstmt.execute();
		}
	}
	//删除在临时作品数据库中的记录
	public void deleteWait(Connection con, int id) throws SQLException {
		String sql = "DELETE from temwork where temwork.id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
		
		return ;
	}
	//审批未通过公示
	public void moveDeleWait(Connection con, int id) throws SQLException {
		String name="", time="", user="", tag="";
		String sql = "select work_name, nickname, temwork.time, tag from temwork, person, lable where temwork.id=? and temwork.user_id=person.id and temwork.lable_id=lable.id";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			name = rs.getString("work_name");
			user = rs.getString("nickname");
			time = rs.getString("time");
			tag = rs.getString("tag");
		}
		
		sql = "insert delework(work_name, user, type, time, lable) values(?,?,?,?,?)";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2, user);
		pstmt.setString(3, "新作品");
		pstmt.setString(4, time);
		pstmt.setString(5, tag);
		pstmt.execute();
		
		return ;
	}
	
	//待更新作品通过，作品搬移
	public int allowUpdateWork (int id, Connection con) throws SQLException{
		Work work = new Work();
		String sql = "SELECT * from updatework where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		int workId = 0;
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			workId = rs.getInt("work_id");
			work.setAddr(rs.getString("addr"));
			work.setDescribe(rs.getString("content"));
			work.setTime(rs.getString("time"));
			work.setOs(rs.getString("os"));
		}
	
		sql = "update software set addr=?, updatecontent=?, updatetime=?, os=? where id=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, work.getAddr());
		pstmt.setString(2, work.getDescribe());
		pstmt.setString(3, work.getTime());
		pstmt.setString(4, work.getOs());
		pstmt.setInt(5, workId);
		pstmt.execute();
		
		return workId;
	}
	//获取新增加的图文说明
	public WorkPic getUpdatePic (int id, Connection con) throws SQLException {
		WorkPic workpic = new WorkPic();
		String sql = "SELECT * from updatepic where update_id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			workpic.setPic(rs.getString("pic"), count);
			workpic.setDes(rs.getString("picdescribe"), count);
			workpic.setSize(rs.getInt("size"), count);
			workpic.setTit(rs.getString("title"), count);
			count++;
		}
		workpic.setCount(count);
		
		return workpic;
	}
	//向该作品原有的图文说明增加新更新的内容
	public void moveUpdatePic(WorkPic workpic, int workId, Connection con) throws SQLException {
		int count = workpic.getCount();
		int num = 0;
		String sql;
		PreparedStatement pstmt;
		
		sql="SELECT num from workpic where work_id=? ORDER BY num DESC limit 0,1";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, workId);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			num = rs.getInt("num");
		}
		
		for(int i = 0; i < count; i++)
		{
			sql = "INSERT INTO workpic (pic, picdescribe, work_id, num, size, title) VALUES(?,?,?,?,?,?)";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, workpic.getPic(i));
			pstmt.setString(2, workpic.getDes(i));
			pstmt.setInt(3, workId);
			pstmt.setInt(4, num+i+1);
			pstmt.setInt(5, workpic.getSize(i));
			pstmt.setString(6, workpic.getTit(i));
			pstmt.execute();
		}
	}
	//删除在临时更新数据库中的记录(通过)
	public void deleteUpdate(Connection con, int id) throws SQLException {
		String sql = "DELETE from updatework where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
		
		return ;
	}
	//审批未通过公示
	public void moveDeleUpdate(Connection con, int id) throws SQLException {
		String name="", time="", user="", tag="";
		String sql = "select work_name, nickname, updatework.time, tag from updatework, software, person, lable where updatework.id=? and updatework.work_id=software.id and software.user_id=person.id and software.lable_id=lable.id";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			name = rs.getString("work_name");
			user = rs.getString("nickname");
			time = rs.getString("time");
			tag = rs.getString("tag");
		}
		
		sql = "insert delework(work_name, user, type, time,lable) values(?,?,?,?,?)";
		pstmt=con.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setString(2, user);
		pstmt.setString(3, "更新");
		pstmt.setString(4, time);
		pstmt.setString(5, tag);
		pstmt.execute();
		
		return ;
	}
	
	//删除已通过的作品
	public void deleteHave(Connection con, int id) throws SQLException {
		String sql = "DELETE from software where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
		
		return ;
	}
	
	//删除未通过的作品
	public void deleteNotPass(Connection con, int id) throws SQLException {
		String sql = "DELETE from delework where id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
			
		return ;
	}
	
	//获得通过作品的截图
	public WorkPic getHavePic (int id, Connection con) throws SQLException {
		WorkPic workpic = new WorkPic();
		String sql = "SELECT * from workpic where work_id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			workpic.setPic(rs.getString("pic"), count);
			workpic.setDes(rs.getString("picdescribe"), count);
			workpic.setSize(rs.getInt("size"), count);
			count++;
		}
		
		sql = "SELECT img from software where id=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			workpic.setPic(rs.getString("img"), count);
			count++;
		}
		workpic.setCount(count);
		
		return workpic;
	}
	
	//提取待审核作品的相关信息（管理员）
	public Work getWaitWork(Connection con, int id) throws SQLException {
		Work work = new Work();
		String sql = "SELECT work_name, os, work_describe, tag, nickname, keyword, addr from temwork, person, lable where temwork.user_id=person.id and temwork.lable_id=lable.id and temwork.id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			work.setId(id);
			work.setName(rs.getString("work_name"));
			work.setOs(rs.getString("os"));
			work.setDescribe(rs.getString("work_describe"));
			work.setLable(rs.getString("tag"));
			work.setUser(rs.getString("nickname"));
			work.setAddr(rs.getString("addr"));
			work.setSelftag(rs.getString("keyword"));
		}
		
		return work;
	}
	
	//提取待更新作品的相关信息（管理员）
	public Work getUpdateWork(Connection con, int id) throws SQLException {
		Work work = new Work();
		String sql = "SELECT work_name, updatework.os, content, tag, nickname, updatework.addr from software, updatework, person, lable where software.user_id=person.id and software.lable_id=lable.id and software.id=updatework.work_id and updatework.id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			work.setId(id);
			work.setName(rs.getString("work_name"));
			work.setOs(rs.getString("os"));
			work.setDescribe(rs.getString("content"));
			work.setLable(rs.getString("tag"));
			work.setUser(rs.getString("nickname"));
			work.setAddr(rs.getString("addr"));
		}
		
		return work;
	}
	
	//提取正式作品的相关信息（管理员）
	public Work getOnWork(Connection con, int id) throws SQLException {
		Work work = new Work();
		String sql = "SELECT work_name, os, addr, work_describe, tag, nickname from software, person, lable where software.user_id=person.id and software.lable_id=lable.id and software.id=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			work.setId(id);
			work.setName(rs.getString("work_name"));
			work.setOs(rs.getString("os"));
			work.setDescribe(rs.getString("work_describe"));
			work.setLable(rs.getString("tag"));
			work.setAddr(rs.getString("addr"));
			work.setUser(rs.getString("nickname"));
		}
		
		sql = "SELECT tag from relationkey, keyword where keyword.id=relationkey.tag_id and relationkey.work_id=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs = pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			work.setTag(rs.getString("tag"), count);
			count ++;
		}
		work.setTagnum(count);
		
		return work;
	}
	
	//单个作品展示（管理员）
	public Work oneWorkLoad(Connection con, String work_name, String user_name, String name) throws SQLException {
		String sql;
		sql = "SELECT software.id, work_name, addr, work_describe,updatetime, software.time, downnum, goodnum, grade, software.img workimg, person.img userimg, tag, os, updatecontent FROM software, lable, person WHERE software.work_name=? and person.nickname=? and software.lable_id = lable.id";
		Work work = new Work();
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, work_name);
		pstmt.setString(2, user_name);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			work.setId(rs.getInt("id"));
			work.setName(rs.getString("work_name"));
			work.setUser(user_name);
			work.setAddr(rs.getString("addr"));
			work.setDescribe(rs.getString("work_describe"));
			work.setDown(rs.getInt("downnum"));
			work.setGood(rs.getInt("goodnum"));
			work.setUpdatetime(rs.getString("updatetime"));
			work.setTime(rs.getString("time"));
			work.setGrade(rs.getFloat("grade"));
			work.setWorkimg(rs.getString("workimg"));
			work.setLable(rs.getString("tag"));
			work.setOs(rs.getString("os"));
			work.setSelftag(rs.getString("updatecontent"));
		}
		
		sql = "select tag from relationkey, keyword where relationkey.work_id=? and relationkey.tag_id=keyword.id";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, work.getId());
		rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			work.setTag(rs.getString("tag"), count);
			count++;
		}
		work.setTagnum(count); 
		
		String flag = "false";
		sql = "select count(*) cnt from collection, person where collection.user_id=person.id and person.nickname=? and collection.work_id=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setInt(2, work.getId());
		rs=pstmt.executeQuery();
		while(rs.next()) {
			if(rs.getInt("cnt") > 0) {
				flag = "true";
			}
		}
		work.setUserimg(flag);
		
		return work;
	}
	
	//待审核作品加载（管理员）
	public List<Work> waitWorkLoad(Connection con, int numStart, int numEnd) throws SQLException {
		List<Work> list = new ArrayList<Work>();
		String sql = "SELECT temwork.id, work_name, nickname, temwork.addr, work_describe, temwork.time, temwork.img workimg, tag FROM temwork, person, lable WHERE temwork.user_id = person.id and temwork.lable_id = lable.id ORDER BY temwork.id ASC LIMIT ?,?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, numStart);
		pstmt.setInt(2, numEnd); 
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			Work work = new Work(); 
			work.setId(rs.getInt("id"));
			work.setName(rs.getString("work_name"));
			work.setUser(rs.getString("nickname"));
			work.setAddr(rs.getString("addr"));
			work.setDescribe(rs.getString("work_describe"));
			work.setTime(rs.getString("time"));
			work.setWorkimg(rs.getString("workimg"));
			work.setLable(rs.getString("tag"));
			list.add(work);
		}
		
		return list;
	}
	
	//待已通过作品加载（管理员）
	public List<Work> haveWorkLoad(Connection con, int numStart, int numEnd) throws SQLException {
		List<Work> list = new ArrayList<Work>();
		String sql = "SELECT software.id, work_name, nickname, software.addr, work_describe, software.time, software.img workimg, tag FROM software, person, lable WHERE software.user_id = person.id and software.lable_id = lable.id ORDER BY software.id DESC LIMIT ?,?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, numStart);
		pstmt.setInt(2, numEnd);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			Work work = new Work(); 
			work.setId(rs.getInt("id"));
			work.setName(rs.getString("work_name"));
			work.setUser(rs.getString("nickname"));
			work.setAddr(rs.getString("addr"));
			work.setDescribe(rs.getString("work_describe"));
			work.setTime(rs.getString("time"));
			work.setWorkimg(rs.getString("workimg"));
			work.setLable(rs.getString("tag"));
			list.add(work);
		}
		
		return list;
	}
	
	//待更新作品加载（管理员）
	public List<Work> updateWorkLoad(Connection con, int numStart, int numEnd) throws SQLException {
		List<Work> list = new ArrayList<Work>();
		String sql = "SELECT updatework.id, work_name, nickname, updatework.addr, updatework.content, updatework.time, software.img workimg, tag FROM updatework, software, person, lable WHERE status=0 and updatework.work_id=software.id and software.user_id = person.id and software.lable_id = lable.id ORDER BY updatework.time DESC LIMIT ?,?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, numStart);
		pstmt.setInt(2, numEnd);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			Work work = new Work(); 
			work.setId(rs.getInt("id"));
			work.setName(rs.getString("work_name"));
			work.setUser(rs.getString("nickname"));
			work.setAddr(rs.getString("addr"));
			work.setDescribe(rs.getString("content"));
			work.setTime(rs.getString("time"));
			work.setWorkimg(rs.getString("workimg"));
			work.setLable(rs.getString("tag"));
			list.add(work);
		}
		
		return list;
	}
	
	//未通过作品加载（管理员）
	public List<Work> notPassWorkLoad(Connection con, int numStart, int numEnd) throws SQLException {
		List<Work> list = new ArrayList<Work>();
		String sql = "SELECT id, work_name, user, time, type from delework ORDER BY id ASC LIMIT ?,?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, numStart);
		pstmt.setInt(2, numEnd);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			Work work = new Work(); 
			work.setId(rs.getInt("id"));
			work.setName(rs.getString("work_name"));
			work.setUser(rs.getString("user"));
			work.setTime(rs.getString("time"));
			work.setLable(rs.getString("type"));
			list.add(work);
		}
		
		return list;
	}
	
	//根据base加载作品
	public List<Work> newWorkLoad(Connection con, int num, String base) throws SQLException {
		String sql;
		sql = "SELECT software.id, work_name, nickname, addr, work_describe, software.time, downnum, goodnum, grade, software.img workimg, person.img userimg, tag FROM software, person, lable WHERE software.user_id = person.id and software.lable_id = lable.id ORDER BY software."+ base +" DESC LIMIT 0,?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, num);
		ResultSet rs=pstmt.executeQuery();
		List<Work> list = new ArrayList<Work>();
		while(rs.next()) {
			Work work = new Work(); 
			work.setId(rs.getInt("id"));
			work.setName(rs.getString("work_name"));
			work.setUser(rs.getString("nickname"));
			work.setAddr(rs.getString("addr"));
			work.setDescribe(rs.getString("work_describe"));
			work.setDown(rs.getInt("downnum"));
			work.setGood(rs.getInt("goodnum"));
			work.setTime(rs.getString("time"));
			work.setGrade(rs.getFloat("grade"));
			work.setWorkimg(rs.getString("workimg"));
			work.setUserimg(rs.getString("userimg"));
			work.setLable(rs.getString("tag"));
			list.add(work);
		}
		
		return list;
	}
	
	//相似作品
	public List<Work> alikeLoad(Connection con, int id) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		int[] num = new int[5];
		String sql = "SELECT distinct(work_id) from relationkey where tag_id in(select tag_id from relationkey where relationkey.work_id=?) and work_id!=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, id);
		ResultSet rs=pstmt.executeQuery();
		int cnt = 0;
		while(rs.next() && cnt < 5) {
			num[cnt] = rs.getInt("work_id");
			cnt++;
		}
		
		if(cnt < 5) {
			sql = "select distinct(id) from software where id not in (SELECT distinct(work_id) from relationkey where tag_id in(select tag_id from relationkey where relationkey.work_id=?))";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			while(rs.next() && cnt < 5) {
				num[cnt] = rs.getInt("id");
				cnt++;
			}
		}
		
		for(int i = 0; i < 5; i++) {
			sql = "select software.id, software.img, software.work_name, person.nickname, lable.tag, software.downnum from software, person, lable where software.user_id=person.id and software.lable_id=lable.id and software.id=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num[i]);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Work one = new Work();
				one.setName(rs.getString("work_name"));
				one.setId(rs.getInt("id"));
				one.setWorkimg(rs.getString("img"));
				one.setUser(rs.getString("nickname"));
				one.setLable(rs.getString("tag"));
				one.setDown(rs.getInt("downnum"));
				work.add(one);
			}
		}
		
		return work;
	}
}
