 package com.software.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.software.Dao.IndexDao;
import com.software.Pojo.Discuss;
import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Talk;
import com.software.Pojo.TalkTag;
import com.software.Pojo.UserPly;
import com.software.Pojo.UserSay;
import com.software.Pojo.WorkPic;

public class IndexDaoImpl implements IndexDao{

//论坛
	//计算所有话题总数（基于base：0无条件  1标签   2话题）
	public int sumTalk(Connection con, int type, String base) throws SQLException {
		String sql = "select count(*) cnt from talk";
		if(type == 1) {
			sql = "select count(*) cnt from relationtalk, topic where topic_id=topic.id and topic.value=?";
		} else{
			if(type == 2) {
				sql = "select count(*) cnt from talk where talk.title like '%" + base + "%'";
			}
		}
		PreparedStatement pstmt=con.prepareStatement(sql);
		if(type == 1) {
			pstmt.setString(1, base);
		}
		ResultSet rs=pstmt.executeQuery();
		int cnt = 0;
		while(rs.next()) {
			cnt = rs.getInt("cnt");
		}
		
		return cnt;
	}
	
	//论坛页面加载（基于base：0无条件  1标签   2话题）
	public List<Talk> loadTalk(int num1, int type, String base, Connection con) throws SQLException {
		List<Talk> talk = new ArrayList<Talk>();
		String sql = "select talk.id, title, content, nickname, person.img, talk.time, look, reply from talk, person where user_id = person.id ORDER BY talk.time desc LIMIT ?,?";
		if(type == 2) {
			sql = "select talk.id, title, content, nickname, person.img, talk.time, look, reply from talk, person where user_id = person.id and talk.title like '%" + base + "%' ORDER BY talk.time desc LIMIT ?,?";
		}
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, num1*5);
		pstmt.setInt(2, 5);
		if(type == 1) {
			sql = "select talk.id, title, content, nickname, person.img, talk.time, look, reply from talk, person, relationtalk, topic where user_id = person.id and topic_id=topic.id and topic.value=? and talk_id=talk.id ORDER BY talk.time desc LIMIT ?,?";
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, base);
			pstmt.setInt(2, num1*5);
			pstmt.setInt(3, num1*5 + 5);
		}
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			Talk one = new Talk();
			one.setId(rs.getInt("id"));
			one.setTitle(rs.getString("title"));
			one.setUser(rs.getString("nickname"));
			one.setImg(rs.getString("img"));
			one.setContent(rs.getString("content"));
			one.setLook(rs.getInt("look"));
			one.setReply(rs.getInt("reply"));
			one.setTime(rs.getString("time"));
			talk.add(one);
		}
		
		for(int i = 0; i < talk.size(); i++) {
			int id = talk.get(i).getId();
			sql = "select topic.id, topic.value from topic, relationtalk where topic.id = relationtalk.topic_id and relationtalk.talk_id=?";
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, id);
			rs=pstmt.executeQuery();
			TalkTag tag = new TalkTag();
			int count = 0;
			while(rs.next()) {
				tag.setId(rs.getInt("id"), count);
				tag.setTag(rs.getString("value"), count);
				count++;
			}
			tag.setCnt(count);
			talk.get(i).setTag(tag);
		}
		
		return talk;
	}
	
	//热门话题加载
	public List<Talk> loadHotTalk(Connection con) throws SQLException {
		List<Talk> talk = new ArrayList<Talk>();
		
		String sql = "select talk.id, title, nickname, talk.time from talk, person where person.id = talk.user_id order by reply desc limit 0,5";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			Talk one = new Talk();
			one.setId(rs.getInt("id"));
			one.setTitle(rs.getString("title"));
			one.setTime(rs.getString("time"));
			one.setUser(rs.getString("nickname")); 
			talk.add(one);
		}
		
		return talk;
	}
	
	//单个话题详情页面加载
	public List<Discuss> loadDiscuss(Connection con, int id, int page) throws SQLException {
		List<Discuss> discuss = new ArrayList<Discuss>();
		int look = 0;
		String sql = "select nickname, title, content, talk.time, img, reply, look from talk, person where talk.id=? and talk.user_id=person.id";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			Discuss one = new Discuss();
			one.setTitle(rs.getString("title"));
			one.setUser(rs.getString("nickname"));
			one.setContent(rs.getString("content"));
			one.setImg(rs.getString("img"));
			one.setTime(rs.getString("time"));
			one.setReply(rs.getInt("reply"));
			look = rs.getInt("look");
			discuss.add(one);
		}
		
		sql = "update talk set look=? where id=?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, look+1);
		pstmt.setInt(2, id);
		pstmt.execute();
		
		sql = "select level1.id, nickname, img, content, level1.time, reply from level1, person where level1.talk_id=? and level1.user_id=person.id order by level1.time limit ?,5";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page*5);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			Discuss one = new Discuss();
			one.setId(rs.getInt("id"));
			one.setUser(rs.getString("nickname"));
			one.setBelong(id);
			one.setContent(rs.getString("content"));
			one.setImg(rs.getString("img"));
			one.setLevel(1);
			one.setTime(rs.getString("time"));
			one.setReply(rs.getInt("reply"));
			discuss.add(one);
		}
		
		return discuss;
	}
	
//资源展示页面
	//评论加载
	public UserSay loadComment(Connection con, int id, int page) throws SQLException {
		UserSay say = new UserSay();
		page = page*8;
		String sql = "select comment.id id, nickname, content, comment.time from comment, person where work_id=? and user_id=person.id order by comment.time desc limit ?,8";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page);
		ResultSet rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			say.setId(rs.getInt("id"), count);
			say.setUser(rs.getString("nickname"), count);
			say.setContent(rs.getString("content"), count);
			say.setTime(rs.getString("time"), count);
			count ++;
		}
		say.setNum(count);
		
		sql = "select count(*) num from comment, person where work_id=? and user_id=person.id";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			say.setSum(rs.getInt("num"));
		}
		
		for(int i = 0; i < count; i++)
		{
			sql = "select p1.nickname f, p2.nickname t, subcomment.time, content from subcomment, person p1, person p2 where p1.id=subcomment.user_id and p2.id=subcomment.to_id and comment_id=? order by subcomment.time asc";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, say.getId(i));
			rs=pstmt.executeQuery();
			int x = 0;
			UserPly reply = new UserPly();
			while(rs.next()) {
				reply.setFrom(rs.getString("f"), x);
				reply.setTo(rs.getString("t"), x);
				reply.setContent(rs.getString("content"), x);
				reply.setTime(rs.getString("time"), x);
				x++;
			}
			reply.setNum(x);
			say.setReply(reply);
		}
		
		return say;
	}
	
	//作品图文说明加载 	
	public WorkPic showWorkPic(Connection con, int id, int num1) throws SQLException {
		WorkPic workpic = new WorkPic();
		String sql = "select * from workpic WHERE work_id=? ORDER BY id DESC LIMIT ?,3";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, num1);
		ResultSet rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			workpic.setPic(rs.getString("pic"), count);
			workpic.setDes(rs.getString("picdescribe"), count);
			workpic.setSize(rs.getInt("size"), count);
			workpic.setTit(rs.getString("title"), count);
			count++;
		}
		workpic.setCount(count);
		
		sql = "select count(*) num from workpic WHERE work_id=?";
		pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		rs=pstmt.executeQuery();
		while(rs.next()) {
			workpic.setSum(rs.getInt("num"));
		}
		
		return workpic;
	}
	
//公告	
	//全部公告加载
	public List<Notice> loadNotice(Connection con) throws SQLException {
		String sql;
		sql = "Select * from notices";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		List<Notice> list = new ArrayList<Notice>();
		while(rs.next()) {
			Notice notice = new Notice();
			notice.setId(rs.getInt("id"));
			notice.setTitle(rs.getString("title"));
			notice.setContent(rs.getString("content"));
			notice.setTime(rs.getString("time"));
			list.add(notice);
		}
		return list;
	}
	
	//单个公告加载
	public Notice loadOneNotice(Connection con, int id) throws SQLException {
		String sql;
		sql = "Select notices.id, notices.title, notices.content, notices.time, nickname from notices, person WHERE notices.id=? and person.id=notices.writer";
		Notice notice = new Notice(); 
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			notice.setId(rs.getInt("id"));
			notice.setUser(rs.getString("nickname"));
			notice.setTitle(rs.getString("title"));
			notice.setContent(rs.getString("content"));
			notice.setTime(rs.getString("time"));
		}
		
		return notice;
	}
	
//标签
	//资源一级标签加载
	public Lable loadTag(Connection con) throws SQLException {
		Lable tag = new Lable();
		String sql = "select id, tag from Blable ORDER BY id DESC";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			tag.setValue(rs.getInt("id"), count);
			tag.setLable(rs.getString("tag"), count);
			count++;
		}
		tag.setNum(count);
		return tag;
	}
	
	//话题标签加载
	public TalkTag loadAllTag(Connection con) throws SQLException {
		TalkTag tag = new TalkTag();
		String sql = "select * from topic ORDER BY id DESC";
		PreparedStatement pstmt=con.prepareStatement(sql);
		ResultSet rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			tag.setId(rs.getInt("id"), count);
			tag.setTag(rs.getString("value"), count);
			tag.setImg(rs.getString("img"), count);
			count++;
		}
		tag.setCnt(count);
		
		return tag;
	}
}
