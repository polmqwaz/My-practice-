package com.software.Dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.software.Pojo.Work;
import com.software.Pojo.WorkPic;

public interface WorkDao {

//获取细节
	//获取地址
	public String getAddr(Connection con, int id, int status) throws SQLException;
	//待更新作品总量（All）
	public int sumUpdateWork(Connection con) throws SQLException;
	//待通过作品总量（All）
	public int sumWaitWork(Connection con) throws SQLException;
	//已通过作品总量（All）
	public int sumHaveWork(Connection con) throws SQLException;
	//未通过作品总量（All）
	public int sumNotPassWork(Connection con) throws SQLException;
	//所有作品(用于清理)
	public List<Work> loadAllWork(Connection con) throws SQLException;
	//所有截图(用于清理)
	public List<Work> loadAllPic(Connection con) throws SQLException;
	//删除截图（id）
	public void delePic(Connection con, int id) throws SQLException;

//教师推荐
	//展示排行榜
	public List<Work> showRank(Connection con) throws SQLException;
	//手动排行
	public Work findWork(Connection con, String name, String user, int num) throws SQLException;
	//更新排行
	public void updateRank(String num[], Connection con) throws SQLException;

//作品上传
	//待审核新作品添加
	public void addwork (Work work, int num, String pic[], String size[], String picdes[], String title[], int id, Connection con) throws SQLException;	
	//待审核更新作品添加
	public void updatework (Work work, int num, String pic[], String size[], String picdes[], String title[], Connection con) throws SQLException;

//管理员审核
	//新作品通过，作品搬移
	public int allowWork (int id, Connection con) throws SQLException;
	//获取该审核通过作品的说明截图和作品图标
	public WorkPic getPic (int id, Connection con) throws SQLException;
	//搬移图片到正式图库中
	public void movePic(WorkPic workpic, int workId, Connection con) throws SQLException;
	//删除在临时作品数据库中的记录
	public void deleteWait(Connection con, int id) throws SQLException;
	//审批未通过公示
	public void moveDeleWait(Connection con, int id) throws SQLException;
	
	//待更新作品通过，作品搬移
	public int allowUpdateWork (int id, Connection con) throws SQLException;
	//获取新增加的图文说明
	public WorkPic getUpdatePic (int id, Connection con) throws SQLException;
	//向该作品原有的图文说明增加新更新的内容
	public void moveUpdatePic(WorkPic workpic, int workId, Connection con) throws SQLException;
	//删除在临时更新数据库中的记录
	public void deleteUpdate(Connection con, int id) throws SQLException;
	//审批未通过公示
	public void moveDeleUpdate(Connection con, int id) throws SQLException;
	
	//删除已通过的作品
	public void deleteHave(Connection con, int id) throws SQLException;
	//删除未通过的作品
	public void deleteNotPass(Connection con, int id) throws SQLException;
	
//作品展示	
	//获得通过作品的截图
	public WorkPic getHavePic (int id, Connection con) throws SQLException;
	//提取待审核作品的相关信息（管理员）
	public Work getWaitWork(Connection con, int id) throws SQLException;
	//提取待更新作品的相关信息（管理员）
	public Work getUpdateWork(Connection con, int id) throws SQLException;
	//提取正式作品的相关信息（管理员）
	public Work getOnWork(Connection con, int id) throws SQLException;
	//单个作品展示（管理员）
	public Work oneWorkLoad(Connection con, String work_name, String user_name, String name) throws SQLException;

//分类作品加载
	//待审核作品加载（管理员）
	public List<Work> waitWorkLoad(Connection con, int numStart, int numEnd) throws SQLException;
	//待已通过作品加载（管理员）
	public List<Work> haveWorkLoad(Connection con, int numStart, int numEnd) throws SQLException;
	//待更新作品加载（管理员）
	public List<Work> updateWorkLoad(Connection con, int numStart, int numEnd) throws SQLException;
	//未通过作品加载（管理员）
	public List<Work> notPassWorkLoad(Connection con, int numStart, int numEnd) throws SQLException;
	//根据base加载作品
	public List<Work> newWorkLoad(Connection con, int num, String base) throws SQLException;
	//相关作品
	public List<Work> alikeLoad(Connection con, int id) throws SQLException;


}
