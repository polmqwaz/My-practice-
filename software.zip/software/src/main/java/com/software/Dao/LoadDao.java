package com.software.Dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Work;

public interface LoadDao {
	
	//搜索
	//按标签搜索
	public List<Work> searchTag(Connection con, int num, String Tag, String tag, String on) throws SQLException;
	//按标签和关键字搜索
	public List<Work> searchTag(Connection con, int num, String value[], String on) throws SQLException;
	//按用户名搜索
	public List<Work> searchUser(Connection con, String value, int num, String on, int id) throws SQLException;
	//按工具名搜索
	public List<Work> searchWork(Connection con, String value, int num, String on) throws SQLException;
	//按关键字搜索
	public List<Work> searchKey(Connection con, String value, int num, String on) throws SQLException;
	//按描述搜索
	public List<Work> searchDes(Connection con, String value, int num, String on) throws SQLException;
	
	//个人主页
	//加载该用户已通过作品
	public List<Work> loadMywork(Connection con, int id, int page) throws SQLException;
	//加载该用户待更新的作品
	public List<Work> loadMyupdatework(Connection con, int id, int page) throws SQLException;
	//加载该用户待审核的作品
	public List<Work> loadMywaitwork(Connection con, int id, int page) throws SQLException;
	//加载该用户未通过的作品
	public List<Work> loadMynotpasswork(Connection con, int id, int page) throws SQLException;
	//获取要更新作品的基本信息
	public Work loadworkUpdate(Connection con, String name, int id) throws SQLException;
	//加载用户已下载的工具
	public List<Work> loadMydownwork(Connection con, int id, int page) throws SQLException;
	//加载用户收藏的工具
	public List<Work> loadMylovework(Connection con, int id, int page) throws SQLException;
	//二级标签加载
	public Lable getTag(Connection con, int id) throws SQLException;
	
	//管理员
	//加载今日公告
	public List<Notice> loadTodayNotice(Connection con, int page) throws SQLException;
	//加载所有公共
	public List<Notice> loadAllNotice(Connection con, int page) throws SQLException;
}
