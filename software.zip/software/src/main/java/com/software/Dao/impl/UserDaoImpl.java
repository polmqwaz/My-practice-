package com.software.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.software.Dao.UserDao;
import com.software.Pojo.User;
import com.software.Pojo.UserDetail;

public class UserDaoImpl implements UserDao{

	//获取用户Id
	public int getUserId(Connection con, String name) throws SQLException {
		String sql;
		int ans = 0;
		sql = "select id from person where nickname=?";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, name);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next()) {
			ans = rs.getInt("id");
		}
		return ans;
	}
	
	//上传工具排行榜
	public List<UserDetail> workRank(Connection con) throws SQLException {
		List<UserDetail> user = new ArrayList<UserDetail>();
		String sql = "SELECT * from person ORDER BY work DESC LIMIT 0,10";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail(); 
			one.setUsername(rs.getString("nickname"));
			one.setId(rs.getInt("work"));
			user.add(one);
		}
		
		return user;
	}
	
	//用户登录
	public int userLogin(User user, Connection con) throws SQLException {
		String sql;
		int id = 0;
		if(user.getPosition() == 1) {
			sql = "Select id from person where nickname=? and password=? and position!=0";
		}else {
			sql = "Select id from person where nickname=? and password=?";
		}
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, user.getName());
		pstmt.setString(2, user.getPass());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next())
		{
			id = rs.getInt("id");
		}	
		return id;
	}

	//注册用户名检查 
	public Boolean checkUserName(String name, Connection con) throws SQLException {
		Boolean ans = true;
		String sql = "select count(*) cnt from person where person.nickname=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, name);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			if(rs.getInt("cnt") > 0) {
				ans = false;
			}
		}
		
		return ans;
	}
	
	//用户注册
	public void userRegisiter(UserDetail detail, Connection con) throws SQLException {

		int max=1000;
        Random random = new Random();
        int s = random.nextInt(max%29+1);
        String img = s + ".png";
		
		//insert new user
		String sql = "insert into person(nickname,password,major,mail,word,position,img) values(?,?,?,?,?,0,?)";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setString(1, detail.getUsername());
		pstmt.setString(2, detail.getUserpass());
		pstmt.setString(3, detail.getUsermajor());
		pstmt.setString(4, detail.getUsermail());
		pstmt.setString(5, detail.getUserword());
		pstmt.setString(6, img);
		pstmt.execute();
		
	}
	
	//用户信息更新
	public void updateUser(UserDetail user, Connection con) throws SQLException {
		String sql = "update person set nickname=?, major=?, mail=?, word=? where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, user.getUsername());
		pstmt.setString(2, user.getUsermajor());
		pstmt.setString(3, user.getUsermail());
		pstmt.setString(4, user.getUserword());
		pstmt.setInt(5, user.getId());
		pstmt.execute();
		
	}
	
	//提取用户信息
	public UserDetail userDetail(int id, Connection con) throws SQLException {
		UserDetail user = new UserDetail();
		String sql = "SELECT * from person where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			user.setUsername(rs.getString("nickname"));
			user.setUsermajor(rs.getString("major"));
			user.setUsermail(rs.getString("mail"));
			user.setUserpass(rs.getString("password"));
			user.setUserword(rs.getString("word"));
			user.setImg(rs.getString("img"));
			if(rs.getInt("position") == 1) {
				user.setUserpass("管理员");
			} else {
				if(rs.getInt("position") == 2) {
					user.setUserpass("教师");
				} else {
					user.setUserpass("用户");
				}
			}
		}
		
		return user;
	}
	
	//更改密码
	public void changePass(String pass, int id, Connection con) throws SQLException {
		String sql = "update person set password=? where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, pass);
		pstmt.setInt(2, id);
		pstmt.execute();
	}
	
	//ad
	//用户身份
	public int getPosition(Connection con, int id) throws SQLException {
		int position = 0;
		String sql = "select position from person where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			position = rs.getInt("position");
		}
		
		return position;
	}
		
	//展示所有用户
	public List<UserDetail> showAll(Connection con, int page) throws SQLException {
		List<UserDetail> user = new ArrayList<UserDetail>();
		String sql = "SELECT count(*) cnt from person";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setId(rs.getInt("cnt"));
			user.add(one);
		}
		
		sql = "SELECT * from person ORDER BY id LIMIT ?,7";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setUsername(rs.getString("nickname"));
			one.setUsermail(rs.getString("mail"));
			one.setUsermajor(rs.getString("major"));
			if(rs.getInt("position") == 1) {
				one.setUserpass("管理员");
			} else {
				if(rs.getInt("position") == 2) {
					one.setUserpass("教师");
				} else {
					one.setUserpass("用户");
				}
			}
			one.setUserword(rs.getString("word"));
			one.setId(rs.getInt("id"));
			user.add(one);
		}
		
		return user;
	}
	
	//展示近期添加用户(近7天)
	public List<UserDetail> showNow(Connection con, int page) throws SQLException {
		List<UserDetail> user = new ArrayList<UserDetail>();
		String sql = "SELECT count(*) cnt from person WHERE time>date_sub(curdate(),interval 7 day)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setId(rs.getInt("cnt"));
			user.add(one);
		}
		
		sql = "SELECT * from person WHERE time>date_sub(curdate(),interval 7 day) ORDER BY time DESC LIMIT ?,7";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setUsername(rs.getString("nickname"));
			one.setUsermail(rs.getString("mail"));
			one.setUsermajor(rs.getString("major"));
			if(rs.getInt("position") == 1) {
				one.setUserpass("管理员");
			} else {
				if(rs.getInt("position") == 2) {
					one.setUserpass("教师");
				} else {
					one.setUserpass("用户");
				}
			}
			one.setUserword(rs.getString("word"));
			one.setId(rs.getInt("id"));
			user.add(one);
		}
		
		return user;
	}
	
	//展示所有普通用户
	public List<UserDetail> showUser(Connection con, int page) throws SQLException {
		List<UserDetail> user = new ArrayList<UserDetail>();
		String sql = "SELECT count(*) cnt from person WHERE position=0";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setId(rs.getInt("cnt"));
			user.add(one);
		}
		
		sql = "SELECT * from person WHERE position=0 ORDER BY time DESC LIMIT ?,7";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setUsername(rs.getString("nickname"));
			one.setUsermail(rs.getString("mail"));
			one.setUsermajor(rs.getString("major"));
			one.setUserpass("用户");
			one.setUserword(rs.getString("word"));
			one.setId(rs.getInt("id"));
			user.add(one);
		}
		
		return user;
	}
	
	//展示所有管理员
	public List<UserDetail> showAd(Connection con, int page) throws SQLException {
		List<UserDetail> user = new ArrayList<UserDetail>();
		String sql = "SELECT count(*) cnt from person WHERE position=1";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setId(rs.getInt("cnt"));
			user.add(one);
		}
		
		sql = "SELECT * from person WHERE position=1 ORDER BY time DESC LIMIT ?,7";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setUsername(rs.getString("nickname"));
			one.setUsermail(rs.getString("mail"));
			one.setUsermajor(rs.getString("major"));
			one.setUserpass("管理员");
			one.setUserword(rs.getString("word"));
			one.setId(rs.getInt("id"));
			user.add(one);
		}
		
		return user;
	}
	
	//展示所有教师
	public List<UserDetail> showTea(Connection con, int page) throws SQLException {
		List<UserDetail> user = new ArrayList<UserDetail>();
		String sql = "SELECT count(*) cnt from person WHERE position=2";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setId(rs.getInt("cnt"));
			user.add(one);
		}
		
		sql = "SELECT * from person WHERE position=2 ORDER BY time DESC LIMIT ?,7";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			UserDetail one = new UserDetail();
			one.setUsername(rs.getString("nickname"));
			one.setUsermail(rs.getString("mail"));
			one.setUsermajor(rs.getString("major"));
			one.setUserpass("教师");
			one.setUserword(rs.getString("word"));
			one.setId(rs.getInt("id"));
			user.add(one);
		}
		
		return user;
	}
	
	//身份改变
	public void changePosition(int id, int type, Connection con) throws SQLException {
		String sql = "update person set position=? where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, type);
		pstmt.setInt(2, id);
		pstmt.execute();
		
		return ;
	}
	
	//删除用户
	public void deleUser(int id, Connection con) throws SQLException {
		String sql = "delete from person where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
		
		return ;
	}
}
