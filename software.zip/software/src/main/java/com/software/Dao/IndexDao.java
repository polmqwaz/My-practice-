 package com.software.Dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.software.Pojo.Discuss;
import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Talk;
import com.software.Pojo.TalkTag;
import com.software.Pojo.UserSay;
import com.software.Pojo.WorkPic;

public interface IndexDao {
//论坛
	//计算所有话题总数（基于base：0无条件  1标签   2话题）
	public int sumTalk(Connection con, int type, String base) throws SQLException;
	//论坛页面加载（基于base：0无条件  1标签   2话题）
	public List<Talk> loadTalk(int num1, int type, String base, Connection con) throws SQLException;
	//热门话题加载
	public List<Talk> loadHotTalk(Connection con) throws SQLException;
	//单个话题详情页面加载	
	public List<Discuss> loadDiscuss(Connection con, int id, int page) throws SQLException;

//资源展示页面
	//评论加载
	public UserSay loadComment(Connection con, int id, int page) throws SQLException;
	//作品图文说明加载 
	public WorkPic showWorkPic(Connection con, int id, int num1) throws SQLException;
	
//公告	
	//全部公告加载
	public List<Notice> loadNotice(Connection con) throws SQLException;
	//单个公告加载
	public Notice loadOneNotice(Connection con, int id) throws SQLException;

//标签
	//资源一级标签加载
	public Lable loadTag(Connection con) throws SQLException;	
	//话题标签加载
	public TalkTag loadAllTag(Connection con) throws SQLException;
	
	
	

}
