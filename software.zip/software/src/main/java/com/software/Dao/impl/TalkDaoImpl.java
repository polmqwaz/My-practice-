package com.software.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.software.Dao.TalkDao;
import com.software.Pojo.Discuss;
import com.software.Pojo.Talk;

public class TalkDaoImpl implements TalkDao{

	//展示我的话题
	public List<Talk> showMyTalk(Connection con, int id, int page) throws SQLException {
		List<Talk> talk = new ArrayList<Talk>();
		String sql = "SELECT count(*) cnt from talk where talk.user_id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Talk one = new Talk();
			one.setId(rs.getInt("cnt"));
			talk.add(one);
		}
		
		sql = "SELECT talk.id, talk.title, talk.look, talk.reply, talk.time from talk where talk.user_id=? ORDER BY time DESC LIMIT ?,6";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Talk one = new Talk();
			one.setId(rs.getInt("id"));
			one.setTitle(rs.getString("title"));
			one.setLook(rs.getInt("look"));
			one.setReply(rs.getInt("reply"));
			one.setTime(rs.getString("time"));
			talk.add(one);
		}
		
		return talk;
	}
	
	//删除我的话题
	public void deleTalk(Connection con, int id) throws SQLException {
		String sql = "DELETE FROM talk where id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.execute();
		
		return ;
	}

	//加载今日话题
	public List<Talk> loadTodayTalk(Connection con, int page) throws SQLException {
		List<Talk> talk = new ArrayList<Talk>();
		String sql = "SELECT count(*) cnt from talk where id not in(select id from talk where time<curdate())";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Talk one = new Talk();
			one.setId(rs.getInt("cnt"));
			talk.add(one);
		}
		
		sql = "SELECT talk.id, title, talk.time, nickname from person, talk where talk.id not in(select id from talk where talk.time<curdate()) and talk.user_id=person.id ORDER BY talk.time DESC LIMIT ?,6";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();  
		while(rs.next()) {
			Talk one = new Talk();
			one.setId(rs.getInt("id"));
			one.setTitle(rs.getString("title"));
			one.setTime(rs.getString("time"));
			one.setUser(rs.getString("nickname"));
			talk.add(one);
		}
		
		return talk;
	}
	
	//加载所有话题
	public List<Talk> loadAllTalk(Connection con, int page) throws SQLException {
		List<Talk> talk = new ArrayList<Talk>();
		String sql = "SELECT count(*) cnt from talk";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Talk one = new Talk();
			one.setId(rs.getInt("cnt"));
			talk.add(one);
		}
			
		sql = "SELECT talk.id, title, talk.time, nickname from person, talk where talk.user_id=person.id ORDER BY talk.time DESC LIMIT ?,6";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Talk one = new Talk();
			one.setId(rs.getInt("id"));
			one.setTitle(rs.getString("title"));
			one.setTime(rs.getString("time"));
			one.setUser(rs.getString("nickname"));
			talk.add(one);
		}
			
		return talk;
	}
	
	//加载该话题中某一级话题（id）的二级话题
	public List<Discuss> loadLevel2(Connection con, int id) throws SQLException {
		List<Discuss> discuss = new ArrayList<Discuss>();
		String sql = "SELECT level2.id, nickname, img, level2.content, level2.reply, level2.time from level2, person where level2.level_id=? and level2.user_id=person.id ORDER BY level2.time";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next())
		{
			Discuss one = new Discuss();
			one.setId(rs.getInt("id"));
			one.setImg(rs.getString("img"));
			one.setUser(rs.getString("nickname"));
			one.setContent(rs.getString("content"));
			one.setReply(rs.getInt("reply"));
			one.setTime(rs.getString("time"));
			discuss.add(one);
		}
				
		return discuss;
	}
			
	//加载该话题中某二级话题（id）的三级话题
	public List<Discuss> loadLevel3(Connection con, int id) throws SQLException {
		List<Discuss> discuss = new ArrayList<Discuss>();
		String sql = "SELECT level3.id, p1.nickname n1, p2.nickname n2, p1.img, level3.content, level3.time from level3, person p1, person p2 where level3.level_id=? and level3.user_id=p1.id and level3.to_id=p2.id ORDER BY level3.time";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		while(rs.next())
		{
			Discuss one = new Discuss();
			one.setId(rs.getInt("id"));
			one.setImg(rs.getString("img"));
			one.setUser(rs.getString("n1"));
			one.setTitle(rs.getString("n2"));
			one.setContent(rs.getString("content"));
			one.setTime(rs.getString("time"));
			discuss.add(one);
		}
				
		return discuss;
	}
}
