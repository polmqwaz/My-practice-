package com.software.Dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.software.Dao.LoadDao;
import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Work;

public class LoadDaoImpl implements LoadDao{
	
	//按标签搜索
	public List<Work> searchTag(Connection con, int num, String Tag, String tag, String on) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		if(Tag.equals("全部")) {
			String sql = "select count(*) cnt from software";
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				Work one = new Work();
				one.setId(rs.getInt("cnt"));
				work.add(one);
			}
			 
			sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person where software.user_id=person.id order by software." + on + " desc LIMIT ?,7";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num*7);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Work one = new Work();
				one.setName(rs.getString("work_name"));
				one.setUser(rs.getString("nickname"));
				one.setId(rs.getInt("id"));
				one.setDescribe(rs.getString("work_describe"));
				one.setGood(rs.getInt("goodnum"));
				one.setDown(rs.getInt("downnum"));
				one.setWorkimg(rs.getString("img"));
				one.setTime(rs.getString("time"));
				work.add(one);
			}
		} else {
			if(tag.equals("全部")) {
				String sql = "select count(*) cnt from software, lable, Blable where software.lable_id=lable.id and lable.Bid=Blable.id and Blable.tag=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setString(1, Tag);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					Work one = new Work();
					one.setId(rs.getInt("cnt"));
					work.add(one);
				}
				
				sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, lable, Blable, person where software.user_id=person.id and software.lable_id=lable.id and lable.Bid=Blable.id and Blable.tag=? order by software." + on + " desc LIMIT ?,7";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, Tag);
				pstmt.setInt(2, num*7);
				rs = pstmt.executeQuery();
				while(rs.next()) {
					Work one = new Work();
					one.setName(rs.getString("work_name"));
					one.setUser(rs.getString("nickname"));
					one.setId(rs.getInt("id"));
					one.setDescribe(rs.getString("work_describe"));
					one.setGood(rs.getInt("goodnum"));
					one.setDown(rs.getInt("downnum"));
					one.setWorkimg(rs.getString("img"));
					one.setTime(rs.getString("time"));
					work.add(one);
				}
			} else {
				String sql = "select count(*) cnt from software, lable, Blable where lable.Bid=blable.id and software.lable_id=lable.id and lable.tag=? and blable.tag=?";
				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setString(1, tag);
				pstmt.setString(2, Tag);
				ResultSet rs = pstmt.executeQuery();
				while(rs.next()) {
					Work one = new Work();
					one.setId(rs.getInt("cnt"));
					work.add(one);
				}
				
				sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person, lable, Blable where lable.Bid=blable.id and software.lable_id=lable.id and software.user_id=person.id and lable.tag=? and blable.tag=? order by software." + on + " desc LIMIT ?,7";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, tag);
				pstmt.setString(2, Tag);
				pstmt.setInt(3, num*7);
				rs = pstmt.executeQuery();
				while(rs.next()) {
					Work one = new Work();
					one.setName(rs.getString("work_name"));
					one.setUser(rs.getString("nickname"));
					one.setId(rs.getInt("id"));
					one.setDescribe(rs.getString("work_describe"));
					one.setGood(rs.getInt("goodnum"));
					one.setDown(rs.getInt("downnum"));
					one.setWorkimg(rs.getString("img"));
					one.setTime(rs.getString("time"));
					work.add(one);
				}
			}
			
		}
		
		return work;
	}
	
	//按标签和关键字搜索
	public List<Work> searchTag(Connection con, int num, String value[], String on) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String Tag = value[0];	
		String tag = value[1];
		String str = "";
		for(int i = 2; i < value.length; i++) {
			str += " and software.id in (select software.id from software, keyword, relationkey where software.id=relationkey.work_id and relationkey.tag_id=keyword.id and keyword.tag like '%" + value[i] + "%'";
		}
		for(int i = 2; i < value.length; i++) {
			str += ")";
		}
		String sql = "select count(*) cnt from software, person, lable, Blable WHERE lable.Bid=Blable.id and Blable.tag='" + Tag + "' and lable.tag='" + tag + "' and lable.id=software.lable_id and software.user_id=person.id" + str;
		if(Tag.equals("全部")) {
			sql = "select count(*) cnt from software, person where software.user_id=person.id" + str;
		} else {
			if(tag.equals("全部")) {
				sql = "select count(*) cnt from software, person, lable, Blable where lable.Bid=Blable.id and Blable.tag='" + Tag + "' and software.user_id=person.id" + str;
			}
		}
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person, lable, Blable WHERE lable.Bid=Blable.id and Blable.tag='" + Tag + "' and lable.tag='" + tag + "' and lable.id=software.lable_id and software.user_id=person.id" + str + "order by software." + on + " desc LIMIT ?,7";
		if(Tag.equals("全部")) {
			sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person where software.user_id=person.id" + str + "order by software." + on + " desc LIMIT ?,7";
		} else {
			if(tag.equals("全部")) {
				sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person, Blable, lable where software.lable_id=lable.id and lable.Bid=Blable.id and Blable.tag='" + Tag + "' and software.user_id=person.id" + str + "order by software." + on + " desc LIMIT ?,7";
			}
		}
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, num*7);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setUser(rs.getString("nickname"));
			one.setId(rs.getInt("id"));
			one.setDescribe(rs.getString("work_describe"));
			one.setGood(rs.getInt("goodnum"));
			one.setDown(rs.getInt("downnum"));
			one.setWorkimg(rs.getString("img"));
			one.setTime(rs.getString("time"));
			work.add(one);
		}
		
		return work;
	}
	
	//按用户名搜索
	public List<Work> searchUser(Connection con, String value, int num, String on, int id) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		
		String sql = "select count(*) cnt from software, person WHERE software.user_id=person.id and person.nickname LIKE '%" + value + "%'";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person WHERE software.user_id=person.id and person.nickname LIKE '%" + value + "%' order by software." + on + " desc LIMIT ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, num*id);
		pstmt.setInt(2, id);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setUser(rs.getString("nickname"));
			one.setId(rs.getInt("id"));
			one.setDescribe(rs.getString("work_describe"));
			one.setGood(rs.getInt("goodnum"));
			one.setDown(rs.getInt("downnum"));
			one.setWorkimg(rs.getString("img"));
			one.setTime(rs.getString("time"));
			work.add(one);
		}
		
		return work;
	}
	
	//按作品名搜索
	public List<Work> searchWork(Connection con, String value, int num, String on) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		
		String sql = "select count(*) cnt from software, person WHERE software.user_id=person.id and work_name LIKE '%" + value + "%'";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person WHERE software.user_id=person.id and work_name LIKE '%" + value + "%' order by software." + on + " desc LIMIT ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, num*5);
		pstmt.setInt(2, 5);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setUser(rs.getString("nickname"));
			one.setId(rs.getInt("id"));
			one.setDescribe(rs.getString("work_describe"));
			one.setGood(rs.getInt("goodnum"));
			one.setDown(rs.getInt("downnum"));
			one.setWorkimg(rs.getString("img"));
			one.setTime(rs.getString("time"));
			work.add(one);
		}
			
		return work;
	}
	
	//按关键字搜索
	public List<Work> searchKey(Connection con, String value, int num, String on) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String[] item=value.split(" ");
		String str = "";
		for(int i = 0; i < item.length; i++) {
			str += " and software.id in (select software.id from software, keyword, relationkey where software.id=relationkey.work_id and relationkey.tag_id=keyword.id and keyword.tag like '%" + item[i] + "%'";
		}
		for(int i = 0; i < item.length; i++) {
			str += ")";
		}
		String sql = "select count(*) cnt from software, person WHERE software.user_id=person.id" + str;
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person WHERE software.user_id=person.id" + str + " order by software." + on + " desc LIMIT ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, num*5);
		pstmt.setInt(2, 5);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setUser(rs.getString("nickname"));
			one.setId(rs.getInt("id"));
			one.setDescribe(rs.getString("work_describe"));
			one.setGood(rs.getInt("goodnum"));
			one.setDown(rs.getInt("downnum"));
			one.setWorkimg(rs.getString("img"));
			one.setTime(rs.getString("time"));
			work.add(one);
		}
				
		return work;
	}
	
	//按描述搜索
	public List<Work> searchDes(Connection con, String value, int num, String on) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		
		String[] item=value.split(" ");
		String str = "";
		for(int i = 0; i < item.length; i++) {
			str += "%" + item[i];
		}
		str += "%";
		String sql = "select count(*) cnt from software, person WHERE software.user_id=person.id and software.work_describe like '" + str;
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		sql = "select software.id, work_name, nickname, work_describe, downnum, goodnum, software.img, software.time from software, person WHERE software.user_id=person.id and software.work_describe like '" + str + "' order by software." + on + " desc LIMIT ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, num*5);
		pstmt.setInt(2, 5);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setUser(rs.getString("nickname"));
			one.setId(rs.getInt("id"));
			one.setDescribe(rs.getString("work_describe"));
			one.setGood(rs.getInt("goodnum"));
			one.setDown(rs.getInt("downnum"));
			one.setWorkimg(rs.getString("img"));
			one.setTime(rs.getString("time"));
			work.add(one);
		}
				
		return work;
	}
		
	//加载该用户已通过作品
	public List<Work> loadMywork(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "select count(*) cnt from software where user_id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		sql = "SELECT * from software where user_id=? order by updatetime DESC limit ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page*6);
		pstmt.setInt(3, 6);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setDown(rs.getInt("downnum"));
			one.setGood(rs.getInt("goodnum"));
			one.setTime(rs.getString("time"));
			one.setUpdatetime(rs.getString("updatetime"));
			one.setId(rs.getInt("id"));
			work.add(one);
		}
		
		return work;
	}
	//加载该用户待更新的作品
	public List<Work> loadMyupdatework(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "SELECT count(*) cnt from updatework, software WHERE updatework.work_id=software.id and software.user_id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		
		sql = "SELECT updatework.id, work_name, tag, updatework.time, status from updatework, software, lable where updatework.work_id=software.id and software.user_id=? and software.lable_id=lable.id order by updatework.time DESC limit ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page*6);
		pstmt.setInt(3, 6);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setTime(rs.getString("time"));
			one.setId(rs.getInt("id"));
			one.setSelftag(rs.getString("tag"));
			one.setGood(rs.getInt("status"));
			work.add(one);
		}
		
		return work;
	}
		
	//加载该用户待审核的作品
	public List<Work> loadMywaitwork(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "SELECT count(*) cnt from temwork WHERE user_id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		
		sql = "SELECT temwork.id, temwork.work_name, tag, temwork.time, status from temwork, lable where temwork.lable_id=lable.id and temwork.user_id=? order by temwork.time DESC limit ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page*6);
		pstmt.setInt(3, 6);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setTime(rs.getString("time"));
			one.setId(rs.getInt("id"));
			one.setSelftag(rs.getString("tag"));
			one.setGood(rs.getInt("status"));
			work.add(one);
		}
			
		return work;
	}
		
	//加载该用户未通过的作品
	public List<Work> loadMynotpasswork(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "SELECT count(*) cnt from delework, person WHERE delework.user=person.nickname and person.id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
			
					
		sql = "select delework.id, work_name, delework.time, type, lable from delework, person WHERE delework.user=person.nickname and person.id=? ORDER BY delework.time LIMIT ?,?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page*6);
		pstmt.setInt(3, 6);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setName(rs.getString("work_name"));
			one.setTime(rs.getString("time"));
			one.setId(rs.getInt("id"));
			one.setLable(rs.getString("lable"));
			one.setSelftag(rs.getString("type"));
			work.add(one);
		}
					
		return work;
	}
	
	//获取要更新作品的基本信息
	public Work loadworkUpdate(Connection con, String name, int id) throws SQLException {
		Work work = new Work();
		String sql = "select * from software where work_name=? and user_id=?";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1, name);
		pstmt.setInt(2, id);
		ResultSet rs = pstmt.executeQuery();
		if(rs.next()) {
			work.setName(rs.getString("work_name"));
			work.setOs(rs.getString("os"));
			work.setWorkimg(rs.getString("img"));
		}
					
		return work;
	}
	
	//加载用户已下载的工具
	public List<Work> loadMydownwork(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "select count(work_name) cnt from download, software, person, lable where download.user_id=? and download.work_id=software.id and software.user_id=person.id and software.lable_id=lable.id";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		} 
			
		page = page*6;
		sql = "select download.id, download.time, software.id workId, work_name, nickname, tag, mark.grade from download, software, person, lable, mark where download.user_id=? and software.id=download.work_id and software.user_id=person.id and lable.id=software.lable_id and mark.work_id=software.id and mark.user_id=download.user_id ORDER BY download.time desc LIMIT ?,6";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("id"));
			one.setDown(rs.getInt("workId"));  
			one.setName(rs.getString("work_name"));
			one.setUser(rs.getString("nickname"));
			one.setLable(rs.getString("tag"));
			one.setTime(rs.getString("time"));
			one.setGood(rs.getInt("grade"));
			work.add(one);
		}
		
		return work;
	}
	
	//加载用户收藏的工具
	public List<Work> loadMylovework(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		String sql = "select count(work_name) cnt from collection, software, person, lable where collection.user_id=? and collection.work_id=software.id and software.user_id=person.id and software.lable_id=lable.id";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("cnt"));
			work.add(one);
		}
		
		page = page*6;
		sql = "select collection.id, work_name, nickname, tag, collection.time from collection, software, person, lable where collection.user_id=? and collection.work_id=software.id and software.user_id=person.id and software.lable_id=lable.id ORDER BY collection.time desc LIMIT ?,6";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, id);
		pstmt.setInt(2, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Work one = new Work();
			one.setId(rs.getInt("id"));
			one.setName(rs.getString("work_name"));
			one.setUser(rs.getString("nickname"));
			one.setLable(rs.getString("tag"));
			one.setTime(rs.getString("time"));
			work.add(one);
			
		}
		
		return work;
	}
	//二级标签加载
	public Lable getTag(Connection con, int id) throws SQLException {
		Lable tag = new Lable();
		String sql = "select id, tag from lable where Bid=? ORDER BY id DESC";
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1, id);
		ResultSet rs=pstmt.executeQuery();
		int count = 0;
		while(rs.next()) {
			tag.setValue(rs.getInt("id"), count);
			tag.setLable(rs.getString("tag"), count);
			count++;
		}
		tag.setNum(count);
		return tag;
	}
	
	//管理员
	//加载今日公告
	public List<Notice> loadTodayNotice(Connection con, int page) throws SQLException{
		List<Notice> notice = new ArrayList<Notice>();
		String sql = "select count(*) cnt from notices where notices.time>date_sub(curdate(),interval 1 day)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Notice one = new Notice();
			one.setId(rs.getInt("cnt"));
			notice.add(one);
		}
		
		sql = "select notices.id, title, content, notices.time, nickname from notices, person where notices.time>date_sub(curdate(),interval 1 day) and person.id=writer ORDER BY time desc LIMIT ?,6";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Notice one = new Notice(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("time"), rs.getString("nickname"));
			notice.add(one);
		}
		
		return notice;
	}
	
	//加载所有公共
	public List<Notice> loadAllNotice(Connection con, int page) throws SQLException {
		List<Notice> notice = new ArrayList<Notice>();
		String sql = "select count(*) cnt from notices";
		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			Notice one = new Notice();
			one.setId(rs.getInt("cnt"));
			notice.add(one);
		}
		
		sql = "select notices.id, title, content, notices.time, nickname from notices, person where person.id=writer ORDER BY time desc LIMIT ?,6";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, page);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			Notice one = new Notice(rs.getInt("id"), rs.getString("title"), rs.getString("content"), rs.getString("time"), rs.getString("nickname"));
			notice.add(one);
		}
		
		return notice;
	}
}
