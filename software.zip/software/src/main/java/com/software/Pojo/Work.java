package com.software.Pojo;

public class Work {
	private int id;
	private String name;
	private String user;
	private String addr;
	private String describe;
	private String time;
	private String updatetime;
	private int down;
	private int good;
	private float grade;
	private String workimg;
	private String userimg;
	private String lable;
	private String os;
	private String selftag;
	private String[] tag = new String[30];
	private int tagnum;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getDescribe() {
		return describe;
	}
	public void setDescribe(String describe) {
		this.describe = describe;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getDown() {
		return down;
	}
	public void setDown(int down) {
		this.down = down;
	}
	public int getGood() {
		return good;
	}
	public void setGood(int good) {
		this.good = good;
	}
	public float getGrade() {
		return grade;
	}
	public void setGrade(float grade) {
		this.grade = grade;
	}
	public String getLable() {
		return lable;
	}
	public void setLable(String lable) {
		this.lable = lable;
	}
	public String getUserimg() {
		return userimg;
	}
	public void setUserimg(String userimg) {
		this.userimg = userimg;
	}
	public String getWorkimg() {
		return workimg;
	}
	public void setWorkimg(String workimg) {
		this.workimg = workimg;
	}
	public String getUpdatetime() {
		return updatetime;
	}
	public void setUpdatetime(String updatetime) {
		this.updatetime = updatetime;
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public String getSelftag() {
		return selftag;
	}
	public void setSelftag(String selftag) {
		this.selftag = selftag;
	}
	
	public Work(int id, String name, String user, String addr, String describe, String time, String updatetime,
			int down, int good, float grade, String workimg, String userimg, String lable, String os, String selftag) {
		super();
		this.id = id;
		this.name = name;
		this.user = user;
		this.addr = addr;
		this.describe = describe;
		this.time = time;
		this.updatetime = updatetime;
		this.down = down;
		this.good = good;
		this.grade = grade;
		this.workimg = workimg;
		this.userimg = userimg;
		this.lable = lable;
		this.os = os;
		this.selftag = selftag;
	}
	public Work() {
		super();
	}
	
	public String getTag(int x) {
		return tag[x];
	}
	public void setTag(String item, int x) {
		this.tag[x] = item;
	}
	public int getTagnum() {
		return tagnum;
	}
	public void setTagnum(int tagnum) {
		this.tagnum = tagnum;
	}
	
}
