package com.software.Pojo;

public class Talk {
	private int id;
	private String title;
	private String user;
	private String img;
	private String content;
	private String time;
	private int look;
	private int reply;
	private TalkTag tag = new TalkTag();
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getLook() {
		return look;
	}
	public void setLook(int look) {
		this.look = look;
	}
	public int getReply() {
		return reply;
	}
	public void setReply(int reply) {
		this.reply = reply;
	}
	public Talk(String title, String user, String content, String time, int look, int reply) {
		super();
		this.title = title;
		this.user = user;
		this.content = content;
		this.time = time;
		this.look = look;
		this.reply = reply;
	}
	public Talk() {
		super();
	}
	public TalkTag getTag() {
		return tag;
	}
	public void setTag(TalkTag tag) {
		this.tag = tag;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	
	
}
