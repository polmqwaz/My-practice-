package com.software.Pojo;

public class WorkPic {
	private String[] pic = new String[20];
	private String[] des = new String[20];
	private String[] tit = new String[20];
	private int[] size = new int[20];
	private int count;
	private int sum;
	
	public String getPic(int num) {
		return pic[num];
	}
	public void setPic(String name, int num) {
		this.pic[num] = name;
	}
	public String getDes(int num) {
		return des[num];
	}
	public void setDes(String describe, int num) {
		this.des[num] = describe;
	}
	public String getTit(int num) {
		return tit[num];
	}
	public void setTit(String title, int num) {
		this.tit[num] = title;
	}
	public int getSize(int num) {
		return size[num];
	}
	public void setSize(int x, int num) {
		this.size[num] = x;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public WorkPic() {
		super();
	}
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	
}
