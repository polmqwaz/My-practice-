package com.software.Pojo;

import java.util.ArrayList;
import java.util.List;

public class UserSay {
	private int[] id = new int[15];
	private String[] user = new String[15];
	private String[] content = new String[15];
	private int[] rnum = new int[15];
	private String[] time = new String[15];
	List<UserPly> reply = new ArrayList<UserPly>();
	private int num;
	private int sum;
	public int getId(int x) {
		return id[x];
	}
	public void setId(int t, int x) {
		this.id[x] = t;
	}
	public String getUser(int x) {
		return user[x];
	}
	public void setUser(String name, int x) {
		this.user[x] = name;
	}
	public String getContent(int x) {
		return content[x];
	}
	public void setContent(String con, int x) {
		this.content[x] = con;
	}
	public int getRnum(int x) {
		return rnum[x];
	}
	public void setRnum(int t, int x) {
		this.rnum[x] = t;
	}
	public String getTime(int x) {
		return time[x];
	}
	public void setTime(String t, int x) {
		this.time[x] = t;
	}
	public UserPly getReply(int x) {
		return reply.get(x);
	}
	public int getReplySize() {
		return reply.size();
	}
	public void setReply(UserPly r) {
		this.reply.add(r);
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public UserSay() {
		super();
	}
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	
}
