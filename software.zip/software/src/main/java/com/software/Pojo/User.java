package com.software.Pojo;

public class User {
	private int position;
	private String name;
	private String pass;
	private String word;
	private String img;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public int getPosition() {
		return position;
	}
	public void setPosition(int position) {
		this.position = position;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public User(String name, String word, String img) {
		super();
		this.name = name;
		this.word = word;
		this.img = img;
	}
	public User(int position, String name, String pass) {
		super();
		this.position = position;
		this.name = name;
		this.pass = pass;
	}
	public User(int position, String name, String pass, String word) {
		super();
		this.position = position;
		this.name = name;
		this.pass = pass;
		this.word = word;
	}
	public User(){}
}
