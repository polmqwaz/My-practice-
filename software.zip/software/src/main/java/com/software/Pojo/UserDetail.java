package com.software.Pojo;

public class UserDetail {
	private int id;
	private String username;
	private String userpass;
	private String usermail;
	private String userword;
	private String usermajor;
	private String position;
	private String img;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpass() {
		return userpass;
	}
	public void setUserpass(String userpass) {
		this.userpass = userpass;
	}
	public String getUsermail() {
		return usermail;
	}
	public void setUsermail(String usermail) {
		this.usermail = usermail;
	}
	public String getUserword() {
		return userword;
	}
	public void setUserword(String userword) {
		this.userword = userword;
	}
	public String getUsermajor() {
		return usermajor;
	}
	public void setUsermajor(String usermajor) {
		this.usermajor = usermajor;
	}
	public UserDetail(String username, String userpass, String usermajor, String usermail, String userword) {
		super();
		this.username = username;
		this.userpass = userpass;
		this.usermajor = usermajor;
		this.usermail = usermail;
		this.userword = userword;
	}
	public UserDetail(){}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
}
