package com.software.Pojo;

public class Lable {
	private int num;
	private String[] lable = new String[30];
	private int[] value = new int[30];
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getLable(int x) {
		return lable[x];
	}
	public void setLable(String tag, int x) {
		this.lable[x] = tag;
	}
	public int getValue(int x) {
		return value[x];
	}
	public void setValue(int v, int x) {
		this.value[x] = v;
	}
	
}
