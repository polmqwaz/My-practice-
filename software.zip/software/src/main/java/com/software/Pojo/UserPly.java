package com.software.Pojo;

public class UserPly {
	private String[] from = new String[20];
	private String[] to = new String[20];
	private String[] content = new String[20];
	private String[] time = new String[20];
	private int num;
	public String getFrom(int x) {
		return from[x];
	}
	public void setFrom(String name, int x) {
		this.from[x] = name;
	}
	public String getTo(int x) {
		return to[x];
	}
	public void setTo(String name, int x) {
		this.to[x] = name;
	}
	public String getContent(int x) {
		return content[x];
	}
	public void setContent(String con, int x) {
		this.content[x] = con;
	}
	public String getTime(int x) {
		return time[x];
	}
	public void setTime(String t, int x) {
		this.time[x] = t;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	public UserPly() {
		super();
	}
}
