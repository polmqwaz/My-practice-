package com.software.Pojo;

public class TalkTag {
	private int cnt;
	private String[] img = new String[50];
	private int[] id = new int[50];
	private String[] tag = new String[50];
	public int getId(int x) {
		return id[x];
	}
	public void setId(int id, int x) {
		this.id[x] = id;
	}
	public String getTag(int x) {
		return tag[x];
	}
	public void setTag(String tag, int x) {
		this.tag[x] = tag;
	}
	public TalkTag() {
		super();
	}
	public int getCnt() {
		return cnt;
	}
	public void setCnt(int cnt) {
		this.cnt = cnt;
	}
	public String getImg(int x) {
		return img[x];
	}
	public void setImg(String img, int x) {
		this.img[x] = img;
	}
	
	
}
