package com.software.Servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadBase;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.software.Pojo.Work;
import com.software.Service.WorkService;
import com.software.Service.impl.WorkServiceImpl;
import com.software.util.DbUtil;

/**
 * Servlet implementation class UpdateHandleServlet
 */
public class UpdateHandleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DbUtil dbUtil = new DbUtil();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateHandleServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private String makeFileName(String filename){ 
    	int max=1000;
        Random random = new Random();

        int s = random.nextInt(max);
        String name = s + "_" + filename;
        return name;
    }


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		if (username == null) {
			response.sendRedirect("/software/html/login.html");
		} else {
			Work work = new Work();
	        String[] data = new String[20];
	        String[] dataname = new String[20];
	        String[] pic = new String[20];
	        String[] picdes = new String[20];
	        String[] size = new String[20];
	        String[] title = new String[20];
	        int count = 0, num = 0;
	        Connection con;
			
	        String savePath = this.getServletContext().getRealPath("/WEB-INF/TemWork");
			String picPath = this.getServletContext().getRealPath("/TemPic");
	        String tempPath = this.getServletContext().getRealPath("/WEB-INF/temp");
	        File tmpFile = new File(tempPath);
	        if (!tmpFile.exists()) {
	            tmpFile.mkdir();
	        }
	        try {
	            DiskFileItemFactory factory = new DiskFileItemFactory();
	            factory.setSizeThreshold(1024*100);
	            factory.setRepository(tmpFile);
	            ServletFileUpload upload = new ServletFileUpload(factory);
//	            upload.setProgressListener(new ProgressListener(){
//	                public void update(long pBytesRead, long pContentLength, int arg2) {
//	                    System.out.println("文件大小为：" + pContentLength + ",当前已处理：" + pBytesRead);
//	                }
//	            });
	            upload.setFileSizeMax(1024*1024*20);  //单文件最大20M
	            upload.setSizeMax(1024*1024*100);  //文件总和为100M
	            upload.setHeaderEncoding("UTF-8"); 
	            @SuppressWarnings("unchecked")
	            List<FileItem> list = upload.parseRequest(request);
				for(FileItem item : list){
		            if(item.isFormField()){
		                String valuename = item.getFieldName();
		                String value = item.getString("UTF-8");
		                dataname[count] = valuename;
		                data[count] = value;
		                count++;
		            }else{
		            	String filetype = item.getFieldName();
		                String filename = item.getName();
		                if(filename==null || filename.trim().equals("")){
		                    continue;
		                }
		                filename = filename.substring(filename.lastIndexOf("\\")+1);
		              //扩展名 String fileExtName = filename.substring(filename.lastIndexOf(".")+1);
		                InputStream in = item.getInputStream();
		                if(filetype.equals("uploadwork")) {
		                	filename = makeFileName(filename);
		                	FileOutputStream out = new FileOutputStream(savePath + "\\" + filename);
		                	work.setAddr(filename);
		                	byte buffer[] = new byte[1024];
			                int len = 0;
			                while((len=in.read(buffer))>0){
			                    out.write(buffer, 0, len);
			                }
			                in.close();
			                out.close();
			                item.delete();
		                } else {
		                	filename = makeFileName(filename);
		                	FileOutputStream out = new FileOutputStream(picPath + "\\" + filename);
		                	pic[num] = filename;
		                	num++;
		                	byte buffer[] = new byte[1024];
			                int len = 0;
			                while((len=in.read(buffer))>0){
			                    out.write(buffer, 0, len);
			                }
			                in.close();
			                out.close();
			                item.delete();
		                } 
		            }
		        }
	        }catch (FileUploadBase.FileSizeLimitExceededException e) {
	        	e.printStackTrace();
	            System.out.println("单个文件超出最大值！！！");
	            return;
	        }catch (FileUploadBase.SizeLimitExceededException e) {
	            e.printStackTrace();
	            System.out.println("上传文件的总的大小超出限制的最大值！！！");
	            return;
	        }catch (Exception e) {
	            e.printStackTrace();
	        }
	        
	        work.setUser(username);
				
			int x = 0, y = 0, z = 0;
			for(int i = 0; i < count; i++) {
				if(dataname[i].equals("workname")) {
					work.setName(data[i]);
					continue;
				}
				if(dataname[i].equals("workos")) {
					work.setOs(data[i]);
					continue;
				}
				if(dataname[i].equals("workdes")) {
					work.setDescribe(data[i]);
					continue;
				}
				if(dataname[i].indexOf("picsize") != -1) {
					size[y] = data[i];
					y++;
					continue;
				}
				if(dataname[i].indexOf("title") != -1) {
					title[z] = data[i];
					z++;
					continue;
				}
				if(dataname[i].indexOf("picdes") != -1) {
					picdes[x] = data[i];
					x++;
				}
			}
			WorkService workService = new WorkServiceImpl();
				
			try {
				con = dbUtil.getCon();
				workService.updatework(work, num, pic, size, picdes, title, con);
				dbUtil.closeCon(con);
				
				response.sendRedirect("/software/html/myself_mywork.html");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
