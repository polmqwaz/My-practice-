package com.software.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.software.Pojo.User;
import com.software.Pojo.UserDetail;
import com.software.Service.UserService;
import com.software.Service.impl.UserServiceImpl;
import com.software.util.DbUtil;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DbUtil dbUtil = new DbUtil();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private void userLogin(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException {
    	int id = 0;
    	request.setCharacterEncoding("utf-8");
		String name = request.getParameter("name");
		String pass = request.getParameter("pass");
		int position = 0;
		String flag = request.getParameter("flag");
		if("ad".equals(flag)) {	
			position = 1;
		}else {
			position = 0;
		}
		try {
			Connection con = dbUtil.getCon();
			
			User user = new User(position, name, pass);
			UserService userService = new UserServiceImpl();
			id = userService.userLogin(user, con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(id != 0)
		{
			HttpSession session = request.getSession();
            session.setAttribute("name", name);
            session.setAttribute("id", id);
		}
		
		try {
			Boolean ans = false;
			if(id != 0) {
				ans = true;
			} else {
				ans = false;
			}
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter out = response.getWriter();
			if(position == 1) {
				if(ans) {
					response.sendRedirect("/software/html/ad_deal_work.html");
				} else {
					response.sendRedirect("/software/html/ad_login.html?ans=登陆失败");
				}
			} else {
				out.print("[");
				String msg = "{\"ans\":\"" + ans + "\"}";
				out.print(msg);
				out.print("]");
			}
			out.flush();
			out.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }
    
    private void usernameCheck(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String name = request.getParameter("name");
    	
    	Connection con;
    	Boolean ans = true;
    	UserService userService = new UserServiceImpl();
    	try {
			con = dbUtil.getCon();
			ans = userService.checkUserName(name, con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"ans\":\"" + ans + "\"";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    	
    }
    
    private void userRegister(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	
		try {
			Connection con = dbUtil.getCon();
			request.setCharacterEncoding("utf-8");
			String name = request.getParameter("username");
			String pass = request.getParameter("userpass");
			String major = request.getParameter("usermajor");
			String mail = request.getParameter("usermail");
			String word = request.getParameter("userword");
			System.out.println(name);
			UserDetail detail = new UserDetail(name, pass, major, mail,word);
			UserService userService = new UserServiceImpl();
			userService.userRegisiter(detail, con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.sendRedirect("/software/html/login.html?ans=true");
    }
    
    private void userUpdate(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	Boolean ans = false;
    	request.setCharacterEncoding("utf-8");
    	UserDetail user = new UserDetail();
    	HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		if (username != null) {
			ans = true;
			int id = (Integer) session.getAttribute("id");
			UserService userService = new UserServiceImpl();
			Connection con;
			try {
				con = dbUtil.getCon();
				user = userService.userDetail(id, con);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"ans\":\"" + ans + "\"";
		if(ans) {
			msg += ",";
			msg += "\"name\": \"" + user.getUsername() + "\"," + 
					"\"major\": \"" + user.getUsermajor() + "\"," +
					"\"mail\": \"" + user.getUsermail() + "\"," +
					"\"word\": \"" + user.getUserword() + "\"," +
					"\"img\": \"" + user.getImg() + "\"," +
					"\"pass\": \"" + user.getUserpass() + "\"";
		}
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
		
    }
    
    private void UpdateNow(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	UserDetail user = new UserDetail();
    	
    	HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
    	if (username != null) {
			user.setUsername(request.getParameter("name"));
	    	user.setUsermajor(request.getParameter("major"));
	    	user.setUsermail(request.getParameter("mail"));
	    	user.setUserword(request.getParameter("word"));
			user.setId((Integer) session.getAttribute("id"));
			UserService userService = new UserServiceImpl();
			Connection con;
			try {
				con = dbUtil.getCon();
				userService.updateUser(user, con);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.sendRedirect("/software/html/myself_update.html?ans=1");
		} else {
			response.sendRedirect("/software/html/login.html");
		}
		
    }
    
    private void changePass(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String pass = request.getParameter("pass");
    	Boolean ans = false;
    	HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
    	if (username != null) {
			ans = true;
			int id = (Integer) session.getAttribute("id");
			UserService userService = new UserServiceImpl();
			Connection con;
			try {
				con = dbUtil.getCon();
				userService.changePass(pass, id, con);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"ans\":\"" + ans + "\"";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void showUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int type = Integer.parseInt(request.getParameter("limit"));
    	int page = Integer.parseInt(request.getParameter("page"));
    	
    	Connection con;
    	List<UserDetail> user = new ArrayList<UserDetail>();
    	UserService userService = new UserServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			user = userService.showUser(con, type, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"sum\": " + user.get(0).getId() + ",";
		msg += "\"user\":[";
		for(int i = 1; i < user.size(); i++) {
			
			if(i > 1) {
				msg += ",";
			}
			msg += "{\"name\": \"" + user.get(i).getUsername() + "\"," + 
					"\"major\": \"" + user.get(i).getUsermajor() + "\"," +
					"\"mail\": \"" + user.get(i).getUsermail() + "\"," +
					"\"word\": \"" + user.get(i).getUserword() + "\"," +
					"\"id\": \"" + user.get(i).getId() + "\"," +
					"\"position\": \"" + user.get(i).getUserpass() + "\"}";
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void changePosition(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int position = Integer.parseInt(request.getParameter("position"));
    	int id = Integer.parseInt(request.getParameter("id"));
    	
    	Connection con;
    	UserService userService = new UserServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			userService.changePosition(id, position, con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"ans\":\"true\"";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void deleUser(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	
    	Connection con;
    	UserService userService = new UserServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			userService.deleUser(id, con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"ans\":\"true\"";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void showNav(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	HttpSession session = request.getSession();
		String username = (String) session.getAttribute("name");
		if(username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.print("{");
			String msg = "\"status\": 0";      //0 用户未登陆    1 管理员   2 教师
			out.print(msg);
			out.print("}");
			out.flush();
			out.close();
			
			return ;
		}
		int id = (Integer) session.getAttribute("id");
		int position = 0;
		Connection con;
		UserService userService = new UserServiceImpl();
		try {
			con = dbUtil.getCon();
			position = userService.getPosition(con, id);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"status\": " + position + "";      //0 用户未登陆    1 管理员   2 教师
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
		
		return ;
		
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String type = request.getParameter("type");
		
		//登陆
		if(type.equals("login")) {
			userLogin(request, response);
			return ;
		}
		//注册--用户名检查
		if(type.equals("check")) {
			usernameCheck(request, response);
			return ;
		}
		//注册
		if(type.equals("register")) {
			userRegister(request, response);
			return ;
		}
		//个人--用户信息
		if(type.equals("userUpdate")) {
			userUpdate(request, response);
			return ;
		}
		//个人--用户信息更改
		if(type.equals("UpdateNow")) {
			UpdateNow(request, response);
			return ;
		}
		//个人--用户密码更改
		if(type.equals("changePass")) {
			changePass(request, response);
			return ;
		}
		
//ad
		//页面目录加载
		if(type.equals("nav")) {
			showNav(request, response);
			return ;
		}
		//用户管理加载
		if(type.equals("show")) {
			showUser(request, response);
			return ;
		}
		//用户管理加载--更改身份
		if(type.equals("position")) {
			changePosition(request, response);
			return ;
		}
		//用户管理加载--删除
		if(type.equals("dele")) {
			deleUser(request, response);
			return ;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
