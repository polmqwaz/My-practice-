package com.software.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Talk;
import com.software.Pojo.TalkTag;
import com.software.Pojo.UserDetail;
import com.software.Pojo.UserSay;
import com.software.Pojo.Work;
import com.software.Pojo.WorkPic;
import com.software.Service.IndexService;
import com.software.Service.LoadService;
import com.software.Service.UserService;
import com.software.Service.WorkService;
import com.software.Service.impl.IndexServiceImpl;
import com.software.Service.impl.LoadServiceImpl;
import com.software.Service.impl.UserServiceImpl;
import com.software.Service.impl.WorkServiceImpl;
import com.software.util.DbUtil;

/**
 * Servlet implementation class LoadServlet
 */
public class LoadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DbUtil dbUtil=new DbUtil();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoadServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private void loadingAdTalk(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int type = Integer.parseInt(request.getParameter("type"));
    	int page = Integer.parseInt(request.getParameter("num"));
    	
    	Connection con;
    	List<Talk> talk = new ArrayList<Talk>();
    	LoadService loadService = new LoadServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			talk = loadService.loadTalk(con, type, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"sum\": " + talk.get(0).getId() + ",";
		out.print(msg);
		msg = "\"talk\":[";
		for(int i = 1; i < talk.size(); i++) {
			msg += "{\"id\":\"" + talk.get(i).getId() + "\"," +
				   "\"title\":\"" + talk.get(i).getTitle() + "\"," +
				   "\"user\":\"" + talk.get(i).getUser() + "\"," +
				   "\"time\":\"" + talk.get(i).getTime() + "\"}" ;
			
			if(i < talk.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void loadingAdNotice(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int type = Integer.parseInt(request.getParameter("type"));
    	int page = Integer.parseInt(request.getParameter("num"));
    	
    	Connection con;
    	List<Notice> notice = new ArrayList<Notice>();
    	LoadService loadService = new LoadServiceImpl();
    	try {
			con = dbUtil.getCon();
			notice = loadService.loadNotice(con, type, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"sum\": " + notice.get(0).getId() + ",";
		out.print(msg);
		msg = "\"notice\":[";
		for(int i = 1; i < notice.size(); i++) {
			msg += "{\"id\":\"" + notice.get(i).getId() + "\"," +
				   "\"title\":\"" + notice.get(i).getTitle() + "\"," +
				   "\"user\":\"" + notice.get(i).getUser() + "\"," +
				   "\"time\":\"" + notice.get(i).getTime() + "\"}" ;
			
			if(i < notice.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void loadingAdTag(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String type = request.getParameter("type");  // All:work1+talk  work1  work2  talk
    	int page = Integer.parseInt(request.getParameter("num"));
    	IndexService indexService = new IndexServiceImpl();
    	LoadService loadService = new LoadServiceImpl();
    	Lable work1 = new Lable();
    	Lable work2 = new Lable();
    	TalkTag talk = new TalkTag();
    	
    	Connection con;
    	
    	try {
			con = dbUtil.getCon();
			if(type.equals("All")) {
				work1 = indexService.loadTag(con);
				talk = indexService.loadAllTag(con);
			} else {
				if(type.equals("work1")) {
					work1 = indexService.loadTag(con);
				}else {
					if(type.equals("work2")) {
						int id = Integer.parseInt(request.getParameter("id"));
						work2 = loadService.getTag(con, id);
					} else {
						talk =  indexService.loadAllTag(con);
					}
				} 
			}
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		String msg = "";
		out.print("{");
		msg = "\"work1\": {";
		if(type.equals("All") || type.equals("work1")) {
			int num = work1.getNum();
			msg += "\"tag\": " + num +", \"Tag\": [";
			int start = page*8;
			int end = start + 8;
			for(int i = start; i < end; i++) {
				if(i == num) {
					break;
				}
				if(i < end && i != start) {
					msg += ", ";
				}
				msg += "{ \"tag\":\"" + work1.getLable(i) + "\" , \"value\":" + work1.getValue(i) + " }";
			}
			msg += "]";
		} else {
			msg += "\"tag\": 0";
		}
		msg += "},";
		out.print(msg);
		
		msg = "\"work2\": {";
		if(type.equals("work2")) {
			int num = work2.getNum();
			msg += "\"tag\": " + num +", \"Tag\": [";
			int start = page*8;
			int end = start + 8;
			for(int i = start; i < end; i++) {
				if(i == num) {
					break;
				}
				if(i < end && i != start) {
					msg += ", ";
				}
				msg += "{ \"tag\":\"" + work2.getLable(i) + "\" , \"value\":" + work2.getValue(i) + " }";
			}
			msg += "]";
		} else {
			msg += "\"tag\": 0";
		}
		msg += "},";
		out.print(msg);
		
		msg = "\"talk\": {";
		if(type.equals("All") || type.equals("talk")) {
			int num = talk.getCnt();
			msg += "\"tag\": " + num +", \"Tag\": [";
			int start = page*8;
			int end = start + 8;
			for(int i = start; i < end; i++) {
				if(i == num) {
					break;
				}
				if(i < end && i != start) {
					msg += ", ";
				}
				msg += "{ \"tag\":\"" + talk.getTag(i) + "\" , \"value\":" + talk.getId(i) + " }";
			}
			msg += "]";
		} else {
			msg += "\"tag\": 0";
		}
		msg += "}";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    //index页面加载
    private void loadingIndex(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	request.setCharacterEncoding("utf-8");
    	List<Notice> notice = new ArrayList<Notice>();
		List<Work> newwork = new ArrayList<Work>();
		List<Work> hotwork = new ArrayList<Work>();
		List<Work> teacher = new ArrayList<Work>();
		String msg;
		
		try {
			Connection con = dbUtil.getCon();
			IndexService indexService = new IndexServiceImpl();
			WorkService workService = new WorkServiceImpl();
			notice = indexService.loadNotice(con);
			hotwork = workService.workLoad(con, 4, "downnum");
			newwork = workService.workLoad(con, 4, "time"); 
			teacher = workService.showRank(con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.getSession();

		response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		if (username == null) {
			msg = "\"name\":[{\"username\":\"\"}],";
		}else {
			msg = "\"name\":[{\"username\":\"" + session.getAttribute("name") + "\"}],";
		}
		out.print(msg);
		
		msg = "\"notice\":[";
		for(int i = 0; i < notice.size(); i++) {
			msg += "{\"id\":\"" + notice.get(i).getId() + "\","+
				   "\"title\":\"" + notice.get(i).getTitle() + "\","+
				   "\"content\":\"" + notice.get(i).getContent() + "\","+
				   "\"time\":\"" + notice.get(i).getTime() + "\"}";
			
			if(i < notice.size()-1) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		msg = "\"work\":[";
		for(int i = 0; i < 4; i++) {
			msg += "{\"id\":\"" + teacher.get(i).getId() + "\"," +
				   "\"name\":\"" + teacher.get(i).getName() + "\"," +
				   "\"user\":\"" + teacher.get(i).getUser() + "\"," +
				   "\"describe\":\"" + teacher.get(i).getDescribe() + "\"," +
				   "\"userimg\":\"" + teacher.get(i).getUserimg() + "\"," +
				   "\"workimg\":\"" + teacher.get(i).getWorkimg() + "\"}," ;
		}
		for(int i = 0; i < newwork.size(); i++) {
			msg += "{\"id\":\"" + newwork.get(i).getId() + "\"," +
				   "\"name\":\"" + newwork.get(i).getName() + "\"," +
				   "\"user\":\"" + newwork.get(i).getUser() + "\"," +
				   "\"describe\":\"" + newwork.get(i).getDescribe() + "\"," +
				   "\"userimg\":\"" + newwork.get(i).getUserimg() + "\"," +
				   "\"workimg\":\"" + newwork.get(i).getWorkimg() + "\"}," ;
		}
		for(int i = 0; i < hotwork.size(); i++) {
			msg += "{\"id\":\"" + hotwork.get(i).getId() + "\"," +
				   "\"name\":\"" + hotwork.get(i).getName() + "\"," +
				   "\"user\":\"" + hotwork.get(i).getUser() + "\"," +
				   "\"describe\":\"" + hotwork.get(i).getDescribe() + "\"," +
				   "\"userimg\":\"" + hotwork.get(i).getUserimg() + "\"," +
				   "\"workimg\":\"" + hotwork.get(i).getWorkimg() + "\"}" ;
			
			if(i < hotwork.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    //sort页面加载
    private void loadingSort(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	request.setCharacterEncoding("utf-8");
    	List<Work> good = new ArrayList<Work>();
    	List<Work> down = new ArrayList<Work>();
    	List<Work> grade = new ArrayList<Work>();
    	List<Work> time = new ArrayList<Work>();
    	List<Work> teacher = new ArrayList<Work>();
    	List<UserDetail> user = new ArrayList<UserDetail>();
    	String msg;
    	
    	Connection con;
		try {
			con = dbUtil.getCon();
			WorkService workService = new WorkServiceImpl();
			UserService userService = new UserServiceImpl();
			good = workService.workLoad(con, 10, "goodnum");
			down = workService.workLoad(con, 10, "downnum");
			grade = workService.workLoad(con, 10, "grade");
			time = workService.workLoad(con, 10, "time");
			teacher = workService.showRank(con);
			user = userService.workRank(con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("name");
		if (username == null) {
			msg = "\"name\": \"\",";
		}else {
			msg = "\"name\": \"" + session.getAttribute("name") + "\",";
		}
		out.print(msg);
		
		msg = "\"good\":[";
		for(int i = 0; i < good.size(); i++) {
			msg += "{\"id\":\"" + good.get(i).getId() + "\"," +
				   "\"name\":\"" + good.get(i).getName() + "\"," +
				   "\"user\":\"" + good.get(i).getUser() + "\"," +
				   "\"good\":\"" + good.get(i).getGood() + "\"}" ;
			
			if(i < good.size()-1) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		msg = "\"down\":[";
		for(int i = 0; i < down.size(); i++) {
			msg += "{\"id\":\"" + down.get(i).getId() + "\"," +
				   "\"name\":\"" + down.get(i).getName() + "\"," +
				   "\"user\":\"" + down.get(i).getUser() + "\"," +
				   "\"down\":\"" + down.get(i).getDown() + "\"}" ;
			
			if(i < down.size()-1) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		msg = "\"grade\":[";
		for(int i = 0; i < grade.size(); i++) {
			msg += "{\"id\":\"" + grade.get(i).getId() + "\"," +
				   "\"name\":\"" + grade.get(i).getName() + "\"," +
				   "\"user\":\"" + grade.get(i).getUser() + "\"," +
				   "\"grade\":\"" + grade.get(i).getGrade() + "\"}" ;
			
			if(i < grade.size()-1) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		msg = "\"time\":[";
		for(int i = 0; i < time.size(); i++) {
			msg += "{\"id\":\"" + time.get(i).getId() + "\"," +
				   "\"name\":\"" + time.get(i).getName() + "\"," +
				   "\"user\":\"" + time.get(i).getUser() + "\"," +
				   "\"time\":\"" + time.get(i).getTime() + "\"}" ;
			
			if(i < time.size()-1) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		msg = "\"teacher\":[";
		for(int i = 0; i < teacher.size(); i++) {
			msg += "{\"id\":\"" + teacher.get(i).getId() + "\"," +
				   "\"name\":\"" + teacher.get(i).getName() + "\"," +
				   "\"user\":\"" + teacher.get(i).getUser() + "\"}" ;
			
			if(i < teacher.size()-1) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		msg = "\"user\":[";
		for(int i = 0; i < user.size(); i++) {
			msg += "{\"user\":\"" + user.get(i).getUsername() + "\"," +
				   "\"work\":\"" + user.get(i).getId() + "\"}" ;
			
			if(i < user.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    //加载show页面的Pic截图说明部分
    private void loadingShow(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	int id =  Integer.parseInt(request.getParameter("id"));
    	int page =  Integer.parseInt(request.getParameter("num"));
    	
    	IndexService indexService = new IndexServiceImpl();
    	WorkPic workpic = new WorkPic();
    	Connection con;
    	try {
			con = dbUtil.getCon();
			page = page*3;
			workpic = indexService.showWorkPic(con, id, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		
		int num = workpic.getCount();
		String msg = "\"sum\":" + workpic.getSum() + ",";
		msg += "\"num\":" + num + ",";
		msg += "\"work\":[";
		for(int i = 0; i < num; i++) {
			msg += "{\"pic\": \"" + workpic.getPic(i) + "\"," +
		           " \"des\": \"" + workpic.getDes(i) + "\"," + 
		           " \"title\": \"" + workpic.getTit(i) + "\"," + 
				   " \"size\": " + workpic.getSize(i) + "}";
			
			if(i < num-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
		
    }
    
    private void loadingMyself(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	UserDetail user = new UserDetail();
    	HttpSession session = request.getSession();
		String username = (String) session.getAttribute("name");
		
		UserService userService = new UserServiceImpl();
		Connection con;
		try {
			con = dbUtil.getCon();
			user = userService.loadUser(con, username);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		
		String msg = "\"user\":[" +
					 "{\"name\":\"" + username + "\"," +
					 "\"img\":\"" + user.getImg()  + "\"," +
					 "\"word\":\"" + user.getUserword() + "\"}]"; 
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
		
    }
    
    private void loadingTag(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	request.setCharacterEncoding("utf-8");
    	IndexService indexService = new IndexServiceImpl();
    	Lable tag = new Lable();	
    	Connection con;
    	try {
    		con = dbUtil.getCon();
			tag = indexService.loadTag(con);
			dbUtil.closeCon(con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	int num = tag.getNum();
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"tag\": " + num +", \"Tag\": [";;
		for(int i = 0; i < num; i++) {
			msg += "{ \"tag\":\"" + tag.getLable(i) + "\" , \"value\":" + tag.getValue(i) + " }";
			if(i < num-1) {
				msg += ", ";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    //加载show页面中的Comment部分
    private void loadingComment(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	int id =  Integer.parseInt(request.getParameter("id"));
    	int page =  Integer.parseInt(request.getParameter("num"));
    	UserSay say = new UserSay();
    	
    	IndexService indexService = new IndexServiceImpl();
    	
    	Connection con;
    	try {
			con = dbUtil.getCon();
			say = indexService.loadComment(con, id, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"all\": " + say.getSum() + ",";
		msg += "\"sum\": " + say.getNum() + ",";
		msg += "\"say\": [";
		for(int i = 0; i < say.getNum(); i++) {
			msg += "{\"id\": \"" + say.getId(i) + "\"," +
					"\"user\": \"" + say.getUser(i) + "\"," +
					"\"content\": \"" + say.getContent(i) + "\"," + 
					"\"time\": \"" + say.getTime(i) + "\"," + 
					"\"num\": \"" + say.getReply(i).getNum() + "\"," + 
					"\"reply\": [";
			
			for(int j = 0; j < say.getReply(i).getNum(); j++) {
				msg += "{\"from\": \"" + say.getReply(i).getFrom(j) + "\"," + 
						"\"to\": \"" + say.getReply(i).getTo(j) + "\"," +
						"\"con\": \"" + say.getReply(i).getContent(j) + "\"," + 
						"\"ti\": \"" + say.getReply(i).getTime(j) + "\"}";
				
				if(j < say.getReply(i).getNum()-1) {
					msg += ",";
				}
			}
			msg += "]}";
			
			if(i < say.getNum()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void loadingTalk(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	Connection con;
    	int num1 = Integer.parseInt(request.getParameter("num"));
    	int type = Integer.parseInt(request.getParameter("type"));
    	String base = request.getParameter("base");
    	base = new String(base.getBytes("iso8859-1"),"utf-8");
    	IndexService indexService = new IndexServiceImpl();
    	List<Talk> talk = new ArrayList<Talk>();
    	List<Talk> hot = new ArrayList<Talk>();
    	TalkTag talktag = new TalkTag(); 
    	int cnt = 0;
    	DbUtil dbutil = new DbUtil();
    	try {
			con = dbutil.getCon();
			cnt = indexService.sumTalk(con, type, base);
			talk = indexService.loadTalk(num1,type, base, con);
			talktag = indexService.loadAllTag(con);
			hot = indexService.loadHotTalk(con);
	    	dbutil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg;
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		if (username == null) {
			msg = "\"name\":\"\",";
		}else {
			msg = "\"name\":\"" + session.getAttribute("name") + "\",";
		}
		out.print(msg);
		
		msg = "\"talksum\": " + cnt + ",";
		msg += "\"tagnum\": " + talktag.getCnt() + ",";
		msg += "\"alltag\":[";
		for(int i = 0; i < talktag.getCnt(); i++) {
			msg += "{\"id\": \"" + talktag.getId(i) + "\"," + 
					"\"img\": \"" + talktag.getImg(i) + "\"," + 
					"\"value\": \"" + talktag.getTag(i) + "\"}";
			
			if(i < talktag.getCnt()-1) {
				msg += ",";
			}
		}
		msg += "],";
		msg += "\"talknum\": " + talk.size() + ",";
		msg += "\"talk\":[";
		for(int i1 = 0; i1 < talk.size(); i1++) {
			msg += "{\"id\": \"" + talk.get(i1).getId() + "\"," +
					"\"user\": \"" + talk.get(i1).getUser() + "\"," +
					"\"img\": \"" + talk.get(i1).getImg() + "\"," +
					"\"title\": \"" + talk.get(i1).getTitle() + "\"," +
					"\"content\": \"" + talk.get(i1).getContent() + "\"," + 
					"\"time\": \"" + talk.get(i1).getTime() + "\"," + 
					"\"look\": \"" + talk.get(i1).getLook() + "\"," + 
					"\"reply\": \"" + talk.get(i1).getReply() + "\"," + 
					"\"tagnum\": \"" + talk.get(i1).getTag().getCnt() + "\"," + 
					"\"tag\": [";
			
			for(int j = 0; j < talk.get(i1).getTag().getCnt(); j++) {
				msg += "{\"id\": \"" + talk.get(i1).getTag().getId(j) + "\"," + 
						"\"value\": \"" + talk.get(i1).getTag().getTag(j) + "\"}";
				
				if(j < talk.get(i1).getTag().getCnt()-1) {
					msg += ",";
				}
			}
			msg += "]}";
			
			if(i1 < talk.size()-1) {
				msg += ",";
			}
		}
		msg += "],";
		msg += "\"HotTalk\":[";
		for(int i = 0; i < hot.size(); i++) {
			msg += "{\"id\": \"" + hot.get(i).getId() + "\"," + 
					"\"title\": \"" + hot.get(i).getTitle() + "\"," +
					"\"user\": \"" + hot.get(i).getUser() + "\"," +
					"\"time\": \"" + hot.get(i).getTime() + "\"}";
			
			if(i < hot.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void loadingSearch(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String value = request.getParameter("value");
    	String base = request.getParameter("base");
    	int num = Integer.parseInt(request.getParameter("num"));
    	String on = request.getParameter("on");
    	
    	Connection con;
    	List<Work> work = new ArrayList<Work>();
    	UserDetail user = new UserDetail();
    	Boolean ans = false;
    	LoadService loadService = new LoadServiceImpl();
    	UserService userService = new UserServiceImpl();
    	try {
			con = dbUtil.getCon();
			work = loadService.loadingSearch(con, value, base, num, on);
			if(base.equals("用户")) {
				int id = 0;
				id = userService.getUserId(con, value);
				if(id != 0) {
					user = userService.userDetail(id, con);
					ans = true;
				}
			}
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		String msg = "";
		if (username == null) {
			msg = "\"name\":\"\",";
		}else {
			msg = "\"name\":\"" + session.getAttribute("name") + "\",";
		}
		out.print(msg);
		
		if(base.equals("用户")) {
			msg = "\"status\": \"" + ans + "\",";
			if(ans) {
				msg += "\"username\": \"" + user.getUsername() + "\"," +
						"\"usermajor\": \"" + user.getUsermajor() + "\"," +
						"\"position\": \"" + user.getPosition() + "\"," +
						"\"mail\": \"" + user.getUsermail() + "\"," +
						"\"word\": \"" + user.getUserword() + "\"," +
						"\"img\": \"" + user.getImg() + "\"," ;
			}
		} else {
			msg = "\"status\": \"" + ans + "\",";
		}
		out.print(msg);
		
		msg = "\"work\":[";
		for(int i = 0; i < work.size(); i++) {
			msg  += "{\"name\":\"" + work.get(i).getName() + "\"," +
					"\"img\":\"" + work.get(i).getWorkimg() + "\"," +
					"\"user\":\"" + work.get(i).getUser() + "\"," +
					"\"good\":\"" + work.get(i).getGood() + "\"," +
					"\"down\":\"" + work.get(i).getDown() + "\"," +
					"\"time\":\"" + work.get(i).getTime() + "\"," +
					"\"id\":\"" + work.get(i).getId() + "\"," +
					"\"word\":\"" + work.get(i).getDescribe() + "\"}";
			
			if(i < work.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    //用户个人主页---下载或收藏页面
    private void loadingDownOrLove(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	String type = request.getParameter("type");
    	int page = Integer.parseInt(request.getParameter("num"));
    	
    	HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		if (username == null) {
			
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.print("{");
			String msg = "\"status\": \"false\"";
			out.print(msg);
			out.print("}");
			out.flush();
			out.close();
			
		}else {
			int id = (Integer) session.getAttribute("id");
			List<Work> work = new ArrayList<Work>();
			LoadService loadService = new LoadServiceImpl();
			Connection con;
			try {
				con = dbUtil.getCon();
				work = loadService.loadDownOrLove(con, id, page, type);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.print("{");
			String msg = "\"status\": \"true\",";
			msg += "\"sum\": " + work.get(0).getId() + ",";
			msg += "\"work\":[";
			for(int i = 1; i < work.size(); i++) {
				msg += "{\"name\": \"" + work.get(i).getName() + "\","
						+ "\"id\": \"" + work.get(i).getId() + "\","
						+ "\"workId\": \"" + work.get(i).getDown() + "\","
						+ "\"user\": \"" + work.get(i).getUser() + "\","
						+ "\"lable\": \"" + work.get(i).getLable() + "\","
					    + "\"grade\": \"" + work.get(i).getGood() + "\","
						+ "\"time\": \"" + work.get(i).getTime() + "\"}";
				
				if(i < work.size()-1) {
					msg += ",";
				}
			}
			msg += "]";
			out.print(msg);
			out.print("}");
			out.flush();
			out.close();
			 
		}
    }
    
    private void loadingMyTalk(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int num = Integer.parseInt(request.getParameter("num"));
    	
    	HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		if (username == null) {
			
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.print("{");
			String msg = "\"status\": \"false\"";
			out.print(msg);
			out.print("}");
			out.flush();
			out.close();
			
		}else {
			int id = (Integer) session.getAttribute("id");
			List<Talk> talk = new ArrayList<Talk>();
			LoadService loadService = new LoadServiceImpl();
			Connection con;
			try {
				con = dbUtil.getCon();
				talk = loadService.showMyTalk(con, id, num);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
			
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.print("{");
			String msg = "\"status\": \"true\",";
			msg += "\"sum\": " + talk.get(0).getId() + ",";
			msg += "\"talk\":[";
			for(int i = 1; i < talk.size(); i++) {
				msg += "{\"title\": \"" + talk.get(i).getTitle() + "\","
						+ "\"id\": \"" + talk.get(i).getId() + "\","
						+ "\"look\": " + talk.get(i).getLook() + ","
						+ "\"reply\": \"" + talk.get(i).getReply() + "\","
						+ "\"time\": \"" + talk.get(i).getTime() + "\"}";
				
				if(i < talk.size()-1) {
					msg += ",";
				}
			}
			msg += "]";
			out.print(msg);
			out.print("}");
			out.flush();
			out.close();
			 
		}
    }
    
    private void loadingClassify(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	int num = Integer.parseInt(request.getParameter("num"));
    	String Value = request.getParameter("Tag");
    	String value = request.getParameter("tag");
    	Value = new String(Value.getBytes("iso8859-1"),"utf-8");
    	value = new String(value.getBytes("iso8859-1"),"utf-8");
    	String on = request.getParameter("on");
    	IndexService indexService = new IndexServiceImpl();
    	LoadService loadService = new LoadServiceImpl();
    	Lable Tag = new Lable();	
    	Lable tag = new Lable();	
    	List<Work> work = new ArrayList<Work>();
    	Connection con;
 
    	try {
			con = dbUtil.getCon();
			int id = 0;
			Tag = indexService.loadTag(con);
			for(int i = 0; i < Tag.getNum(); i++) {
				if(Tag.getLable(i).equals(Value)) {
					id = Tag.getValue(i);
					break;
				}
			} 
			tag = loadService.getTag(con, id);
			work = loadService.searchTag(con, num, Value, value, on);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		String msg = "";
		if (username == null) {
			msg = "\"name\":\"\",";
		}else {
			msg = "\"name\":\"" + session.getAttribute("name") + "\",";
		}
		out.print(msg);
		
		msg = "\"sum\": " + work.get(0).getId() +", ";;
		msg += "\"work\":[";
		for(int i = 1; i < work.size(); i++) {
			msg  += "{\"name\":\"" + work.get(i).getName() + "\"," +
					"\"img\":\"" + work.get(i).getWorkimg() + "\"," +
					"\"user\":\"" + work.get(i).getUser() + "\"," +
					"\"good\":\"" + work.get(i).getGood() + "\"," +
					"\"down\":\"" + work.get(i).getDown() + "\"," +
					"\"time\":\"" + work.get(i).getTime() + "\"," +
					"\"id\":\"" + work.get(i).getId() + "\"," +
					"\"word\":\"" + work.get(i).getDescribe() + "\"}";
			
			if(i < work.size()-1) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		num = Tag.getNum();
		msg = "\"Tag\": [";
		for(int i = 0; i < num; i++) {
			msg += "{ \"tag\":\"" + Tag.getLable(i) + "\" , \"value\":" + Tag.getValue(i) + " }";
			if(i < num-1) {
				msg += ", ";
			}
		}
		msg += "],";
		out.print(msg);
		
		num = tag.getNum();
		msg = "\"tag\": [";
		for(int i = 0; i < num; i++) {
			msg += "{ \"tag\":\"" + tag.getLable(i) + "\" , \"value\":" + tag.getValue(i) + " }";
			if(i < num-1) {
				msg += ", ";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void loadingClassify2(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String[] values = request.getParameterValues("values");
    	int num = Integer.parseInt(request.getParameter("num"));
    	for(int i = 0; i < values.length; i++) {
    		values[i] = new String(values[i].getBytes("iso8859-1"),"utf-8");
    	}
    	String on = request.getParameter("on");
    	LoadService loadService = new LoadServiceImpl();
    	List<Work> work = new ArrayList<Work>();
    	Connection con;
 
    	try {
			con = dbUtil.getCon();
			work = loadService.searchTag(con, num, values, on);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		String msg = "";
		if (username == null) {
			msg = "\"name\":\"\",";
		}else {
			msg = "\"name\":\"" + session.getAttribute("name") + "\",";
		}
		out.print(msg);
		
		msg = "\"sum\": " + work.get(0).getId() +", ";;
		msg += "\"work\":[";
		for(int i = 1; i < work.size(); i++) {
			msg  += "{\"name\":\"" + work.get(i).getName() + "\"," +
					"\"img\":\"" + work.get(i).getWorkimg() + "\"," +
					"\"user\":\"" + work.get(i).getUser() + "\"," +
					"\"good\":\"" + work.get(i).getGood() + "\"," +
					"\"down\":\"" + work.get(i).getDown() + "\"," +
					"\"time\":\"" + work.get(i).getTime() + "\"," +
					"\"id\":\"" + work.get(i).getId() + "\"," +
					"\"word\":\"" + work.get(i).getDescribe() + "\"}";
			
			if(i < work.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String page = request.getParameter("page");
//前端页面
		//首页加载
		if(page.equals("index")) {
			loadingIndex(request, response);
			return ;
		}
		//搜索页面加载
		if(page.equals("search")) {
			loadingSearch(request, response);
			return ;
		}
		//分类页面加载
		if(page.equals("classify")) {
			loadingClassify(request, response);
			return ;
		}
		//分类加载+关键字搜索
		if(page.equals("classify2")) {
			loadingClassify2(request, response);
			return ;
		}
		//排名页面加载
		if(page.equals("sort")) {
			loadingSort(request, response);
			return ;
		}
		//show页面--Pic截图说明加载
		if(page.equals("show")) {
			loadingShow(request, response);
			return ;
		}
		//show页面--Comment加载
		if(page.equals("comment")) {
			loadingComment(request, response);
			return ;
		}
		//话题首页加载
		if(page.equals("talk")) {
			loadingTalk(request, response);
			return ;
		}
		//个人主页--首页加载
		if(page.equals("myself")) {
			loadingMyself(request, response);
			return ;
		}
		//个人主页--下载/收藏页面加载
		if(page.equals("downOrlove")) {
			loadingDownOrLove(request, response);
			return ;
		}
		//个人主页--我的话题页面加载
		if(page.equals("Mytalk")) {
			loadingMyTalk(request, response);
			return ;
		}
		//个人主页--上传页面一级标签加载
		if(page.equals("upload")) {
			try {
				loadingTag(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ;
		}
//ad页面
		//话题管理页面
		if(page.equals("adtalk")) {
			loadingAdTalk(request, response);
			return ;
		}
		//公告管理页面
		if(page.equals("adnotice")) {
			loadingAdNotice(request, response);
			return ;
		}
		//标签管理页面
		if(page.equals("adTag")) {
			loadingAdTag(request, response);
			return ;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
