package com.software.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.software.Pojo.Notice;
import com.software.Service.ChangeService;
import com.software.Service.impl.ChangeServiceImpl;
import com.software.util.DbUtil;

/**
 * Servlet implementation class ChangeServlet
 */
public class ChangeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DbUtil dbUtil=new DbUtil();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangeServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private void changegoodnum (HttpServletRequest request, HttpServletResponse response) throws IOException {
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	
    	HttpSession session = request.getSession();
		int userId = (Integer) session.getAttribute("id");
		
    	try {
			con = dbUtil.getCon();
			String getid = request.getParameter("id");
			String getnum = request.getParameter("num");
			int id = Integer.parseInt(getid);
			int num = Integer.parseInt(getnum);
			changeService.changeGoodnum(id, num, userId, con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"ans\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    	
    	return ;
    }
    
    private void changedownnum (HttpServletRequest request, HttpServletResponse response) throws IOException {
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	
    	HttpSession session = request.getSession();
		int userId = (Integer) session.getAttribute("id");
    	try {
			con = dbUtil.getCon();
			String getid = request.getParameter("id");
			String getnum = request.getParameter("num");
			int id = Integer.parseInt(getid);
			int num = Integer.parseInt(getnum);
			changeService.changeDownnum(id, num, userId, con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"ans\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    	
    	return ;
    }
    
    public void changegrade(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	
    	HttpSession session = request.getSession();
    	String username = (String) session.getAttribute("name");
    	if(username == null) {
    		response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close();
			
    	} else {
    		int userId = (Integer) session.getAttribute("id");
        	try {
    			con = dbUtil.getCon();
    			int grade = Integer.parseInt(request.getParameter("grade"));
    			int workId = Integer.parseInt(request.getParameter("work"));
    			changeService.workGrade(userId, workId, grade, con);
    			dbUtil.closeCon(con);
    		} catch (Exception e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
        	
        	response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"true\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close();
    	}
    	
    	return ;
    }
    
    private void uploadComment(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	int toComment = Integer.parseInt(request.getParameter("to"));
    	int workId = Integer.parseInt(request.getParameter("work_id"));
    	int id = 0;
    	String toUser = request.getParameter("toUser");
    	String content = request.getParameter("content");
    	ChangeService changeService = new ChangeServiceImpl();
    	Connection con;
    	
    	HttpSession session = request.getSession();
		String username = (String) session.getAttribute("name");
		if (username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close();
			
		}else {
			con = dbUtil.getCon();
			id = (Integer) session.getAttribute("id");
			if(toComment == 0) {
				changeService.addComment(workId, id, content, con);
			} else {
				changeService.addSubComment(toComment, id, toUser, content, con);
			}
			con.close();
		}
		
		response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    }
    
    private void addLevel1(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("to"));
    	String content = request.getParameter("content");
    	
    	HttpSession session = request.getSession();
    	String username = (String) session.getAttribute("name");
		if (username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
			
		}else {
			Connection con;
			int me = (Integer) session.getAttribute("id");
	    	ChangeService changeService = new ChangeServiceImpl();
	    	try {
				con = dbUtil.getCon();
				changeService.addLevel1(con, id, me, content);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"true\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
		}
    	
    }
    
    private void addLevel2(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("to"));
    	String content = request.getParameter("content");
    	
    	HttpSession session = request.getSession();
    	String username = (String) session.getAttribute("name");
		if (username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
			
		}else {
			Connection con;
			int me = (Integer) session.getAttribute("id");
	    	ChangeService changeService = new ChangeServiceImpl();
	    	try {
				con = dbUtil.getCon();
				changeService.addLevel2(con, id, me, content);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"true\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
		}
    }

    private void addLevel3(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("to"));
    	String content = request.getParameter("content");
    	String you = request.getParameter("toUser");
    	
    	HttpSession session = request.getSession();
    	String username = (String) session.getAttribute("name");
		if (username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
			
		}else {
			Connection con;
			int me = (Integer) session.getAttribute("id");
	    	ChangeService changeService = new ChangeServiceImpl();
	    	try {
				con = dbUtil.getCon();
				changeService.addLevel3(con, id, me, you, content);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"true\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
		}
    }
    
    private void deleMywork(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	String workType = request.getParameter("status");
    	int work_id = Integer.parseInt(request.getParameter("id"));
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	try {
			con = dbUtil.getCon();
			if(workType.equals("1")) {
				changeService.deleTemMywork(con, work_id);
			} else {
				if(workType.equals("0")) {
					changeService.deleUpdateMywork(con, work_id);
				} else {
					if(workType.equals("3")) {
						changeService.delePassMywork(con, work_id);
					} else {
						changeService.deleNotPassMywork(con, work_id);
					}
				}
			}
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close(); 
    }
    
    private void deleRecord(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int page = Integer.parseInt(request.getParameter("page"));
    	int recordId = Integer.parseInt(request.getParameter("id"));
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	HttpSession session = request.getSession();
    	String username = (String) session.getAttribute("name");
		if (username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
			
		}else {
			try {
				con = dbUtil.getCon();
				changeService.deleRecord(page, recordId, con);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"true\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
		}
    }
    
    private void deleMytalk(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	HttpSession session = request.getSession();
    	String username = (String) session.getAttribute("name");
		if (username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
			
		}else {
			try {
				con = dbUtil.getCon();
				changeService.deleTalk(con, id);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"true\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
		}
    }
    
    private void postTalk(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String title = request.getParameter("title");
    	String context = request.getParameter("context");
    	int select = Integer.parseInt(request.getParameter("select"));
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();	
    	HttpSession session = request.getSession();
    	String username = (String) session.getAttribute("name");
		if (username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
			
		}else {
			try {
				int id = (Integer) session.getAttribute("id");
				con = dbUtil.getCon();
				changeService.postTalk(title, context, select, id, con);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"true\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
		}
    	
    }
    
    private void addNotice(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String title = request.getParameter("title"); 
    	String context = request.getParameter("context");
    	title = new String(title.getBytes("iso8859-1"),"utf-8");
    	context = new String(context.getBytes("iso8859-1"),"utf-8");
    	
    	Connection con;
    	Notice notice = new Notice();
    	ChangeService changeService = new ChangeServiceImpl();	
    	HttpSession session = request.getSession();
    	String username = (String) session.getAttribute("name");
		if (username == null) {
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"false\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
			
		}else {
			try {
				int id = (Integer) session.getAttribute("id");
				notice.setTitle(title);
				notice.setContent(context);
				notice.setId(id);
				con = dbUtil.getCon();
				changeService.addNotice(con, notice);
				dbUtil.closeCon(con);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.setContentType("application/json;charset=UTF-8");
			PrintWriter pout = response.getWriter();
	    	String msg = "{\"status\": \"true\"}";
	    	pout.print(msg);
			pout.flush();
			pout.close(); 
		}
    }
    
    private void deleAdNotice(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	try {
			con = dbUtil.getCon();
			changeService.deleNotice(con, id);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close(); 
    }
    
    private void deleAdSomeNotice(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String[] num = request.getParameterValues("num");
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	try {
			con = dbUtil.getCon();
			for(int i = 0; i < num.length; i++) {
				int id = Integer.parseInt(num[i]);
				changeService.deleNotice(con, id);
			}
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close(); 
    }
    
    private void deleAdTalk(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	try {
			con = dbUtil.getCon();
			changeService.deleTalk(con, id);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close(); 
    }
    
    private void deleAdSomeTalk(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String[] num = request.getParameterValues("num");
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	try {
			con = dbUtil.getCon();
			for(int i = 0; i < num.length; i++) {
				int id = Integer.parseInt(num[i]);
				changeService.deleTalk(con, id);
			}
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close(); 
    }
    
    private void changeTag(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	String value = request.getParameter("value");
    	int id = Integer.parseInt(request.getParameter("id"));
    	String type = request.getParameter("type2");
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	try {
			con = dbUtil.getCon();
			changeService.changeTag(con, type, id, value);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close(); 
    }
    
    private void addTag(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	String value = request.getParameter("value");
    	int id = Integer.parseInt(request.getParameter("id"));
    	String type = request.getParameter("type2");
    	
    	Connection con;
    	ChangeService changeService = new ChangeServiceImpl();
    	try {
			con = dbUtil.getCon();
			changeService.addTag(con, type, value, id);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close(); 
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String type = request.getParameter("type");
//面对User
		//资源展示页面--收藏功能
		if(type.equals("good")) {
			changegoodnum(request, response);
			return ;
		}
		//资源展示页面--下载功能
		if(type.equals("down")) {
			changedownnum(request, response);
			return ;
		}
		//资源展示页面--回复功能
		if(type.equals("uploadComment")) {
			try {
				uploadComment(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return ;
		}
		//话题页面--发表功能
		if(type.equals("postTalk")) {
			postTalk(request, response);
			return ;
		}
		//单个话题展示页面--回复功能
		if(type.equals("uploadDiscuss")) {
			int level = Integer.parseInt(request.getParameter("level"));
			if(level == 0) {
				addLevel1(request, response);
			} else {
				if(level == 1) {
					addLevel2(request, response);
				} else {
					addLevel3(request, response);
				}
			}
			return ;
		}
		//个人下载页面--评分功能
		if(type.equals("grade")) {
			changegrade(request, response);
			return ;
		}
		//个人下载/收藏资源页面--删除功能
		if(type.equals("deleRecord")) {
			deleRecord(request, response);
			return ;
		}
		//个人上传资源页面--删除功能
		if(type.equals("deleMywork")) {
			deleMywork(request, response);
			return ;
		}
		//个人话题页面--删除功能
		if(type.equals("deleMytalk")) {
			deleMytalk(request, response);
			return ;
		}
//面向Ad		
		//话题管理页面--单个删除功能
		if(type.equals("deletalk")) {
			deleAdTalk(request, response);
			return ;
		}
		//话题管理页面--批量删除功能
		if(type.equals("delesometalk")) {
			deleAdSomeTalk(request, response);
			return ;
		}
		//公告管理页面--单个删除功能
		if(type.equals("delenotice")) {
			deleAdNotice(request, response);
			return ;
		}
		//公告管理页面--批量删除功能
		if(type.equals("delesomenotice")) {
			deleAdSomeNotice(request, response);
			return ;
		}
		//公告管理页面--发表功能
		if(type.equals("addNotice")) {
			addNotice(request, response);
			return ;
		}
		//标签管理页面--修改功能
		if(type.equals("changeTag")) {
			changeTag(request, response);
			return ;
		}
		//标签管理页面--添加功能
		if(type.equals("addTag")) {
			addTag(request, response);
			return ;
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
