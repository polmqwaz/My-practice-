package com.software.Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.software.Pojo.Discuss;
import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Work;
import com.software.Service.IndexService;
import com.software.Service.LoadService;
import com.software.Service.WorkService;
import com.software.Service.impl.IndexServiceImpl;
import com.software.Service.impl.LoadServiceImpl;
import com.software.Service.impl.WorkServiceImpl;
import com.software.util.DbUtil;

/**
 * Servlet implementation class SingelServlet
 */
public class SingelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DbUtil dbUtil=new DbUtil();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SingelServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    private void workOperation(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	Work work = new Work();
    	List<Work> list = new ArrayList<Work>();
    	List<Work> downwork = new ArrayList<Work>();
    	String msg;
    	request.setCharacterEncoding("utf-8");
    	String work_name = request.getParameter("work_name");
    	String user_name = request.getParameter("user_name");
    	Connection con;
    	
    	HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
    	
		try {
			con = dbUtil.getCon();
			WorkService workService = new WorkServiceImpl();
			work = workService.oneworkLoad(con, work_name, user_name, username);
			list = workService.alikeLoad(con, work.getId());
			downwork = workService.workLoad(con, 5, "downnum"); 
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    		   	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		

		if (username == null) {
			msg = "\"name\":[{\"username\":\"\"}],";
		}else {
			msg = "\"name\":[{\"username\":\"" + session.getAttribute("name") + "\"}],";
		}
		out.print(msg);
		
		msg = "\"work\":";
		msg += "{\"id\":\"" + work.getId() + "\"," +
			   "\"name\":\"" + work.getName() + "\"," +
			   "\"user\":\"" + work.getUser() + "\"," +
			   "\"grade\":\"" + work.getGrade() + "\"," +
			   "\"os\":\"" + work.getOs() + "\"," +
			   "\"addr\":\"" + work.getAddr() + "\"," +
			   "\"time\":\"" + work.getTime() + "\"," +
			   "\"updatetime\":\"" + work.getUpdatetime() + "\"," +
			   "\"updatecontent\":\"" + work.getSelftag() + "\"," +
			   "\"goodnum\":\"" + work.getGood() + "\"," +
			   "\"downnum\":\"" + work.getDown() + "\"," +
			   "\"describe\":\"" + work.getDescribe() + "\"," +
			   "\"userlove\":\"" + work.getUserimg() + "\"," +
			   "\"workimg\":\"" + work.getWorkimg() + "\"}," ;
		out.print(msg);
		
		msg = "\"tagNum\": " + work.getTagnum() + ",";
		msg += "\"tag\":[";
		for(int i = 0; i < work.getTagnum(); i++) {
			msg += "{\"value\": \"" + work.getTag(i) +"\"}";
			
			if(i < work.getTagnum()-1) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		msg += "\"alike\":[";
		for(int i = 0; i < 5; i++) {
			msg += "{\"id\":\"" + list.get(i).getId() + "\"," +
					"\"name\":\"" + list.get(i).getName() + "\"," +
					"\"user\":\"" + list.get(i).getUser() + "\"," +
					"\"downnum\":\"" + list.get(i).getDown() + "\"," +
					"\"lable\":\"" + list.get(i).getLable() + "\"," +
					"\"workimg\":\"" + list.get(i).getWorkimg() + "\"}" ;
			
			if(i < 4) {
				msg += ",";
			}
		}
		msg += "],";
		out.print(msg);
		
		msg = "\"sort\":[";
		for(int i = 0; i < downwork.size(); i++) {
			msg += "{\"id\":\"" + downwork.get(i).getId() + "\"," +
				   "\"name\":\"" + downwork.get(i).getName() + "\"," +
				   "\"user\":\"" + downwork.get(i).getUser() + "\"," +
				   "\"lable\":\"" + downwork.get(i).getLable() + "\"," +
				   "\"down\":\"" + downwork.get(i).getDown() + "\"," +
				   "\"workimg\":\"" + downwork.get(i).getWorkimg() + "\"}" ;
			
			if(i < downwork.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
		
    }
    
    private void talkOperation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	int page = Integer.parseInt(request.getParameter("page"));
    	List<Discuss> discuss = new ArrayList<Discuss>();
    	
    	Connection con;
    	IndexService indexService = new IndexServiceImpl();
    	try {
			con = dbUtil.getCon();
			discuss = indexService.loadDiscuss(con, id, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "";
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("name");
		if (username == null) {
			msg = "\"name\":[{\"username\":\"\"}],";
		}else {
			msg = "\"name\":[{\"username\":\"" + session.getAttribute("name") + "\"}],";
		}
		out.print(msg);
		
		msg = "\"discuss\":[";
		msg += "{\"title\": \"" + discuss.get(0).getTitle() + "\", " +
				"\"user\": \"" + discuss.get(0).getUser() + "\", " +
				"\"img\": \"" + discuss.get(0).getImg() + "\"," + 
				"\"content\": \"" + discuss.get(0).getContent() + "\"," + 
				"\"reply\": \"" + discuss.get(0).getReply() + "\"," + 
				"\"time\": \"" + discuss.get(0).getTime() + "\"}";
		if(discuss.size() > 1) {
			msg += ",";
		}
		for(int i = 1; i < discuss.size(); i++) {
			msg += "{\"id\":" + discuss.get(i).getId() + ", " +
					"\"user\": \"" + discuss.get(i).getUser() + "\", " +
					"\"img\": \"" + discuss.get(i).getImg() + "\"," + 
					"\"content\": \"" + discuss.get(i).getContent() + "\"," + 
					"\"time\": \"" + discuss.get(i).getTime() + "\"," +
					"\"reply\": " + discuss.get(i).getReply() + "}";
			
			if(i < discuss.size()-1) {
				msg += ",";
			}
		}
		
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void level2Operation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	
    	LoadService loadService = new LoadServiceImpl();
    	List<Discuss> discuss = new ArrayList<Discuss>();
    	Connection con;
    	
    	try {
			con = dbUtil.getCon();
			discuss = loadService.loadLevel2(con, id);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"Reply\":[";
		
		for(int i = 0; i < discuss.size(); i++) {
			msg += "{\"id\": " + discuss.get(i).getId() + ", " +
					"\"user\": \"" + discuss.get(i).getUser() + "\", " + 
					"\"img\": \"" + discuss.get(i).getImg() + "\", " +
					"\"content\": \"" + discuss.get(i).getContent() + "\", " + 
					"\"reply\": " + discuss.get(i).getReply() + ", " +
					"\"time\": \"" + discuss.get(i).getTime() + "\"}";
			
			if(i < discuss.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
		
    }

    private void level3Operation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	
    	LoadService loadService = new LoadServiceImpl();
    	List<Discuss> discuss = new ArrayList<Discuss>();
    	Connection con;
    	
    	try {
			con = dbUtil.getCon();
			discuss = loadService.loadLevel3(con, id);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"Reply\":[";
		
		for(int i = 0; i < discuss.size(); i++) {
			msg += "{\"user\": \"" + discuss.get(i).getUser() + "\", " + 
					"\"to\": \"" + discuss.get(i).getTitle() + "\", " +
					"\"id\": \"" + discuss.get(i).getId() + "\", " +
					"\"img\": \"" + discuss.get(i).getImg() + "\", " +
					"\"content\": \"" + discuss.get(i).getContent() + "\", " + 
					"\"time\": \"" + discuss.get(i).getTime() + "\"}";
			
			if(i < discuss.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
		
    }
    
    private void myworkOperation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int page = Integer.parseInt(request.getParameter("page"));
    	
    	HttpSession session = request.getSession();
		int id = (Integer) session.getAttribute("id");
		String username = (String) session.getAttribute("name");
    	
    	LoadService loadService = new LoadServiceImpl();
    	List<Work> work = new ArrayList<Work>();
    	Connection con;
    	try {
			con = dbUtil.getCon();
			work = loadService.loadMywork(con, id, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"sum\":" + work.get(0).getId() + ",";
		msg += "\"name\":\"" + username + "\",";
		msg += "\"work\":[";
		
		for(int i = 1; i < work.size(); i++) {
			msg += "{\"name\": \"" + work.get(i).getName() + "\", " + 
					"\"down\": \"" + work.get(i).getDown() + "\", " +
					"\"id\": \"" + work.get(i).getId() + "\", " +
					"\"good\": \"" + work.get(i).getGood() + "\", " +
					"\"update\": \"" + work.get(i).getUpdatetime() + "\", " + 
					"\"time\": \"" + work.get(i).getTime() + "\"}";
			
			if(i < work.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    	
    }
    
    private void mywaitworkOperation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int page = Integer.parseInt(request.getParameter("page"));
    	
    	HttpSession session = request.getSession();
		int id = (Integer) session.getAttribute("id");
    	
    	LoadService loadService = new LoadServiceImpl();
    	List<Work> work = new ArrayList<Work>();
    	Connection con;
    	try {
			con = dbUtil.getCon();
			work = loadService.loadMywaitwork(con, id, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"sum\":" + work.get(0).getId() + ",";
		msg += "\"work\":[";
		
		for(int i = 1; i < work.size(); i++) {
			msg += "{\"name\": \"" + work.get(i).getName() + "\", " + 
					"\"lable\": \"" + work.get(i).getSelftag() + "\", " +
					"\"id\": \"" + work.get(i).getId() + "\", " +
					"\"time\": \"" + work.get(i).getTime() + "\"}";
			
			if(i < work.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    	
    }
    
    private void myupdateworkOperation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int page = Integer.parseInt(request.getParameter("page"));
    	
    	HttpSession session = request.getSession();
		int id = (Integer) session.getAttribute("id");
		String username = (String) session.getAttribute("name");
    	
    	LoadService loadService = new LoadServiceImpl();
    	List<Work> work = new ArrayList<Work>();
    	Connection con;
    	try {
			con = dbUtil.getCon();
			work = loadService.loadMyupdatework(con, id, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"sum\":" + work.get(0).getId() + ",";
		msg += "\"name\":\"" + username + "\",";
		msg += "\"work\":[";
		
		for(int i = 1; i < work.size(); i++) {
			msg += "{\"name\": \"" + work.get(i).getName() + "\", " + 
					"\"lable\": \"" + work.get(i).getSelftag() + "\", " +
					"\"id\": \"" + work.get(i).getId() + "\", " +
					"\"status\": \"" + work.get(i).getGood() + "\", " +
					"\"time\": \"" + work.get(i).getTime() + "\"}";
			
			if(i < work.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    	
    }
    
    private void workUpdateOperation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String workname = request.getParameter("name");
    	HttpSession session = request.getSession();
		int id = (Integer) session.getAttribute("id");
    	
    	Connection con;
    	Work work = new Work();
    	LoadService loadService = new LoadServiceImpl();
    	try {
			con = dbUtil.getCon();
			work = loadService.loadworkUpdate(con, workname, id);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"name\":\"" + work.getName() + "\"," +
					 "\"os\": \"" + work.getOs() + "\"," +
					 "\"img\": \"" + work.getWorkimg() + "\"";
		
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void mynotpassworkOperation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int page = Integer.parseInt(request.getParameter("page"));
    	
    	HttpSession session = request.getSession();
		int id = (Integer) session.getAttribute("id");
		String username = (String) session.getAttribute("name");
    	
    	LoadService loadService = new LoadServiceImpl();
    	List<Work> work = new ArrayList<Work>();
    	Connection con;
    	try {
			con = dbUtil.getCon();
			work = loadService.loadMynotpasswork(con, id, page);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"sum\":" + work.get(0).getId() + ",";
		msg += "\"name\":\"" + username + "\",";
		msg += "\"work\":[";
		
		for(int i = 1; i < work.size(); i++) {
			msg += "{\"name\": \"" + work.get(i).getName() + "\", " + 
					"\"lable\": \"" + work.get(i).getLable() + "\", " +
					"\"status\": \"" + work.get(i).getSelftag() + "\", " +
					"\"id\": \"" + work.get(i).getId() + "\", " +
					"\"time\": \"" + work.get(i).getTime() + "\"}";
			
			if(i < work.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void noticOperation(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int id = Integer.parseInt(request.getParameter("id"));
    	
    	IndexService indexService = new IndexServiceImpl();
    	Notice notice = new Notice(); 
    	Connection con;
    	try {
			con = dbUtil.getCon();
			notice = indexService.loadOneNotice(con, id);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"title\": \"" + notice.getTitle() + "\",";
		msg += "\"content\": \"" + notice.getContent() + "\",";
		msg += "\"time\": \"" + notice.getTime() + "\",";
		msg += "\"user\": \"" + notice.getUser() + "\","
				+ "\"id\": \"" + notice.getId() + "\"";
		
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void loadingTag(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	request.setCharacterEncoding("utf-8");
    	int id = Integer.parseInt(request.getParameter("id"));
    	LoadService loadService = new LoadServiceImpl();
    	Lable tag = new Lable();	
    	Connection con;
    	try {
    		con = dbUtil.getCon();
			tag = loadService.getTag(con, id);
			dbUtil.closeCon(con);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	int num = tag.getNum();
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"tag\": " + num +", \"Tag\": [";;
		for(int i = 0; i < num; i++) {
			msg += "{ \"tag\":\"" + tag.getLable(i) + "\" , \"value\":" + tag.getValue(i) + " }";
			if(i < num-1) {
				msg += ", ";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String type = request.getParameter("type");
		//首页--公告展示
		if("notic".equals(type))
		{
			noticOperation(request, response);
		}
		//资源展示页面
		if("work".equals(type))
		{
			workOperation(request, response);
		}
		//话题--一级回复加载
		if("talk".equals(type))
		{
			talkOperation(request, response);
		}
		//话题--二级回复加载
		if("level2".equals(type))
		{
			level2Operation(request, response);
		}
		//话题--三级回复加载
		if("level3".equals(type))
		{
			level3Operation(request, response);
		}		
		//个人--已通过作品
		if("mywork".equals(type))
		{
			myworkOperation(request, response);
		}
		//个人--其他作品（update：更新；wait：新作品；notpass：未通过）
		if("myotherwork".equals(type))
		{
			String flag = request.getParameter("flag");
			if("wait".equals(flag)) {
				mywaitworkOperation(request, response);
			} else {
				if("update".equals(flag)){
					myupdateworkOperation(request, response);
				} else {
					mynotpassworkOperation(request, response);
				}
			}
			
		}
		//个人--上传页面
		if("upload".equals(type))
		{
			try {
				loadingTag(request, response);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//个人--资源更新
		if("work_update".equals(type))
		{
			workUpdateOperation(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
