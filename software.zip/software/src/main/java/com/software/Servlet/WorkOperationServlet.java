package com.software.Servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.software.Pojo.Work;
import com.software.Pojo.WorkPic;
import com.software.Service.WorkService;
import com.software.Service.impl.WorkServiceImpl;
import com.software.util.DbUtil;

/**
 * Servlet implementation class WorkOperationServlet
 */
public class WorkOperationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DbUtil dbUtil = new DbUtil();
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public WorkOperationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    
  //ad_work页面加载
    private void loadingWaitWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	request.setCharacterEncoding("utf-8");
    	int numStart =  Integer.parseInt(request.getParameter("start"));
    	int numEnd =  Integer.parseInt(request.getParameter("end"));
    	int num = 1;
    	List<Work> waitwork = new ArrayList<Work>();
  
    	try {
			Connection con = dbUtil.getCon();
			WorkService workService = new WorkServiceImpl();
			waitwork = workService.waitWorkLoad(con, numStart, numEnd);
			num = workService.sumWaitWork(con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"page\":[{\"num\":\"" + num + "\"}],";
		out.print(msg);
		msg = "\"work\":[";
		for(int i = 0; i < waitwork.size(); i++) {
			msg += "{\"id\":\"" + waitwork.get(i).getId() + "\"," +
				   "\"name\":\"" + waitwork.get(i).getName() + "\"," +
				   "\"user\":\"" + waitwork.get(i).getUser() + "\"," +
				   "\"addr\":\"" + waitwork.get(i).getAddr() + "\"," +
				   "\"describe\":\"" + waitwork.get(i).getDescribe() + "\"," +
				   "\"time\":\"" + waitwork.get(i).getTime() + "\"," +
				   "\"tag\":\"" + waitwork.get(i).getLable() + "\"," +
				   "\"workimg\":\"" + waitwork.get(i).getWorkimg() + "\"}" ;
			
			if(i < waitwork.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    	
    }
    
    private void loadingHaveWork(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	int numStart =  Integer.parseInt(request.getParameter("start"));
    	int numEnd =  Integer.parseInt(request.getParameter("end"));
    	int num = 1;
    	List<Work> waitwork = new ArrayList<Work>();
    	
    	try {
			Connection con = dbUtil.getCon();
			WorkService workService = new WorkServiceImpl();
			waitwork = workService.haveWorkLoad(con, numStart, numEnd);
			num = workService.sumHaveWork(con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"page\":[{\"num\":\"" + num + "\"}],";
		out.print(msg);
		msg = "\"work\":[";
		for(int i = 0; i < waitwork.size(); i++) {
			msg += "{\"id\":\"" + waitwork.get(i).getId() + "\"," +
				   "\"name\":\"" + waitwork.get(i).getName() + "\"," +
				   "\"user\":\"" + waitwork.get(i).getUser() + "\"," +
				   "\"addr\":\"" + waitwork.get(i).getAddr() + "\"," +
				   "\"describe\":\"" + waitwork.get(i).getDescribe() + "\"," +
				   "\"time\":\"" + waitwork.get(i).getTime() + "\"," +
				   "\"tag\":\"" + waitwork.get(i).getLable() + "\"," +
				   "\"workimg\":\"" + waitwork.get(i).getWorkimg() + "\"}" ;
			
			if(i < waitwork.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    }
    
    private void loadingUpdateWork(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	request.setCharacterEncoding("utf-8");
    	int numStart =  Integer.parseInt(request.getParameter("start"));
    	int numEnd =  Integer.parseInt(request.getParameter("end"));
    	int num = 1;
    	List<Work> waitwork = new ArrayList<Work>();
    	
    	try {
			Connection con = dbUtil.getCon();
			WorkService workService = new WorkServiceImpl();
			waitwork = workService.updateWorkLoad(con, numStart, numEnd);
			num = workService.sumUpdateWork(con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"page\":[{\"num\":\"" + num + "\"}],";
		out.print(msg);
		msg = "\"work\":[";
		for(int i = 0; i < waitwork.size(); i++) {
			msg += "{\"id\":\"" + waitwork.get(i).getId() + "\"," +
				   "\"name\":\"" + waitwork.get(i).getName() + "\"," +
				   "\"user\":\"" + waitwork.get(i).getUser() + "\"," +
				   "\"addr\":\"" + waitwork.get(i).getAddr() + "\"," +
				   "\"describe\":\"" + waitwork.get(i).getDescribe() + "\"," +
				   "\"time\":\"" + waitwork.get(i).getTime() + "\"," +
				   "\"tag\":\"" + waitwork.get(i).getLable() + "\"," +
				   "\"workimg\":\"" + waitwork.get(i).getWorkimg() + "\"}" ;
			
			if(i < waitwork.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    	
    }
    
    private void loadingNotPass(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	request.setCharacterEncoding("utf-8");
    	int numStart =  Integer.parseInt(request.getParameter("start"));
    	int numEnd =  Integer.parseInt(request.getParameter("end"));
    	int num = 1;
    	List<Work> waitwork = new ArrayList<Work>();
    	
    	try {
			Connection con = dbUtil.getCon();
			WorkService workService = new WorkServiceImpl();
			waitwork = workService.notPassWorkLoad(con, numStart, numEnd);
			num = workService.sumNotPassWork(con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter out = response.getWriter();
		out.print("{");
		String msg = "\"page\":[{\"num\":\"" + num + "\"}],";
		out.print(msg);
		msg = "\"work\":[";
		for(int i = 0; i < waitwork.size(); i++) {
			msg += "{\"id\":\"" + waitwork.get(i).getId() + "\"," +
				   "\"name\":\"" + waitwork.get(i).getName() + "\"," +
				   "\"user\":\"" + waitwork.get(i).getUser() + "\"," +
				   "\"time\":\"" + waitwork.get(i).getTime() + "\"," +
				   "\"tag\":\"" + waitwork.get(i).getLable() + "\"}" ;
			
			if(i < waitwork.size()-1) {
				msg += ",";
			}
		}
		msg += "]";
		out.print(msg);
		out.print("}");
		out.flush();
		out.close();
    	
    }
    
    //审批通过作品
    private void allowWork (HttpServletRequest request, HttpServletResponse response) throws IOException {
    	Connection con;
    	Boolean ans = false;
    	WorkPic workpic = new WorkPic();
    	request.setCharacterEncoding("utf-8");
    	int id = Integer.parseInt(request.getParameter("id"));
    	String fileName = request.getParameter("addr");
    	int status = Integer.parseInt(request.getParameter("status"));
    	
    	String savePath = this.getServletContext().getRealPath("/WEB-INF/Work");
        String savepicPath = this.getServletContext().getRealPath("/WorkPic");  
        String getpicPath = this.getServletContext().getRealPath("/TemPic");
        String getPath=this.getServletContext().getRealPath("/WEB-INF/TemWork");
        
        File file = new File(getPath + "\\" + fileName);
        FileInputStream in = new FileInputStream(getPath + "\\" + fileName);
        FileOutputStream out = new FileOutputStream(savePath + "\\" + fileName);
        byte buffer[] = new byte[1024];
        int len = 0;
        while((len=in.read(buffer))>0){
            out.write(buffer, 0, len);
        }
        in.close();
        out.close();
    	file.delete();
    	
    	WorkService workService = new WorkServiceImpl();
    	try {
			con = dbUtil.getCon();
			if(status == 3) {
				workpic = workService.allowUpdateWork(id, con);
			} else {
				workpic = workService.allowWork(id, con);
			}
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	if(workpic.getCount() != -1) {
    		for(int i = 0; i < workpic.getCount(); i++) {
    			String picName = workpic.getPic(i);
    			file = new File(getpicPath + "\\" + picName);
    			in = new FileInputStream(getpicPath + "\\" + picName);
    			out = new FileOutputStream(savepicPath + "\\" + picName);
    			byte tembuffer[] = new byte[1024];
    			len = 0;
    			while((len=in.read(tembuffer))>0){
    				out.write(tembuffer, 0, len);
    			}
    			in.close();
    			out.close();
    			file.delete();
    		}
    		ans = true;
    	}    	
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"ans\": " + ans + "}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    }
    //删除已通过作品
    private void deleHave(HttpServletRequest request, HttpServletResponse response, int flag, int tem) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	Connection con;
    	WorkPic workpic = new WorkPic();
    	Boolean ans = false;
    	int id = 0, status = 0;
    	String fileName = "";
    	
    	WorkService workService = new WorkServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			if(flag == 0) {
				id = Integer.parseInt(request.getParameter("id"));
				fileName = request.getParameter("addr");
				
			} else {
				id = flag;
				fileName = workService.getAddr(con, id, status);
			}  	
			
			String getpicPath = this.getServletContext().getRealPath("/WorkPic");
			String getPath = this.getServletContext().getRealPath("/WEB-INF/Work");
    	
    
			workpic = workService.DeleHave(id, con);
			dbUtil.closeCon(con);
			
			if(workpic.getCount() != 0) {
	    		
	    		File file = new File(getPath + "\\" + fileName);
	        	file.delete();
	        	
	    		for(int i = 0; i < workpic.getCount(); i++) {
	    			String picName = workpic.getPic(i);
	    			file = new File(getpicPath + "\\" + picName);
	    			file.delete();
	    		}
	    		ans = true;
	    	}    	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"ans\": " + ans + "}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    }
    //删除待审核作品
    private void deleWait(HttpServletRequest request, HttpServletResponse response, int flag, int tem) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	Connection con;
    	WorkPic workpic = new WorkPic();
    	Boolean ans = true;
    	int id = 0, status = 0;
    	String fileName = "";
    	
    	WorkService workService = new WorkServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			if(flag == 0) {
				id = Integer.parseInt(request.getParameter("id"));
				fileName = request.getParameter("addr");
				status = Integer.parseInt(request.getParameter("status"));
				
			} else {
				id = flag;
				status = tem;
				fileName = workService.getAddr(con, id, status);
			}  	
    	
			String getpicPath = this.getServletContext().getRealPath("/TemPic");
			String getPath=this.getServletContext().getRealPath("/WEB-INF/TemWork");
			File file = new File(getPath + "\\" + fileName);
			file.delete();
    	
			if(status == 3) {
				workpic = workService.DeleUpdate(id, con);
			} else {
				workpic = workService.DeleWait(id, con);
			}
			dbUtil.closeCon(con);
			
			if(workpic.getCount() != 0) {
	        	
	    		for(int i = 0; i < workpic.getCount(); i++) {
	    			String picName = workpic.getPic(i);
	    			file = new File(getpicPath + "\\" + picName);
	    			file.delete();
	    		}
	    		
	    	}    
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"ans\": " + ans + "}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    }
    //展示作品
    private void showWork(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	int id = Integer.parseInt(request.getParameter("id"));
    	int status = Integer.parseInt(request.getParameter("status"));
    	
    	Connection con;
    	Work work = new Work();
    	WorkService workService = new WorkServiceImpl();
    	try {
			con = dbUtil.getCon();
			work = workService.showWork(con, id, status);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
		pout.print("{");
		String msg = "";
		
		if(status == 2) {
    		msg += "\"keyword\":[";
    		for(int i = 0; i < work.getTagnum(); i++) {
    			msg += "{\"value\": \"" + work.getTag(i) + "\"}";
    			
    			if(i < work.getTagnum()-1) {
    				msg += ",";
    			}
    		}
    		msg += "],";
    	}
		
		if(status == 1) {
			msg += "\"keyword\": \"" + work.getSelftag() + "\",";
		}
		
    	msg += "\"id\": " + id + "," +
    			"\"name\": \"" + work.getName() + "\"," +
    			"\"os\": \"" + work.getOs() + "\"," +
    			"\"des\": \"" + work.getDescribe() + "\"," +
    			"\"addr\": \"" + work.getAddr() + "\"," +
    			"\"user\": \"" + work.getUser() + "\"," +
    			"\"lable\": \"" + work.getLable() + "\"";
    	
    	pout.print(msg);
    	pout.print("}");
		pout.flush();
		pout.close();
    }
    //批量删除
    private void deleSome(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String[] num = request.getParameterValues("num");
    	int status = Integer.parseInt(request.getParameter("status"));
    	
    	//1：待审核   2：通过    3：待更新   4:不通过的作品	
    	if(status == 1 || status == 3) {
    		for(int i = 0; i < num.length; i++) {
    			int id = Integer.parseInt(num[i]);
    			deleWait(request, response, id, status);
    		}
    	} else {
    		if(status == 2) {
    			for(int i = 0; i < num.length; i++) {
        			int id = Integer.parseInt(num[i]);
        			deleHave(request, response, id, status);
        		}
    		} else {
    			Connection con;
    			try {
					con = dbUtil.getCon();
					for(int i = 0; i < num.length; i++) {
	        			int id = Integer.parseInt(num[i]);
	        			WorkService workService = new WorkServiceImpl();
	        			workService.DeleNotPass(id, con);
	        		}
					dbUtil.closeCon(con);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    			
    		}
    	}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"ans\": " + true + "}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    
    }
    
    private void showRank(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	List<Work> work = new ArrayList<Work>(); 
    	WorkService workService = new WorkServiceImpl();
    	Connection con;
    	
    	try {
			con = dbUtil.getCon();
			work = workService.showRank(con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"work\":[";
    	for(int i = 0; i < 10; i++) {
    		msg += "{\"id\": " + work.get(i).getId() + "," +
    			  "\"name\": \"" + work.get(i).getName() + "\"," +
    			  "\"user\": \"" + work.get(i).getUser() + "\"}";
    		
    		if(i < 9) {
    			msg += ",";
    		}
    	}
    	msg += "]}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    }
    
    private void findWork(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	request.setCharacterEncoding("utf-8");
    	String name = request.getParameter("name");
    	String user = request.getParameter("user");
    	int num = Integer.parseInt(request.getParameter("num"));
    	
    	Connection con;
    	Work work = new Work();
    	WorkService workService = new WorkServiceImpl();
    	 
    	try {
			con = dbUtil.getCon();
			work = workService.findWork(con, name, user, num);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
		String msg = "{\"id\": 0}";
		if(work.getDown() == 1) {
			msg = "{\"name\": \"" + work.getName() + "\"," +
					"\"id\": " + work.getId() + "}";
		}
    	pout.print(msg);
		pout.flush();
		pout.close();
    }
    
    private void updateRank(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	String[] num = request.getParameterValues("num");
    	
    	Connection con;
    	WorkService workService = new WorkServiceImpl();
    	try {
			con = dbUtil.getCon();
			workService.updateRank(num, con);
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
		String msg = "{\"ans\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close();
    }
    
    private void cleanWork() {
    	Connection con;
    	List<Work> list = new ArrayList<Work>();
    	WorkService workService = new WorkServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			list = workService.cleanOperation(con, 1);
			
			String path=this.getServletContext().getRealPath("/WEB-INF/Work");
			for(int i = 0; i < list.size(); i++) {
			    File file=new File(path + "\\" + list.get(i).getAddr());    
			    if(!file.exists())    
			    {    
			    	workService.deleOther(con, 1, list.get(i).getId());
			    }    
			}
			
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return ;
    	
    }
    
    private void cleanFWork() {
    	Connection con;
    	List<Work> list = new ArrayList<Work>();
    	WorkService workService = new WorkServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			list = workService.cleanOperation(con, 1);
			
			String path=this.getServletContext().getRealPath("/WEB-INF");
			File file=new File(path + "\\" + "Work");    
			String[] fileList = file.list();   
			for (int i = 0; i < fileList.length; i++) {  
				String string = fileList[i];  
				File one = new File(file.getPath(),string);  
	            String name = one.getName(); 
	            int j = 0;
	            for(j = 0; j < list.size(); j++) {
	            	if(list.get(j).getAddr().equals(name)) {
	            		break;
	            	} 
	            }
	            
	            if(j == list.size()) {
	            	one.delete();
	            }
			}
			
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return ;
    	
    }
    
    private void cleanPic() {
    	Connection con;
    	List<Work> list = new ArrayList<Work>();
    	WorkService workService = new WorkServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			list = workService.cleanOperation(con, 2);
			
			String path=this.getServletContext().getRealPath("/WorkPic");
			for(int i = 0; i < list.size(); i++) {
			    File file=new File(path + "\\" + list.get(i).getAddr());    
			    if(!file.exists())    
			    {  
			    	if(list.get(i).getGood() == 0) {
			    		workService.deleOther(con, 2, list.get(i).getId());
			    	}
			    }    
			}
			
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return ;
    	
    }
    
    private void cleanFPic() {
    	Connection con;
    	List<Work> list = new ArrayList<Work>();
    	WorkService workService = new WorkServiceImpl();
    	
    	try {
			con = dbUtil.getCon();
			list = workService.cleanOperation(con, 2);
			
			String path=this.getServletContext().getRealPath("/WorkPic");
			File file=new File(path);    
			String[] fileList = file.list();   
			for (int i = 0; i < fileList.length; i++) {  
				String string = fileList[i];  
				File one = new File(file.getPath(),string);  
	            String name = one.getName(); 
	            int j = 0;
	            for(j = 0; j < list.size(); j++) {
	            	if(list.get(j).getAddr().equals(name)) {
	            		break;
	            	} 
	            }
	            
	            if(j == list.size()) {
	            	one.delete();
	            }
			}
			
			dbUtil.closeCon(con);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	return ;
    	
    }
    
    private void changeOther(HttpServletRequest request, HttpServletResponse response) throws IOException {
    	int num = Integer.parseInt(request.getParameter("num"));
    	
    	if(num == 1) {
    		cleanWork();
    	} else {
    		if(num == 2) {
    			cleanPic();
    		} else {
    			if(num == 3) {
    				cleanFWork();
    			} else {
    				cleanFPic();
    			}
    		}
    	}
    	
    	response.setContentType("application/json;charset=UTF-8");
		PrintWriter pout = response.getWriter();
    	String msg = "{\"status\": \"true\"}";
    	pout.print(msg);
		pout.flush();
		pout.close(); 
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String type = request.getParameter("type");
//前台页面
		//排行页面（前、后台公用）
		if(type.equals("rank")) {
			showRank(request, response);
		}

//管理员
		//管理员作品管理页面
		if(type.equals("adwork")) {
			int page = Integer.parseInt(request.getParameter("page"));
			if(page == 1) {
				loadingWaitWork(request, response);
			} else {
				if(page == 2) {
					loadingHaveWork(request, response);
				} else {
					if(page == 3) {
						loadingUpdateWork(request, response);
					} else {
						loadingNotPass(request, response);
					}
				}
				
			}		
			return ;
		}
		//单个作品展示
		if(type.equals("show")) {
			showWork(request, response);
			return ;
		}
		//作品审核通过
		if(type.equals("allow")) {
			allowWork(request, response);
			return ;
		}
		//作品审核不通过
		if(type.equals("allowDele")) {
			deleWait(request, response, 0, 0);
			return ;
		}
		//删除单个作品
		if(type.equals("haveDele")) {
			deleHave(request, response, 0, 0);
			return ;
		}
		//批量删除作品
		if(type.equals("delesome")) {
			deleSome(request, response);
		}
		//手动排行页面（寻找作品）
		if(type.equals("find")) {
			findWork(request, response);
		}
		//手动排行页面（更新排行）
		if(type.equals("updateRank")) {
			updateRank(request, response);
		}
		//清理
		if(type.equals("other")) {
			changeOther(request, response);
			return ;
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
