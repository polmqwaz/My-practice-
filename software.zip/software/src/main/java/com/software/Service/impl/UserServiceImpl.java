package com.software.Service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.software.Dao.UserDao;
import com.software.Dao.impl.UserDaoImpl;
import com.software.Pojo.User;
import com.software.Pojo.UserDetail;
import com.software.Service.UserService;

public class UserServiceImpl implements UserService{
	private UserDao userDao = new UserDaoImpl();
	
	//获取用户Id
	public int getUserId(Connection con, String name) throws SQLException {
		int id = 0;
		id = userDao.getUserId(con, name);
		
		return id;
	}
	
	//上传工具排行榜
	public List<UserDetail> workRank(Connection con) throws SQLException {
		List<UserDetail> user = new ArrayList<UserDetail>();
		user = userDao.workRank(con);
		
		return user;
	}
	
	//个人首页信息加载
	public UserDetail loadUser(Connection con, String name) throws SQLException {
		
		UserDetail user = new UserDetail();
		int id = 0;
		id = userDao.getUserId(con, name);
		user = userDao.userDetail(id, con);
		
		return user;
	}
	
	//用户登录
	public int userLogin(User user, Connection con) throws SQLException {
		int id = 0;
		id = userDao.userLogin(user, con);
		
		return id;
	}
	
	//用户名重用检查
	public Boolean checkUserName(String name, Connection con) throws SQLException {
		Boolean ans = true;
		ans = userDao.checkUserName(name, con);
		
		return ans;
	}
	
	//用户注册
	public void userRegisiter(UserDetail detail, Connection con) throws SQLException {
	
		userDao.userRegisiter(detail, con);
		
	}
	
	//用户信息更新
	public void updateUser(UserDetail user, Connection con) throws SQLException {
		userDao.updateUser(user, con);
		return ;
	}
	
	//提取用户信息
	public UserDetail userDetail(int id, Connection con) throws SQLException {
		UserDetail user = new UserDetail();
		user = userDao.userDetail(id, con);
		
		return user;
	}
	
	//更改密码
	public void changePass(String pass, int id, Connection con) throws SQLException {
		userDao.changePass(pass, id, con);
		
		return ;
	}
	
	//ad
	//用户身份
	public int getPosition(Connection con, int id) throws SQLException {
		int position = 0;
		position = userDao.getPosition(con, id);
		
		return position;
	}
	
	//展示用户
	public List<UserDetail> showUser(Connection con, int type, int page) throws SQLException {  //type: 0全部  1新增  2 普通  3 管理员
		List<UserDetail> user = new ArrayList<UserDetail>();
		if(type == 0) {
			user = userDao.showTea(con, page);
			return user;
		}
		if(type == 1) {
			user = userDao.showNow(con, page);
			return user;
		}
		if(type == 2) {
			user = userDao.showUser(con, page);
			return user;
		}
		if(type == 3) {
			user = userDao.showAd(con, page);
			return user;
		}
		
		return user;
	}
	
	//身份改变
	public void changePosition(int id, int type, Connection con) throws SQLException {
		userDao.changePosition(id, type, con);
		
		return ;
	}
	
	//删除用户
	public void deleUser(int id, Connection con) throws SQLException {
		userDao.deleUser(id, con);
		
		return ;
	}
}
