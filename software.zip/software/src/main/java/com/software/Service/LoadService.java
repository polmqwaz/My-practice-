package com.software.Service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.software.Pojo.Discuss;
import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Talk;
import com.software.Pojo.Work;

public interface LoadService {
//搜索
	//按作者、作品名、描述、关键字搜索
	public List<Work> loadingSearch(Connection con, String value, String base, int num, String on) throws SQLException;
	//按标签搜索
	public List<Work> searchTag(Connection con, int num, String Tag, String tag, String on) throws SQLException;
	//按标签和关键字搜索
	public List<Work> searchTag(Connection con, int num, String value[], String on) throws SQLException;
	
//个人主页
	//加载该用户已通过作品
	public List<Work> loadMywork(Connection con, int id, int page) throws SQLException;
	//加载该用户待更新的作品
	public List<Work> loadMyupdatework(Connection con, int id, int page) throws SQLException;
	//加载该用户待审核的作品
	public List<Work> loadMywaitwork(Connection con, int id, int page) throws SQLException;
	//加载该用户未通过的作品
	public List<Work> loadMynotpasswork(Connection con, int id, int page) throws SQLException;
	//获取要更新作品的基本信息
	public Work loadworkUpdate(Connection con, String name, int id) throws SQLException;
	//加载用户下载或收藏的工具
	public List<Work> loadDownOrLove(Connection con, int id, int page, String type) throws SQLException;
	//加载用户发表的话题
	public List<Talk> showMyTalk(Connection con, int id, int page) throws SQLException;
	//资源二级标签加载
	public Lable getTag(Connection con, int id) throws SQLException;
	
//论坛
	//加载该话题中某一级话题（id）的二级话题
	public List<Discuss> loadLevel2(Connection con, int id) throws SQLException;
	//加载该话题中某二级话题（id）的三级话题
	public List<Discuss> loadLevel3(Connection con, int id) throws SQLException;
	
//管理员
	//加载话题
	public List<Talk> loadTalk(Connection con, int type, int page) throws SQLException;
	//加载公告
	public List<Notice> loadNotice(Connection con,int type, int page) throws SQLException;
}
