package com.software.Service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.software.Pojo.Work;
import com.software.Pojo.WorkPic;

public interface WorkService {

//获取细节
	//获取地址
	public String getAddr(Connection con, int id, int status) throws SQLException;
	//管理员查看所有作品
	public Work showWork(Connection con, int id, int status) throws SQLException;
	
//作品的基本操作
	//删除已通过作品
	public WorkPic DeleHave (int id, Connection con) throws SQLException;	
	//删除未通过作品
	public void DeleNotPass (int id, Connection con) throws SQLException;

//排行
	//展示排行榜
	public List<Work> showRank(Connection con) throws SQLException;
	//手动排行
	public Work findWork(Connection con, String name, String user, int num) throws SQLException;
	//更新排行
	public void updateRank(String num[], Connection con) throws SQLException;

//作品上传
	//用户上传作品
	public void addwork (Work work, int num, String pic[], String size[], String picdes[], String title[], Connection con) throws SQLException ;	
	//用户上传更新作品
	public void updatework (Work work, int num, String pic[], String size[], String picdes[], String title[], Connection con) throws SQLException;	
	
//管理审核上传作品
	//通过
	public WorkPic allowWork (int id, Connection con) throws SQLException;
	//不通过
	public WorkPic DeleWait (int id, Connection con) throws SQLException;
	
//管理员审核通过待更新作品
	//通过
	public WorkPic allowUpdateWork(int id, Connection con) throws SQLException;
	//不通过
	public WorkPic DeleUpdate (int id, Connection con) throws SQLException;

//管理员清理
	//other操作
	public List<Work> cleanOperation(Connection con, int num) throws SQLException;
	//删除多余的记录
	public void deleOther(Connection con, int num, int id) throws SQLException;
	
//非用户作品加载
	//待审核作品加载
	public List<Work> waitWorkLoad(Connection con, int numStart, int numEnd) throws SQLException;
	//计算总数
	public int sumWaitWork(Connection con) throws SQLException;
	//已通过作品加载
	public List<Work> haveWorkLoad(Connection con, int numStart, int numEnd) throws SQLException;
	//计算总数
	public int sumHaveWork(Connection con) throws SQLException;
	//待更新作品加载
	public List<Work> updateWorkLoad(Connection con, int numStart, int numEnd) throws SQLException;
	//计算总数
	public int sumUpdateWork(Connection con) throws SQLException;
	//不通过作品加载
	public List<Work> notPassWorkLoad(Connection con, int numStart, int numEnd) throws SQLException;
	//计算总数
	public int sumNotPassWork(Connection con) throws SQLException;
	
//前台作品加载
	//作品加载（基于base）
	public List<Work> workLoad (Connection con, int num, String base) throws SQLException;
	//单个作品加载
	public Work oneworkLoad (Connection con, String work_name, String user_name, String name) throws SQLException;
	//相似作品加载
	public List<Work> alikeLoad(Connection con, int id) throws SQLException;
}
