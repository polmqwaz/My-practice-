package com.software.Service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.software.Dao.IndexDao;
import com.software.Dao.impl.IndexDaoImpl;
import com.software.Pojo.Discuss;
import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Talk;
import com.software.Pojo.TalkTag;
import com.software.Pojo.UserSay;
import com.software.Pojo.WorkPic;
import com.software.Service.IndexService;

public class IndexServiceImpl implements IndexService{
	private IndexDao indexDao = new IndexDaoImpl();
	
//标签操作
	//话题标签加载
	public TalkTag loadAllTag(Connection con) throws SQLException {
		TalkTag tag = new TalkTag();
		tag = indexDao.loadAllTag(con);
		
		return tag;
	}
	
	//资源一级标签加载
	public Lable loadTag(Connection con) throws SQLException {
		
		Lable tag = new Lable();
		tag = indexDao.loadTag(con);
		
		return tag;
	}
	
//论坛	
	//计算所有话题总数（基于base：0无条件  1标签   2话题）
	public int sumTalk(Connection con, int type, String base) throws SQLException  {
		int cnt = 0;
		cnt = indexDao.sumTalk(con, type, base);
		
		return cnt;
	}
	
	//论坛页面加载（基于base：0无条件  1标签   2话题）
	public List<Talk> loadTalk(int num1, int type, String base,Connection con) throws SQLException {
		List<Talk> talk = new ArrayList<Talk>();
		talk = indexDao.loadTalk(num1, type, base, con);
		
		return talk;
	}
	
	//热门话题加载
	public List<Talk> loadHotTalk(Connection con) throws SQLException  {
		List<Talk> talk = new ArrayList<Talk>();
		talk = indexDao.loadHotTalk(con);
		
		return talk;
	}
	
	//单个话题详情页面加载	
	public List<Discuss> loadDiscuss(Connection con, int id, int page) throws SQLException {
		List<Discuss> discuss = new ArrayList<Discuss>();
		discuss = indexDao.loadDiscuss(con, id, page);
		
		return discuss;
	}

//资源展示页面
	//评论加载
	public UserSay loadComment(Connection con, int id, int page) throws SQLException {
		UserSay say = new UserSay();
		say = indexDao.loadComment(con, id, page);
		
		return say;
	}
	
	//加载作品图文说明
	public WorkPic showWorkPic(Connection con, int id, int num1) throws SQLException {
		WorkPic workpic = new WorkPic();
		workpic = indexDao.showWorkPic(con, id, num1);
		
		return workpic;
	}

//公告
	//全部公告加载
	public List<Notice> loadNotice(Connection con) throws SQLException {
		
		List<Notice> list = new ArrayList<Notice>();
		list = indexDao.loadNotice(con);
		 
		return list;
	}
	
	//单个公告加载
	public Notice loadOneNotice(Connection con, int id) throws SQLException {
		
		Notice notice = new Notice();
		notice = indexDao.loadOneNotice(con, id);
		 
		return notice;
	}
	
}