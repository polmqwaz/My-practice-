package com.software.Service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.software.Dao.LoadDao;
import com.software.Dao.TalkDao;
import com.software.Dao.UserDao;
import com.software.Dao.impl.LoadDaoImpl;
import com.software.Dao.impl.TalkDaoImpl;
import com.software.Dao.impl.UserDaoImpl;
import com.software.Pojo.Discuss;
import com.software.Pojo.Lable;
import com.software.Pojo.Notice;
import com.software.Pojo.Talk;
import com.software.Pojo.Work;
import com.software.Service.LoadService;

public class LoadServiceImpl implements LoadService{
	LoadDao loadDao = new LoadDaoImpl();
	
	public List<Work> loadingSearch(Connection con, String value, String base, int num, String on) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		
		if(base.equals("资源名")) {
			work = loadDao.searchWork(con, value, num, on);
			
		} else{
			if(base.equals("用户")) {
				int id = 0;
				UserDao userDao = new UserDaoImpl();
				id = userDao.getUserId(con, value);
				if(id == 0) {
					id = 5;
				} else {
					id = 4;
				}
				work = loadDao.searchUser(con, value, num, on, id);
				
			} else {
				if(base.equals("描述")) {
					work = loadDao.searchDes(con, value, num, on);
					
				} else{
					work = loadDao.searchKey(con, value, num, on);
					 
				}
			}
		}
		
		return work;
	}
	
	//所有作品
	public List<Work> searchTag(Connection con, int num, String Tag, String tag, String on) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = loadDao.searchTag(con, num, Tag, tag, on);
		
		return work;
	}
	//按标签和关键字搜索
	public List<Work> searchTag(Connection con, int num, String value[], String on) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = loadDao.searchTag(con, num, value, on);
		
		return work;
	}
	
	public Work loadworkUpdate(Connection con, String name, int id) throws SQLException {
		Work work = new Work();
		work = loadDao.loadworkUpdate(con, name, id);
		
		return work;
	}
	
	public List<Work> loadMywork(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = loadDao.loadMywork(con, id, page);
		
		return work;
	}
	
	public List<Work> loadMyupdatework(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = loadDao.loadMyupdatework(con, id, page);
		
		return work;
	}
	
	public List<Work> loadMywaitwork(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = loadDao.loadMywaitwork(con, id, page);
		
		return work;
	}
	
	public List<Work> loadMynotpasswork(Connection con, int id, int page) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = loadDao.loadMynotpasswork(con, id, page);
		
		return work;
	}
	
	//加载用户下载或收藏的工具
	public List<Work> loadDownOrLove(Connection con, int id, int page, String type) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		
		if(type.equals("down")) {
			work = loadDao.loadMydownwork(con, id, page);
		} else {
			work = loadDao.loadMylovework(con, id, page);
		}
		
		return work;
	}
	
	public List<Talk> showMyTalk(Connection con, int id, int page) throws SQLException {
		List<Talk> talk = new ArrayList<Talk>();
		TalkDao talkDao = new TalkDaoImpl();
		talk = talkDao.showMyTalk(con, id, page);
		
		return talk;
	}
	
	public List<Discuss> loadLevel2(Connection con, int id) throws SQLException {
		List<Discuss> discuss = new ArrayList<Discuss>();
		TalkDao talkDao = new TalkDaoImpl();
		discuss = talkDao.loadLevel2(con, id);
		
		return discuss;
	}
	
	public List<Discuss> loadLevel3(Connection con, int id) throws SQLException {
		List<Discuss> discuss = new ArrayList<Discuss>();
		TalkDao talkDao = new TalkDaoImpl();
		discuss = talkDao.loadLevel3(con, id);
		
		return discuss;
	}
	
	//二级标签加载
	public Lable getTag(Connection con, int id) throws SQLException {
		Lable tag = new Lable();
		tag = loadDao.getTag(con, id);
		
		return tag;
	}
	
	//管理员
	//加载话题
	public List<Talk> loadTalk(Connection con, int type, int page) throws SQLException {
		List<Talk> talk = new ArrayList<Talk>();
		TalkDao talkDao = new TalkDaoImpl();
		//type  0今日  1所有
		if(type == 0) {
			talk = talkDao.loadTodayTalk(con, page);
		} else {
			talk = talkDao.loadAllTalk(con, page);
		}
		
		return talk;
	}
	
	//加载公告
	public List<Notice> loadNotice(Connection con,int type, int page) throws SQLException {
		List<Notice> notice = new ArrayList<Notice>();
		//type:  0 today   1 all
		if(type == 0) {
			notice = loadDao.loadTodayNotice(con, page);
		} else {
			notice = loadDao.loadAllNotice(con, page);
		}
		
		return notice;
	}
	
}
