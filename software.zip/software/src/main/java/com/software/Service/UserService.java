package com.software.Service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.software.Pojo.User;
import com.software.Pojo.UserDetail;

public interface UserService {
	
	//获取用户Id
	public int getUserId(Connection con, String name) throws SQLException;
	
	//上传工具排行榜
	public List<UserDetail> workRank(Connection con) throws SQLException;
	//个人首页信息加载
	public UserDetail loadUser (Connection con, String name) throws SQLException;
	
	//用户登录
	public int userLogin (User user, Connection con) throws SQLException;
	//用户名重用检查
	public Boolean checkUserName(String name, Connection con) throws SQLException;
	//用户注册
	public void userRegisiter(UserDetail detail, Connection con) throws SQLException;
	//用户信息更新
	public void updateUser(UserDetail user, Connection con) throws SQLException;
	//提取用户信息
	public UserDetail userDetail(int id, Connection con) throws SQLException;
	//更改密码
	public void changePass(String pass, int id, Connection con) throws SQLException;
	
	//ad
	//用户身份
	public int getPosition(Connection con, int id) throws SQLException;
	//展示用户
	public List<UserDetail> showUser(Connection con, int type, int page) throws SQLException;
	//身份改变
	public void changePosition(int id, int type, Connection con) throws SQLException;
	//删除用户
	public void deleUser(int id, Connection con) throws SQLException;
}
