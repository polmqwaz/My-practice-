package com.software.Service.impl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.software.Dao.UserDao;
import com.software.Dao.WorkDao;
import com.software.Dao.impl.UserDaoImpl;
import com.software.Dao.impl.WorkDaoImpl;
import com.software.Pojo.Work;
import com.software.Pojo.WorkPic;
import com.software.Service.WorkService;

public class WorkServiceImpl implements WorkService{
	WorkDao workDao = new WorkDaoImpl();
	
	//获取地址
	public String getAddr(Connection con, int id, int status) throws SQLException {
		String addr = "";
		addr = workDao.getAddr(con, id, status);
		
		return addr;
	}
	
	//管理员查看所有作品
	public Work showWork(Connection con, int id, int status) throws SQLException {
		Work work = new Work();

		if(status == 1) {  //待审核
			work = workDao.getWaitWork(con, id);
		} else {
			if(status == 2) {  //已通过
				work = workDao.getOnWork(con, id);
			} else {   //待更新
				work = workDao.getUpdateWork(con, id);
			}
		}
				
		return work;
	}
	
	//删除已通过作品
	public WorkPic DeleHave (int id, Connection con) throws SQLException {
		WorkPic workpic = new WorkPic();
		
		workpic = workDao.getHavePic(id, con);
		workDao.deleteHave(con, id);
		
		return workpic;
	}
	
	//删除未通过作品
	public void DeleNotPass (int id, Connection con) throws SQLException {
		
		workDao.deleteNotPass(con, id);
		
		return ;
	}
	
	//展示排行榜
	public List<Work> showRank(Connection con) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = workDao.showRank(con);
		
		return work;
	}
	
	//手动排行
	public Work findWork(Connection con, String name, String user, int num) throws SQLException {
		Work work = new Work();
		work = workDao.findWork(con, name, user, num);
		
		return work;
	}
	
	//更新排行
	public void updateRank(String num[], Connection con) throws SQLException {
		workDao.updateRank(num, con);
		
		return ;
	}
	
	//用户上传作品
	public void addwork (Work work, int num, String pic[], String size[], String picdes[], String title[], Connection con) throws SQLException {
		UserDao userDao = new UserDaoImpl();
		int id = userDao.getUserId(con, work.getUser());
		workDao.addwork(work, num, pic, size, picdes, title, id, con);
	}
	
	//用户上传更新作品
	public void updatework (Work work, int num, String pic[], String size[], String picdes[], String title[], Connection con) throws SQLException {
		workDao.updatework(work, num, pic, size, picdes, title, con);
	}
	
	//管理审核上传作品(通过)
	public WorkPic allowWork (int id, Connection con) throws SQLException{
		WorkPic workpic = new WorkPic();
		int workId = 0;
		workId  = workDao.allowWork(id, con);
		if(workId != 0) {
			workpic = workDao.getPic(id, con);
			workDao.movePic(workpic, workId, con);
			workDao.deleteWait(con, id);
			return workpic;
		}
		workpic.setCount(-1);
		return workpic;
	}
	
	//管理审核上传作品(不通过)
	public WorkPic DeleWait (int id, Connection con) throws SQLException {
		WorkPic workpic = new WorkPic();
		
		workpic = workDao.getPic(id, con);
		workDao.moveDeleWait(con, id);
		workDao.deleteWait(con, id);
		
		return workpic;
	}
	
	//管理员审核通过待更新作品(通过)
	public WorkPic allowUpdateWork(int id, Connection con) throws SQLException{
		WorkPic workpic = new WorkPic();
		int workId = 0;
		workId  = workDao.allowUpdateWork(id, con);
		if(workId != 0) {
			workpic = workDao.getUpdatePic(id, con);
			workDao.moveUpdatePic(workpic, workId, con);
			workDao.deleteUpdate(con, id);
			return workpic;
		}
		workpic.setCount(-1);
		return workpic;
	}
	
	//管理员审核通过待更新作品(不通过)
	public WorkPic DeleUpdate (int id, Connection con) throws SQLException {
		WorkPic workpic = new WorkPic();
		
		workpic = workDao.getUpdatePic(id, con);
		workDao.moveDeleUpdate(con, id);
		workDao.deleteUpdate(con, id);
		
		return workpic;
	}

	//other操作      num: 1Work 2Pic
	public List<Work> cleanOperation(Connection con, int num) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		if(num == 1) {
			work = workDao.loadAllWork(con);
		} else {
			work = workDao.loadAllPic(con);
		}
		
		return work;
	}
	
	//删除多余的记录
	public void deleOther(Connection con, int num, int id) throws SQLException {
		if(num == 1) {
			workDao.deleteHave(con, id);
		} else {
			workDao.delePic(con, id);
		}
		
		return ;
	}
	
	//待审核作品加载
	public List<Work> waitWorkLoad(Connection con, int numStart, int numEnd) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = workDao.waitWorkLoad(con, numStart, numEnd);
		
		return work;
	}
	
	//计算总数
	public int sumWaitWork(Connection con) throws SQLException {
		int num;
		num = workDao.sumWaitWork(con);
		
		return num;
	}
	
	//已通过作品加载
	public List<Work> haveWorkLoad(Connection con, int numStart, int numEnd) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = workDao.haveWorkLoad(con, numStart, numEnd);
		
		return work;
	}
	//计算总数
	public int sumHaveWork(Connection con) throws SQLException {
		int num;
		num = workDao.sumHaveWork(con);
		
		return num;
	}
	
	//待更新作品加载
	public List<Work> updateWorkLoad(Connection con, int numStart, int numEnd) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = workDao.updateWorkLoad(con, numStart, numEnd);
		
		return work;
	}
	//计算总数
	public int sumUpdateWork(Connection con) throws SQLException {
		int num;
		num = workDao.sumUpdateWork(con);
		
		return num;
	}

	//不通过作品加载
	public List<Work> notPassWorkLoad(Connection con, int numStart, int numEnd) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = workDao.notPassWorkLoad(con, numStart, numEnd);
		
		return work;
	}
	//计算总数
	public int sumNotPassWork(Connection con) throws SQLException {
		int num;
		num = workDao.sumNotPassWork(con);
		
		return num;
	}
	
	//作品加载（基于base）
	public List<Work> workLoad(Connection con, int num, String base) throws SQLException {
		List<Work> works = new ArrayList<Work>();
		works = workDao.newWorkLoad(con, num, base);
		 
		return works;
	}
	
	//单个作品加载
	public Work oneworkLoad(Connection con, String work_name, String user_name, String name) throws SQLException {
		Work work = new Work();
		work = workDao.oneWorkLoad(con, work_name, user_name, name);
		 
		return work;
	}
	
	//相似作品罗列
	public List<Work> alikeLoad(Connection con, int id) throws SQLException {
		List<Work> work = new ArrayList<Work>();
		work = workDao.alikeLoad(con, id);
			
		return work;
	}
}
