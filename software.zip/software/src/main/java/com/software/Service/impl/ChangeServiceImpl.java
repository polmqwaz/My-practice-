package com.software.Service.impl;

import java.sql.Connection;
import java.sql.SQLException;

import com.software.Dao.ChangeDao;
import com.software.Dao.TalkDao;
import com.software.Dao.impl.ChangeDaoImpl;
import com.software.Dao.impl.TalkDaoImpl;
import com.software.Pojo.Notice;
import com.software.Service.ChangeService;

public class ChangeServiceImpl implements ChangeService{
	private ChangeDao changeDao = new ChangeDaoImpl();

//用户对话题的操作
	//删除我的话题
	public void deleTalk(Connection con, int id) throws SQLException {
		TalkDao talkDao = new TalkDaoImpl();
		talkDao.deleTalk(con, id);
		
		return ;
	}
	//话题发表
	public void postTalk(String title, String context, int select, int id, Connection con) throws SQLException {
		changeDao.postTalk(title, context, select, id, con);
		
		return ;
	}
	//添加话题的一级回复
	public void addLevel1(Connection con, int id, int me, String content) throws SQLException {
		changeDao.addLevel1(con, id, me, content);
		
		return ;
	}
	//添加话题的二级回复
	public void addLevel2(Connection con, int id, int me, String content) throws SQLException {
		changeDao.addLevel2(con, id, me, content);
		
		return ;
	}
	//添加话题的三级回复
	public void addLevel3(Connection con, int id, int me, String you, String content) throws SQLException {
		changeDao.addLevel3(con, id, me, you, content);
		
		return ;
	}
	
//用户对资源的操作	
	//添加资源一级回复
	public void addComment(int workId, int userId, String content, Connection con) throws SQLException {
		changeDao.addComment(workId, userId, content, con);
	}
	//添加资源二级回复
	public void addSubComment(int commentId, int userId, String toUser, String content, Connection con) throws SQLException {
		changeDao.addSubComment(commentId, userId, toUser, content, con);
	}
	//用户收藏该资源
	public void changeGoodnum (int id, int num, int userId, Connection con) throws SQLException {
		changeDao.changeGoodnum(id, num, userId, con);
	}
	//用户下载该资源
	public void changeDownnum (int id, int num, int userId, Connection con) throws SQLException {
		changeDao.changeDownnum(id, num, userId, con);
	}
	//用户对已下载资源评分
	public void workGrade (int userId, int workId, int grade, Connection con) throws SQLException {
		changeDao.workGrade(userId, workId, grade, con);
	}
	//用户删除自己已通过资源
	public void delePassMywork(Connection con, int id) throws SQLException {
		changeDao.delePassMywork(con, id);
		
		return ;
	}
	//用户删除自己待审核资源
	public void deleTemMywork(Connection con, int id) throws SQLException {
		changeDao.deleTemMywork(con, id);
		
		return ;
	}
	//用户删除自己待更新资源
	public void deleUpdateMywork(Connection con, int id) throws SQLException {
		changeDao.deleUpdateMywork(con, id);
		
		return ;
	}
	//用户删除自己未通过资源
	public void deleNotPassMywork(Connection con, int id) throws SQLException {
		changeDao.deleNotPassMywork(con, id);
		
		return ;
	}
	//删除用户收藏或下载记录
	public void deleRecord(int type, int recordId, Connection con) throws SQLException {
		//type  1 下载  2 收藏
		if(type == 1) {
			changeDao.deleDownRecord(recordId, con);
		} else {
			changeDao.deleLoveRecord(recordId, con);
		}
		
		return ;
	}
	
//管理员对公告的操作		
	//删除一个公告
	public void deleNotice(Connection con, int id) throws SQLException {
		changeDao.deleNotice(con, id);
		
		return ;
	}	
	//添加公告
	public void addNotice(Connection con, Notice notice) throws SQLException {
		changeDao.addNotice(con, notice);
			
		return ;
	}
	
//管理员对公告的操作
	//添加一个标签
	public void addTag(Connection con, String type, String value, int id) throws SQLException {
		if(type.equals("work1")) {
			changeDao.addBWorkTag(con, value);
		} else {
			if(type.equals("work2")) {
				changeDao.addWorkTag(con, value, id);
			} else {
				changeDao.addTalkTag(con, value);
			}
		}
		
		return ;
	}
	//修改标签
	public void changeTag(Connection con, String type, int id, String value) throws SQLException {
		if(type.equals("work1")) {
			changeDao.changeBWorkTag(con, id, value);
		} else {
			if(type.equals("work2")) {
				changeDao.changeWorkTag(con, id, value);
			} else {
				changeDao.changeTalkTag(con, id, value);
			}
		}
		
		return ;
	}
}
