var flag = 0;
var E = window.wangEditor;
var editor;
function loading(type, x) {
	for(var i = 0; i < 3; i++) {
		var area = 'bnt' + i;
		var item = document.getElementById(area);
		if(i == type) {
			item.style.backgroundColor = "rgb(110,155,194)";
			item.style.borderColor = "rgb(110,155,194)";
		} else {
			item.style.backgroundColor = "rgb(208,207,207)";
			item.style.borderColor = "rgb(208,207,207)";
		}
	}
	
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		dataType: "json",
		data: {"page": "adnotice", "type": type, "num": x},
		success:function(data) {
			var item = eval(data);
			
			var str = '<div class="col-md-10 table_width" id="Row"><table class="table table-hover col-md-offset-1 col-md-5">';
			str += '<tr><th class="col-md-1"><input type="checkbox" id="checkAllbox" aria-label="..." onclick="check_all()"></th>' +
						'<th class="col-md-5" style="text-align: center ">公告</th>' +
						'<th class="col-md-1" style="text-align: center ">发布者</th>' +
						'<th class="col-md-2" style="text-align: center ">时间</th>' +
						'<th class="col-md-1" style="text-align: center ">操作</th></tr>';
			for(var i = 0; i < item.notice.length; i++) {
				str += '<tr onclick="showNotice(' + item.notice[i].id + ', ' + x + ', ' + type + ')"><td class="col-md-1"><input type="checkbox" name="selectall" id="blankCheckbox" value="' + item.notice[i].id + '" aria-label="..."></td>' +
						'<td class="col-md-5">' + item.notice[i].title + '</td>' +
						'<td class="col-md-1" style="text-align: center " >' + item.notice[i].user + '</td>' +
						'<td class="col-md-2" style="text-align: center ">' + item.notice[i].time + '</td>' +
						'<td class="col-md-1 do_some" style="text-align: center "><span class="glyphicon glyphicon-remove" aria-hidden="true" onclick="dele(' + item.notice[i].id + ', ' + x + ', ' + type + ')"></span></td></tr>';	
			}
			str += '</table></div>';
			str += '<nav aria-label="Page navigation" style="text-align: center; clear: both;"><ul class="pagination" id="pageUl">';
			
//        	页码计算
        	var beginstr, endstr;
        	var num = item.sum;
        	var start = x;
        	if(start == 0) {
        		beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
      	      		       "<li class=\"active\"><span>1 <span class=\"sr-only\">(current)</span></span></li>";  
        		if(num > 30) {
        			endstr = "<li><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        		} else {
        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>"
        		}
        	} else {
        		if(num > 30) {
        			if(start >= 18) {
        				beginstr = "<li><span><span aria-hidden=\"true\">&laquo;</span></span></li>";
        				if((start + 18) < num) {
        					endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        				} else {
        					endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        				}
        			} else {
        				beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
  	                               "<li><a onclick=\"loading(" + type + ", 0)\" style=\"color:grey;cursor:pointer;\">1</a></li>";
        				endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        			}
        		} else {
        			beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
                               "<li><a onclick=\"loading(" + type + ", 0)\" style=\"color:grey;\">1</a></li>";
        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        		}
        	}
        	
        	var nowpage = (start + 6) / 6;
        	
        	if(nowpage <= 3) {
        		for(var r = 2; r <= 5; r++) {
        			from = (r-1) * 6;
        			if(from >= num) {
        				break;
        			}
        			if(r == nowpage) {
        				beginstr += "<li class=\"active\"><span>" + r + " <span class=\"sr-only\">(current)</span></span></li>";
        			} else {
        				beginstr += "<li><a onclick=\"loading(" + type + ", " + from + ")\" style=\"color:grey; cursor:pointer;\">" + r + "</a></li>";
        			}
        		}
        		beginstr += endstr;
        	}else {
        		for(var r = 1; r < 3; r++) {
        			from = start - r * 6;
        			beginstr += "<li><a onclick=\"loading(" + type + ", " + from + ")\" style=\"color:grey;cursor:pointer;\">" + (nowpage-r) + "</a></li>";
        		}
        		beginstr += "<li class=\"active\"><span>" + nowpage + " <span class=\"sr-only\">(current)</span></span></li>";
        		for(var r = 0; r < 2; r++) {
        			from = end + r * 6;
        			if(from < num) {
        				beginstr += "<li><a onclick=\"loading(" + type + ", " + from + ")\" style=\"color:grey;cursor:pointer;\">" + (nowpage + r + 1) + "</a></li>";
        			}        			
        		}
        		beginstr += endstr;
        	}
        	str += beginstr;
        	str += '</ul></nav>';
        	var area = document.getElementById('Row');
        	area.style.marginTop = '3%';
        	area.style.marginLeft = '0%';
        	area.innerHTML = str;
        	
        	var select_all = document.getElementById('checkAllbox');
        	var check_box = document.getElementsByName('selectall');
        	for (var i = check_box.length - 1; i >= 0; i--) {
        		check_box[i].onclick = function() {
        			flag = 1;
        			select_all.checked = false;
        		};
        	};
		},
		error:function(json) {
			
		}
	});
}

function loadAdd() {
	for(var i = 0; i < 3; i++) {
		var area = 'bnt' + i;
		var item = document.getElementById(area);
		if(i == 2) {
			item.style.backgroundColor = "rgb(110,155,194)";
			item.style.borderColor = "rgb(110,155,194)";
		} else {
			item.style.backgroundColor = "rgb(208,207,207)";
			item.style.borderColor = "rgb(208,207,207)";
		}
	}
	
	var area = document.getElementById('Row');
	var str = '<div class="form-horizontal"><div class="form-group">' +
    			'<label for="title" class="col-sm-2 control-label ad-notic-title">标题：</label>' +
    			'<div class="col-sm-7"><input type="text" class="form-control" id="title" placeholder="标题"></div></div>' +
    			'<div class="form-group"><label for="content" class="col-sm-2 control-label ad-notic-title">内容：</label>' +
    			'<div class="col-sm-7"><div id="editor" class="editor"></div></div></div>' +
    			'<div class="form-group"><div class="col-sm-offset-8 col-sm-2"><button class="btn btn-default" onclick="publish()">发布</button></div></div></div>';
	area.style.marginTop = '5%';
	area.style.marginLeft = '6%';
	area.innerHTML = str;
	
	editor = new E('#editor');
    // 自定义菜单配置
    editor.customConfig.menus = [
        
    ];
    editor.create();
    editor.txt.html('');
	
	document.getElementById('pageUl').innerHTML = "";
}

function publish() {
	var title = document.getElementById('title').value;
	var context = editor.txt.html();
	if(title == '' || context == '') {
		alert('信息未完整');
		return false;
	} else {
		$.ajax({
			type: "GET",
			url: "/software/ChangeServlet",
			data: {"type": "addNotice", "title": title, "context": context},
			dataType: "json",
			success:function(data) {
				var item = eval(data);
				if(item.status == "false") {
					alert('用户已下线，请重新登陆');
				} else {
					alert('添加成功');
					loading(0, 0)
				}
			},
			error:function(json) {
				alert('66');
			}
		});
	}
	
}

function dele(id, page, type) {
	flag = 1;
	var r = confirm("是否删除该公告");
	if(r == true) {
		$.ajax({
			type: "GET",
			url: "/software/ChangeServlet",
			data: {"type": "delenotice", "id": id},
			dataType: "json",
			success: function(data) {
				var item = eval(data);
				alert("删除成功");
				loading(type, page);
			},
			error: function(json) {
				
			}
		});
	}
}

function check_all() {
	var check_box = document.getElementsByName('selectall');
	var select_all = document.getElementById('checkAllbox');
	
	if(select_all.checked == true)
	{
		for (var i = check_box.length - 1; i >= 0; i--) {
			check_box[i].checked = true;
		}
	}else {
		for (var i = check_box.length - 1; i >= 0; i--) {
			check_box[i].checked = false;
		}
	}
}

function deleSome() {
	var check_box = document.getElementsByName('selectall');
	var select_all = document.getElementById('checkAllbox');
	var num = new Array();
	for (var i = check_box.length - 1; i >= 0; i--) {
		if(check_box[i].checked == true) {
			num.push(check_box[i].value);
		}
	}
	var sum = num.length;
	
	$.ajax({
		type: "POST",
		traditional: true,
		url: "/software/ChangeServlet",
		data: {"type": "delesomenotice", "num": num},
		dataType: "json",
		success:function(data) {
			alert("已删除" + sum + "条记录");
			loading(0, 0);
		},
		error:function(json) {
			alert("请刷新重试");
		}
	});
}

function showNotice(id, page, type) {
	$.ajax({
		type: "GET",
		url: "/software/SingelServlet",
		data: {"type": "notic", "id":id},
		dataType: "json",
		success:function(data) {
			var item = eval(data);
			var str = "";
			var btn = "";
			$('#myModal').modal('show');
			
			str = '<div class="row"><div class="col-md-offset-1 col-md-2 work-show-name">标题：</div><div class="col-md-8 work-show-value">' + item.title + '</div></div>' +
				  '<div class="row"><div class="col-md-offset-1 col-md-2 work-show-name">作者：</div><div class="col-md-8 work-show-value">' + item.user + '</div></div>' +
				  '<div class="row"><div class="col-md-offset-1 col-md-2 work-show-name">时间：</div><div class="col-md-8 work-show-value">' + item.time + '</div></div>' +
				  '<div class="row"><div class="col-md-offset-1 col-md-2 work-show-name">内容：</div><div class="col-md-8 work-show-text" id="describe">' + item.content + '</div></div>';
				
			btn = '<button type="button" class="btn btn-default" data-dismiss="modal" onclick="dele(' + id + ', \'' + page + '\', ' + type + ')">删除</button>';
			
			$('#modal-body').html(str);
			$('#modal-btn').html(btn);
		},
		error:function(json) {
			
		}
	});
}