var x = 0;
var type = 0;
var base = 0;
//var E = window.wangEditor;
//var editor = new E('#editor');
//editor.customConfig.menus = [];
//editor.txt.html('lala');
//editor.create();
function loadingTalk() {
	x = parseInt(getParams("page"));
	type = getParams("type");  //0 无搜索    1 标签   2 话题
	base = getParams("base");
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {"page": "talk", "num": x, "type": type, "base": base},
		dataType: "json",
		success:function(data) {
			var item = eval(data);
			//用户名
			var nav = "<ul>" +
					"<li><a href=\"./index.html\">首页</a></li>" +
					"<li><a href=\"./sort.html\">排行</a></li>" +
					"<li><a href=\"./classify.html\">分类</a></li>" +
					"<li><a href=\"talk.html?page=0&type=0&base=0\">话题</a></li>";
 					  
        	if(item.name == "")
        	{
        		nav += "<li><a href=\"./login.html\">登录</a></li>";
        	} else {
        		nav += "<li><a href=\"./myself.html\">" + item.name + "</a></li>" +
        			   "<li><a href=\"/software/ExitServlet\">登出</a></li>";
        	}
        	nav += "</ul>";
        	var area = document.getElementById('nav');
        	area.innerHTML = nav;
			//标签插入
			var str = "<ul>";
			var str2 = "";
			for(var i = 0; i < item.tagnum; i++) {
				str += "<li><a href=\"./talk.html?page=0&type=1&base=" + item.alltag[i].value + "\"><img src=\"../TagPic/" + item.alltag[i].img + "\"><span>" + item.alltag[i].value + "</span></a></li>"
				str2 += '<option value ="' + item.alltag[i].id + '">' + item.alltag[i].value + '</option>'
			}
			str += "</ul>";
			document.getElementById('topic').innerHTML = str;
			document.getElementById('select').innerHTML = str2;
			//讨论加载
			str = "<ul>";
			for(var i = 0; i < item.talknum; i++) {
				str += "<li><a href=\"discuss.html?id=" + item.talk[i].id + "&page=0\">" +
						"<div class=\"who\"><img src=\"../UserPic/" + item.talk[i].img + "\"><span>" + item.talk[i].user + "</span></div>" +
						"<div class=\"talk\"><div class=\"title\">" + item.talk[i].title + "</div>" +
						"<div class=\"des\">" + item.talk[i].content + "</div></div>" +
						"<div class=\"detail\">";
				for(var j = 0; j < item.talk[i].tagnum; j++) {
					str += "<div class=\"belong\">" + item.talk[i].tag[j].value + "</div>";
				}
				str += "<div class=\"pic\"><img src=\"../img/talk/eye.png\">" + item.talk[i].look + "&nbsp;&nbsp;" +
						"<img src=\"../img/talk/reply.png\">" + item.talk[i].reply + "</div><div class=\"time\">" + item.talk[i].time + "</div></div></a></li>";			
							
			}
			str += "</ul>";
			//页码加载
			x = x + 1;
			var sum = item.talksum;
			str += "<div class=\"page\"><ul>";
			if(sum%5 > 0) {
				sum = parseInt(sum/5) + 1;
			} else {
				sum = parseInt(sum/5);
			}
			var cnt = 4;
			if(x == 1) {
				str += "<li class=\"noactive\"><a>...</a></li>" + 
				       "<li class=\"noactive\"><a>1</a></li>";
			} else {
				str += "<li><a href=\"talk.html?page=" + (x-2) + "&type=0&base=0\">...</a></li>";
				var y = 2;
				if(sum-x < 2) {
					y = 4 - sum + x;
				}
				for(var i = x-y; i < x; i++) {
					if(i <= 0) {
						continue;
					}
					str += "<li><a href=\"talk.html?page=" + (i-1) + "&type=0&base=0\">" + i + "</a></li>";
					cnt--;
				}
				str += "<li class=\"noactive\"><a>" + x + "</a></li>";
			}
			for(var i = x; cnt > 0; i++) {
				if(i+1 <= sum) {
					str += "<li><a href=\"talk.html?page=" + (i) + "&type=0&base=0\">" + (i+1) + "</a></li>";
					cnt--;
				} else {
					break;
				}
			}
			if(cnt == 0 && x+2 < sum) {
				str += "<li><a href=\"talk.html?page=" + (x) + "&type=0&base=0\">...</a></li>";
			} else {
				str += "<li class=\"noactive\"><a>...</a></li>";
			}
			str += "</ul></div>";
			
			if(item.talksum == 0) {
				str = '<img src="../img/empty.png"/ style="width: 400px; height: 400px;">';
			}
			document.getElementById('everypost').innerHTML = str;
			//热门加载
			str = "<ul>";
			for(var i = 0; i < item.HotTalk.length; i++) {
				str += "<li><a href=\"discuss.html?id=" + item.HotTalk[i].id + "&page=0\"><p>" + item.HotTalk[i].title + "</p><p>发话人：" + item.HotTalk[i].user + "<span>" + item.HotTalk[i].time + "</span></p></a></li>";
			}
			str += "</ul>";
			document.getElementById('hot_topic_ul').innerHTML = str;
		},
		error:function(json) {
			
		}
	});
}

function getParams(key) {
    var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
    var l = decodeURI(window.location.search);  
    var r = l.substr(1).match(reg);   
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

var postPart = function() {
	return {
		closeOn: function() {
			var area = document.getElementById('close');
			area.src = "../img/talk/close2.png";
		},
		closeOut: function() {
			var area = document.getElementById('close');
			area.src = "../img/talk/close.png";
		},
		closePost: function() {
			var area = document.getElementById('showPart');
			area.style.display = "none";
		},
		showPost: function() {
			var area = document.getElementById('showPart');
			area.style.display = "";
		},
		postTalk: function() {
			var title = document.getElementById('talktitle').value;
			var select = document.getElementById('select').value;
			if(title == "" || editor.txt.text() == "") {
				alert("标题与内容不能为空");
				return false;
			}
			$.ajax({
				type: "POST",
				url: "/software/ChangeServlet",
				data: {"type": "postTalk", "title": title, "context": editor.txt.html(), "select": select},
				dataType: "json",
				success:function(data) {
					item = eval(data);
					if(item.status == "false") {
						alert("目前您尚未登录，请登陆或注册后进行发表");
					} else {
						alert("发表成功！");
						window.location.href = "talk.html?page=0&type=0&base=0";
					}
				},
				error:function(json) {
					
				}
			});
			var area = document.getElementById('showPart');
			area.style.display = "none";
		}
	};
}();

function search() {
	var base = document.getElementById('search').value;
	window.location.href = "talk.html?page=0&type=2&base=" + base;
}