function otherWork(x) {
	$.ajax({
		type: "GET",
		url: "/software/WorkOperationServlet",
		data: {"type": "other", "num": x},
		dataType: "json",
		success:function (data) {
			var item = eval(data);
			if(item.status == "true") {
				alert("清理成功");
			} else {
				alert("请刷新重试");
			}
		},
		error:function (json) {
			alert("请刷新重试");
		}
	});
}