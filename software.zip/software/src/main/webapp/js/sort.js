function loadingSortPage() {
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {'page': 'sort'},  
        dataType:"json",
        success:function(data){
        	var item = eval(data);
        	//用户名
        	var nav = "<ul>" +
					"<li><a href=\"./index.html\">首页</a></li>" +
					"<li><a href=\"./sort.html\">排行</a></li>" +
					"<li><a href=\"./classify.html\">分类</a></li>" +
					"<li><a href=\"talk.html?page=0&type=0&base=0\">话题</a></li>";
 					  
        	if(item.name == "")
        	{
        		nav += "<li><a href=\"./login.html\">登录</a></li>";
        	} else {
        		nav += "<li><a href=\"./myself.html\">" + item.name + "</a></li>" +
 			   			"<li><a href=\"/software/ExitServlet\">登出</a></li>";
        	}
        	nav += "</ul>";
        	var area = document.getElementById('nav');
        	area.innerHTML = nav;
        	
        	//排行榜
        	//down
        	var str = '<li><div class="one">排名</div><div class="two">资源名称</div><div class="three">下载次数</div></li>';
        	for(var i = 0; i < item.down.length; i++) {
        		str += '<li><a href="show.html?name=' + item.down[i].name + '&user=' + item.down[i].user + '"><div class="one"><img src="../img/sort/' + i + '.png">' +
 						'</div><div class="two">' + item.down[i].name + '</div>' +
 						'<div class="three">' + item.down[i].down + '</div></a></li>';				
        	}
        	document.getElementById('down').innerHTML = str;
        	
        	//good
        	str = '<li><div class="one">排名</div><div class="two">资源名称</div><div class="three">收藏次数</div></li>';
        	for(var i = 0; i < item.good.length; i++) {
        		str += '<li><a href="show.html?name=' + item.good[i].name + '&user=' + item.good[i].user + '"><div class="one"><img src="../img/sort/' + i + '.png">' +
 						'</div><div class="two">' + item.good[i].name + '</div>' +
 						'<div class="three">' + item.good[i].good + '</div></a></li>';				
        	}
        	document.getElementById('good').innerHTML = str;
        	
        	//grade
        	str = '<li><div class="one">排名</div><div class="two">资源名称</div><div class="three">评分</div></li>';
        	for(var i = 0; i < item.grade.length; i++) {
        		str += '<li><a href="show.html?name=' + item.grade[i].name + '&user=' + item.grade[i].user + '"><div class="one"><img src="../img/sort/' + i + '.png">' +
 						'</div><div class="two">' + item.grade[i].name + '</div>' +
 						'<div class="three">' + item.grade[i].grade + '</div></a></li>';				
        	}
        	document.getElementById('grade').innerHTML = str;
        	
        	//time
        	str = '<li><div class="one">排名</div><div class="two">资源名称</div><div class="three">上传用户</div></li>';
        	for(var i = 0; i < item.time.length; i++) {
        		str += '<li><a href="show.html?name=' + item.time[i].name + '&user=' + item.time[i].user + '"><div class="one"><img src="../img/sort/' + i + '.png">' +
 						'</div><div class="two">' + item.time[i].name + '</div>' +
 						'<div class="three">' + item.time[i].user + '</div></a></li>';				
        	}
        	document.getElementById('time').innerHTML = str;
        	
        	//teacher
        	str = '<li><div class="one">排名</div><div class="two">资源名称</div><div class="three">上传用户</div></li>';
        	for(var i = 0; i < item.teacher.length; i++) {
        		str += '<li><a href="show.html?name=' + item.teacher[i].name + '&user=' + item.teacher[i].user + '"><div class="one"><img src="../img/sort/' + i + '.png">' +
 						'</div><div class="two">' + item.teacher[i].name + '</div>' +
 						'<div class="three">' + item.teacher[i].user + '</div></a></li>';				
        	}
        	document.getElementById('teacher').innerHTML = str;
        	
        	//user
        	str = '<li><div class="one">排名</div><div class="two">用户名</div><div class="three">资源个数</div></li>';
        	for(var i = 0; i < item.user.length; i++) {
        		str += '<li><a href="search.html?value=' + item.user[i].user + '&base=用户&num=0"><div class="one"><img src="../img/sort/' + i + '.png">' +
 						'</div><div class="two">' + item.user[i].user + '</div>' +
 						'<div class="three">' + item.user[i].work + '</div></a></li>';				
        	}
        	document.getElementById('user').innerHTML = str;
        },
        error: function(json) {
        }
	});
}