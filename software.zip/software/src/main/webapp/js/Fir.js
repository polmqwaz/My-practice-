var area = document.getElementById('noticeul');

//index页面加载
function onloadIndex() {
	var flag = 0;
	$.ajax({  
		type: "GET",  
        url: "/software/LoadServlet",
        data: {'page': 'index'},  
        dataType:"json",  
        success: function(data){
        	var item = eval(data);
        	//用户名
        	var nav = "<ul>" +
 						"<li><a href=\"./index.html\">首页</a></li>" +
 						"<li><a href=\"./sort.html\">排行</a></li>" +
 						"<li><a href=\"./classify.html\">分类</a></li>" +
 						"<li><a href=\"talk.html?page=0&type=0&base=0\">话题</a></li>";
 					  
        	if(item.name[0].username == "")
        	{
        		nav += "<li><a href=\"./login.html\">登录</a></li>";
        	} else {
        		nav += "<li><a href=\"./myself.html\">" + item.name[0].username + "</a></li>" +
        			   "<li><a href=\"/software/ExitServlet\">登出</a></li>";
        	}
        	nav += "</ul>";
        	var area = document.getElementById('nav');
        	area.innerHTML = nav;
        	
        	//添加公告
        	var noticecontent = "<ul class=\"con1\" id=\"con1\">";
        	for(var i = 0; i < item.notice.length; i++)
        	{
        		noticecontent += "<li><a href=\"javascript:void(0)\" onclick=\"mainNotic.showNotic(" + item.notice[i].id + ")\"><span>" + item.notice[i].title + "</span><span>" + item.notice[i].time + "</span></a></li>";
        	}
        	noticecontent += "</ul><ul class=\"con2\" id=\"con2\"></ul>";
        	area = document.getElementById('noticeul');
        	area.innerHTML = noticecontent;
        	
        	//公告滚动条动画
        	var area = document.getElementById('noticeul');
        	var con1 = document.getElementById('con1');
        	var con2 = document.getElementById('con2');
        	var speed = 40;
        	area.scrollTop = 0;
        	con2.innerHTML = con1.innerHTML;
        	var runNotice = self.setInterval("scrollUp()", speed);
        	area.onmouseover = function(){
        		clearInterval(runNotice);
        	};
        	area.onmouseout = function(){
        		runNotice = self.setInterval("scrollUp()",speed);
        	};
        	
        	//添加教师推荐
        	var i = 0, num = 0;
        	var teawork = "<div class=\"title\"><img src=\"../img/index/title.png\"><span><a href=\"sort.html\">更多...</a></span></div><ul>";
        	for(; i < 4; i++)
        	{
        		num = i + 1;
        		teawork += "<li onmouseover=\"mainWork.change(" + num + ")\" onmouseout=\"mainWork.changeback(" + num + ")\">" +
        				   "<a href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" +
        				   "<div class=\"pic\" id=\"pic" + num + "\"><img class=\"norm\" src=\"../WorkPic/" + item.work[i].workimg + "\"></div></a>" +
        				   "<div class=\"word\" id=\"word" + num + "\"><a class=\"workname\" href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" + item.work[i].name + "</a><a class=\"normword\" href=\"search.html?value=" + item.work[i].user + "&base=用户&num=0\">" +
        				   "<img class=\"normhead\" src=\"../UserPic/" + item.work[i].userimg + "\">&nbsp;" + item.work[i].user + "&nbsp;</a><p class=\"wordelse\" id=\"wordelse" + num + "\"><a href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" + item.work[i].describe + "</a></p></div>" +
        				   "</li>";
        	}
        	teawork += "</ul>";
        	var teacherwork  = document.getElementById('teacherwork');
        	teacherwork.innerHTML = teawork;
        	
        	//添加最新作品
        	var newwork = "<div class=\"title\"><img src=\"../img/index/title2.png\"><span><a href=\"sort.html\">更多...</a></span></div><ul>";
        	for(; i < 8; i++)
        	{
        		num = i + 1;
        		newwork += "<li onmouseover=\"mainWork.change(" + num + ")\" onmouseout=\"mainWork.changeback(" + num + ")\">" +
        				   "<a href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" +
        				   "<div class=\"pic\" id=\"pic" + num + "\"><img class=\"norm\" src=\"../WorkPic/" + item.work[i].workimg + "\"></div>" +
        				   "<div class=\"word\" id=\"word" + num + "\"><a class=\"workname\" href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" + item.work[i].name + "</a><a class=\"normword\" href=\"search.html?value=" + item.work[i].user + "&base=用户&num=0\">" +
        				   "<img class=\"normhead\" src=\"../UserPic/" + item.work[i].userimg + "\">&nbsp;" + item.work[i].user + "&nbsp;</a><p class=\"wordelse\" id=\"wordelse" + num + "\"><a href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" + item.work[i].describe + "</a></p></div>" +
        				   "</li>";
        	}
        	newwork += "</ul>";
        	var newworkload  = document.getElementById('newwork');
        	newworkload.innerHTML = newwork;
        	
        	
        	//添加最热作品
        	var hotwork = "<div class=\"title\"><img src=\"../img/index/title3.png\"><span><a href=\"sort.html\">更多...</a></span></div><ul>";
        	for(; i < 12; i++)
        	{
        		num = i + 1;
        		hotwork += "<li onmouseover=\"mainWork.change(" + num + ")\" onmouseout=\"mainWork.changeback(" + num + ")\">" +
        				   "<a href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" +
        				   "<div class=\"pic\" id=\"pic" + num + "\"><img class=\"norm\" src=\"../WorkPic/" + item.work[i].workimg + "\"></div></a>" +
        				   "<div class=\"word\" id=\"word" + num + "\"><a class=\"workname\"  href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" + item.work[i].name + "</a><a class=\"normword\" href=\"search.html?value=" + item.work[i].user + "&base=用户&num=0\">" +
        				   "<img class=\"normhead\" src=\"../UserPic/" + item.work[i].userimg + "\">&nbsp;" + item.work[i].user + "&nbsp;</a><p class=\"wordelse\" id=\"wordelse" + num + "\"><a  href=\"show.html?name=" + item.work[i].name + "&user=" + item.work[i].user + "\">" + item.work[i].describe + "</a></p></div>" +
        				   "</li>";
        	}
        	newwork += "</ul>";
        	var hotworkload  = document.getElementById('hotwork');
        	hotworkload.innerHTML = hotwork;
        	
        },  
        error: function(json){
        }  
    }); 
}


//公告滚动条
function scrollUp() {
	if(area.scrollTop > con1.scrollHeight) {
		area.scrollTop = 0;
	}else{
		area.scrollTop ++;
	}
}

//搜索框
var searchItem=new Array("作品名", "描述", "关键字", "用户");
var mainSearch = function() {
	return {
		else:function() {
			var way = document.getElementById('select');
			if(way.style.display == "") {
				way.style.display = "none";
			} else {
				way.style.display = "";
			}
		},
		item:function(x) {
			document.getElementById('searchContent').innerHTML = searchItem[x];
			var way = document.getElementById('select');
			way.style.display = "none";
		},
		search:function() {
			var value = document.getElementById('search').value;
			var base = document.getElementById('searchContent').innerHTML;
			window.location.href = "search.html?value=" + value + "&base=" + base + "&num=0";
		}
	};
}();

//公告
var mainNotic = function() {
	return {
		showNotic:function(x) {
			$.ajax({
				type: "GET",
				url: "/software/SingelServlet",
				data: {"type": "notic", "id":x},
				dataType: "json",
				success:function(data) {
					var item = eval(data);
					document.getElementById('notic-title').innerHTML = item.title;
					document.getElementById('notic-time').innerHTML = item.time;
					document.getElementById('notic-content').innerHTML = item.content;
				},
				error:function(json) {
					
				}
			});
			
			var area = document.getElementById('showNotic');
			area.style.top = "calc(50% - 200px)";
			area.style.transition = "top 1.5s";
		},
		closeNotic:function() {
			var area = document.getElementById('showNotic');
			area.style.top = "calc(0% - 1000px)";
		}
	};
}();


//index页面的动画
var mainWork = function() {
	return {
		change:function(num) {
			var s1;
			s1 = 'pic' + num;
			var part1 = document.getElementById(s1);
			s1 = 'word' + num;
			var part2 = document.getElementById(s1);
			part1.style.height = "1%";
			part1.style.transition = "height 0.5s";
			part2.style.transition = "height 0.5s";
		},
		changeback:function(num) {
			var s1;
			s1 = 'pic' + num;
			var part1 = document.getElementById(s1);
			s1 = 'word' + num;
			var part2 = document.getElementById(s1);
			part1.style.height = "80%";
			part2.style.height = "20%";
			part1.style.transition = "height 0.5s";
			part2.style.transition = "height 0.5s";
		}
	};
}();