var item1 = 0, iitem1 = 0;
var item2 = '全部', iitem2 = '全部', item3 = 'time', tem = 0;
function loading(x, Tag, tag, on) {
	item2 = Tag;
	iitem2 = tag;
	item3 = on;
	tem = 0;
	document.getElementsByName('searchContent')[0].value = "";
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {"page": "classify", "num": x, "Tag": Tag, "tag": tag, "on": on},
		dataType: "json",
		success: function(data) {
			var item = eval(data);
			var num = item.tag;
			
			//用户名
        	var nav = "<ul>" +
 						"<li><a href=\"./index.html\">首页</a></li>" +
 						"<li><a href=\"./sort.html\">排行</a></li>" +
 						"<li><a href=\"./classify.html\">分类</a></li>" +
 						"<li><a href=\"talk.html?page=0&type=0&base=0\">话题</a></li>";
 					  
        	if(item.name == "")
        	{
        		nav += "<li><a href=\"./login.html\">登录</a></li>";
        	} else {
        		nav += "<li><a href=\"./myself.html\">" + item.name + "</a></li>" +
        			   "<li><a href=\"/software/ExitServlet\">登出</a></li>";
        	}
        	nav += "</ul>";
        	var area = document.getElementById('nav');
        	area.innerHTML = nav;
        	
			
			if(Tag == '全部') {
				var str = '<div class="active" id="Item0" onclick="selectIt(0)">全部</div>';
				for(var i = 0; i < item.Tag.length; i++) {
					str += '<div class="item" id="Item' + (i+1) + '" onclick="selectIt(' + (i+1) + ')">' + item.Tag[i].tag + '</div>';
				}
				document.getElementById("Btag").innerHTML = str;
				
				str = '<div class="active" id="item0" onclick="selectit(0)">全部</div>';
				document.getElementById("tag").innerHTML = str;
				item2 = '全部';
				item1 = 0;
				iitem2 = '全部';
				iitem1 = 0;
			} else {
				if(tag == '全部') {
					var str = '<div class="active" id="item0" onclick="selectit(0)">全部</div>';
					for(var i = 0; i < item.tag.length; i++) {
						str += '<div class="item" id="item' + (i+1) + '" onclick="selectit(' + (i+1) + ')">' + item.tag[i].tag + '</div>';
					}
					document.getElementById("tag").innerHTML = str;
					iitem2 = '全部';
					iitem1 = 0;
				}
			}
			
			str = '';
			for(var i = 0; i < item.work.length; i++) {
				str += '<li><a href=\"show.html?name=' + item.work[i].name + '&user=' + item.work[i].user + '\"><div class="li-title"><img src="../WorkPic/' + item.work[i].img + '">' +
 						'</div><div class="li-content"><div class="row1">' + item.work[i].name + '</div>' +
 						'<div class="row2">' + item.work[i].word + '</div>' +
 						'<div class="row3"><span>下载次数：' + item.work[i].down + '</span><span>上传时间：' + item.work[i].time + '</span>' +
 						'<span>上传者：' + item.work[i].user + '</span></div></div></a></li>';
			}
			document.getElementById('Ul').innerHTML = str;
			
			//页码加载
			num = parseInt(x) + 1;
			var sum = parseInt(item.sum);
			str = "<ul>";
			if(sum%7 > 0) {
				sum = parseInt(sum/7) + 1;
			} else {
				sum = parseInt(sum/7);
			}
			var cnt = 4;
			if(num == 1) {
				str += "<li class=\"noactive\"><a>...</a></li>" + 
				       "<li class=\"noactive\"><a>1</a></li>";
			} else {
				str += "<li><a href=\"javascript:void(0);\" onclick=\"loading(" + (num-2) + ", '" + Tag + "', '" + tag + "', '" + on + "')\">...</a></li>";
				var y = 2;
				if(sum-num < 2) {
					y = 4 - sum + num;
				}
				for(var i = num-y; i < num; i++) {
					if(i <= 0) {
						continue;
					}
					str += "<li><a href=\"javascript:void(0);\" onclick=\"loading(" + (i-1) + ", '" + Tag + "', '" + tag + "', '" + on + "')\">" + i + "</a></li>";
					cnt--;
				}
				str += "<li class=\"noactive\"><a>" + num + "</a></li>";
			}
			for(var i = num; cnt > 0; i++) {
				if(i+1 <= sum) {
					str += "<li><a href=\"javascript:void(0);\" onclick=\"loading(" + (i) + ", '" + Tag + "', '" + tag + "', '" + on + "')\">" + (i+1) + "</a></li>";
					cnt--;
				} else {
					break;
				}
			}
			if(cnt == 0 && num+2 < sum) {
				str += "<li><a href=\"javascript:void(0);\" onclick=\"loading(" + (num) + ", '" + Tag + "', '" + tag + "', '" + on + "')\">...</a></li>";
			} else {
				str += "<li class=\"noactive\"><a>...</a></li>";
			}
			str += "</ul>";
			document.getElementById('page').innerHTML = str;
			
			if(x != 0) {
				window.location.hash = "#Ul";
			}
		},
		error: function(json) {
			
		}
	});
}

function selectIt(x) {
	var str = 'Item' + x;
	var area = document.getElementById(str);
	str = 'Item' + item1;
	var area2 = document.getElementById(str);

	area.className = "active";
	area2.className = "item";
	item1 = x;

	str = '<span>' + area.innerHTML + '</span><span>全部</span>';
	document.getElementById('ans').innerHTML = str;
	loading(0, area.innerHTML, '全部', 'time');
	area.className = "active";
	area2.className = "item";
}

function selectit(x) {
	var str = 'item' + x;
	var area = document.getElementById(str);
	str = 'item' + iitem1;
	var area2 = document.getElementById(str);

	area.className = "active";
	area2.className = "item";
	iitem1 = x;

	str = 'Item' + item1;
	var area2 = document.getElementById(str);
	str = '<span>' + area2.innerHTML + '</span><span>' + area.innerHTML + '</span>';
	document.getElementById('ans').innerHTML = str;
	loading(0, area2.innerHTML, area.innerHTML, 'time');
}

function search(x, on) {
	tem = 1;
	var area = document.getElementsByName('searchContent');
	var value = area[0].value;
	if(value == 0) {
		alert('请输入关键词搜索内容');
		return false;
	}
	var op = new Array();
	var items = value.split(" ");
	var str1 = 'Item' + item1;
	var first = document.getElementById(str1);
	var str = '<span>' + first.innerHTML + '</span>';
	op[0] = first.innerHTML;
	str1 = 'item' + iitem1;
	first = document.getElementById(str1);
	str += '<span>' + first.innerHTML + '</span>';
	op[1] = first.innerHTML;
	for(var i = 0; i < items.length; i++) {
		op[i+2] = items[i];
		str += '<span>' + items[i] + '</span>';
	}
	document.getElementById('ans').innerHTML = str;
	
	$.ajax({
		type: "GET",
		traditional: true,
		url: "/software/LoadServlet",
		data: {"page": "classify2", "num": x, "values": op, "on": on},
		dataType: "json",
		success:function(data) {
			var item = eval(data);
			//用户名
        	var nav = "<ul>" +
 						"<li><a href=\"./index.html\">首页</a></li>" +
 						"<li><a href=\"./sort.html\">排行</a></li>" +
 						"<li><a href=\"./classify.html\">分类</a></li>" +
 						"<li><a href=\"talk.html?page=0&type=0&base=0\">话题</a></li>";
 					  
        	if(item.name == "")
        	{
        		nav += "<li><a href=\"./login.html\">登录</a></li>";
        	} else {
        		nav += "<li><a href=\"./myself.html\">" + item.name + "</a></li>" +
        			   "<li><a href=\"/software/ExitServlet\">登出</a></li>";
        	}
        	nav += "</ul>";
        	var area = document.getElementById('nav');
        	area.innerHTML = nav;       	
			
			str = '';
			for(var i = 0; i < item.work.length; i++) {
				str += '<li><a href=\"show.html?name=' + item.work[i].name + '&user=' + item.work[i].user + '\"><div class="li-title"><img src="../WorkPic/' + item.work[i].img + '">' +
 						'</div><div class="li-content"><div class="row1">' + item.work[i].name + '</div>' +
 						'<div class="row2">' + item.work[i].word + '</div>' +
 						'<div class="row3"><span>下载次数：' + item.work[i].down + '</span><span>上传时间：' + item.work[i].time + '</span>' +
 						'<span>上传者：' + item.work[i].user + '</span></div></div></a></li>';
			}
			document.getElementById('Ul').innerHTML = str;
			
			//页码加载
			num = parseInt(x) + 1;
			var sum = parseInt(item.sum);
			str = "<ul>";
			if(sum%7 > 0) {
				sum = parseInt(sum/7) + 1;
			} else {
				sum = parseInt(sum/7);
			}
			var cnt = 4;
			if(num == 1) {
				str += "<li class=\"noactive\"><a>...</a></li>" + 
				       "<li class=\"noactive\"><a>1</a></li>";
			} else {
				str += "<li><a href=\"javascript:void(0);\" onclick=\"loading(" + (num-2) + ", '" + tag + "', '" + on + "')\">...</a></li>";
				var y = 2;
				if(sum-num < 2) {
					y = 4 - sum + num;
				}
				for(var i = num-y; i < num; i++) {
					if(i <= 0) {
						continue;
					}
					str += "<li><a href=\"javascript:void(0);\" onclick=\"loading(" + (i-1) + ", '" + tag + "', '" + on + "')\">" + i + "</a></li>";
					cnt--;
				}
				str += "<li class=\"noactive\"><a>" + num + "</a></li>";
			}
			for(var i = num; cnt > 0; i++) {
				if(i+1 <= sum) {
					str += "<li><a href=\"javascript:void(0);\" onclick=\"loading(" + (i) + ", '" + tag + "', '" + on + "')\">" + (i+1) + "</a></li>";
					cnt--;
				} else {
					break;
				}
			}
			if(cnt == 0 && num+2 < sum) {
				str += "<li><a href=\"javascript:void(0);\" onclick=\"loading(" + (num) + ", '" + tag + "', '" + on + "')\">...</a></li>";
			} else {
				str += "<li class=\"noactive\"><a>...</a></li>";
			}
			str += "</ul>";
			document.getElementById('page').innerHTML = str;
			
			if(x != 0) {
				window.location.hash = "#Ul";
			}
		},
		error:function(json) {
			alert("请刷新重试");
		}
	});
}

function sort(type, str) {
	if(tem == 1) {
		search(0, str);
	} else {
		loading(0, item2, iitem2, str);
	}
	for(var i = 1; i <=2; i++) {
		var str = 'btu' + i;
		if(type == i) {
			var area = document.getElementById(str);
			area.className = "active";
		} else {
			var area = document.getElementById(str);
			area.className = "noactive";
		}
	}
}