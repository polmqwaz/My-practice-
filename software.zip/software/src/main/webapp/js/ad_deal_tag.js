function loading(type, page, id) {
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {"page": "adTag", "type": type, "num": page, "id": id},
		dataType: "json",
		success:function(data) {
			var item = eval(data);
			
			var msg = '';
			if(type == 'All' || type == 'work1') {
				msg = ' <div class="row title">资源一级标签<button onclick="addTag(\'work1\', 0)">添加标签</button></div><table class="table">';
				msg += '<tr><th class="col-md-1">#</th><th class="col-md-4">标签</th><th class="col-md-1">操作</th></tr>';

				for(var i = 0; i < item.work1.Tag.length; i++) 
				{
					msg += '<tr onclick="loading(\'work2\', 0, ' + item.work1.Tag[i].value + ')"><td class="col-md-1">' + (i+1) + '</td>' +
			               '<td class="col-md-4" id="work1' + i + '">' + item.work1.Tag[i].tag + '</td>' +
			               '<td class="col-md-1" id="op_work' + i + '"><span class="glyphicon glyphicon-pencil change_tag" aria-hidden="true"  onclick="changeTag(\'work1\', ' + i + ', ' + item.work1.Tag[i].value + ')"></span></td></tr>';
				}
				msg += '</table>';
				document.getElementById('part1').innerHTML = msg;
				
//	        	页码计算
	        	var beginstr, endstr;
	        	var num = item.work1.tag;
	        	var start = page * 8;
	        	var end = start + 8;
	        	if(start == 0) {
	        		beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	      	      		       "<li class=\"active\"><span>1 <span class=\"sr-only\">(current)</span></span></li>";  
	        		if(num > 40) {
	        			endstr = "<li><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        		} else {
	        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>"
	        		}
	        	} else {
	        		if(num > 40) {
	        			if(start >= 24) {
	        				beginstr = "<li><span><span aria-hidden=\"true\">&laquo;</span></span></li>";
	        				if((start + 24) < num) {
	        					endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        				} else {
	        					endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        				}
	        			} else {
	        				beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	  	                               "<li><a onclick=\"loading('work1', 0, 0)\" style=\"color:grey;cursor:pointer;\">1</a></li>";
	        				endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        			}
	        		} else {
	        			beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	                               "<li><a onclick=\"loading('work1', 0, 0)\" style=\"color:grey;\">1</a></li>";
	        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        		}
	        	}
	        	
	        	var nowpage = (start + 8) / 8;
	        	
	        	if(nowpage <= 3) {
	        		for(var r = 2; r <= 5; r++) {
	        			from = (r-1) * 8;
	        			if(from >= num) {
	        				break;
	        			}
	        			if(r == nowpage) {
	        				beginstr += "<li class=\"active\"><span>" + r + " <span class=\"sr-only\">(current)</span></span></li>";
	        			} else {
	        				beginstr += "<li><a onclick=\"loading('work1', " + (r-1) + ", 0)\" style=\"color:grey; cursor:pointer;\">" + r + "</a></li>";
	        			}
	        		}
	        		beginstr += endstr;
	        	}else {
	        		for(var r = 1; r < 3; r++) {
	        			from = start - r * 8;
	        			beginstr += "<li><a onclick=\"loading('work1', " + (nowpage-r-1) + ", 0)\" style=\"color:grey;cursor:pointer;\">" + (nowpage-r) + "</a></li>";
	        		}
	        		beginstr += "<li class=\"active\"><span>" + nowpage + " <span class=\"sr-only\">(current)</span></span></li>";
	        		for(var r = 0; r < 2; r++) {
	        			from = end + r * 8;
	        			if(from < num) {
	        				beginstr += "<li><a onclick=\"loading('work1', " + (nowpage + r) + ", 0)\" style=\"color:grey;cursor:pointer;\">" + (nowpage + r + 1) + "</a></li>";
	        			}        			
	        		}
	        		beginstr += endstr;
	        	}
	        	document.getElementById('page1').innerHTML = beginstr;
			} 
			
			if(type == 'All' || type == 'talk') {
				msg = ' <div class="row title">话题标签<button onclick="addTag(\'talk\', 0)">添加标签</button></div><table class="table">';
				msg += '<tr><th class="col-md-1">#</th><th class="col-md-4">标签</th><th class="col-md-1">操作</th></tr>';
				for(var i = 0; i < item.talk.Tag.length; i++) {
					msg += '<tr><td class="col-md-1">' + (i+1) + '</td>' +
							'<td class="col-md-4" id="talk' + i + '">' + item.talk.Tag[i].tag + '</td>' +
							'<td class="col-md-1" id="op_talk' + i + '"><span class="glyphicon glyphicon-pencil change_tag" aria-hidden="true"  onclick="changeTag(\'talk\', ' + i + ', ' + item.talk.Tag[i].value + ')"></span></td></tr>';
				}
				msg += '</table>';
				document.getElementById('part2').innerHTML = msg;
				
//	        	页码计算
	        	var beginstr, endstr;
	        	var num = item.talk.tag;
	        	var start = page * 8;
	        	var end = start + 8;
	        	if(start == 0) {
	        		beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	      	      		       "<li class=\"active\"><span>1 <span class=\"sr-only\">(current)</span></span></li>";  
	        		if(num > 40) {
	        			endstr = "<li><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        		} else {
	        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>"
	        		}
	        	} else {
	        		if(num > 40) {
	        			if(start >= 24) {
	        				beginstr = "<li><span><span aria-hidden=\"true\">&laquo;</span></span></li>";
	        				if((start + 24) < num) {
	        					endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        				} else {
	        					endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        				}
	        			} else {
	        				beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	  	                               "<li><a onclick=\"loading('talk' , 0, 0)\" style=\"color:grey;cursor:pointer;\">1</a></li>";
	        				endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        			}
	        		} else {
	        			beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	                               "<li><a onclick=\"loading('talk', 0, 0)\" style=\"color:grey;\">1</a></li>";
	        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        		}
	        	}
	        	
	        	var nowpage = (start + 8) / 8;
	        	
	        	if(nowpage <= 3) {
	        		for(var r = 2; r <= 5; r++) {
	        			from = (r-1) * 8;
	        			if(from >= num) {
	        				break;
	        			}
	        			if(r == nowpage) {
	        				beginstr += "<li class=\"active\"><span>" + r + " <span class=\"sr-only\">(current)</span></span></li>";
	        			} else {
	        				beginstr += "<li><a onclick=\"loading('talk', " + (r-1) + ", 0)\" style=\"color:grey; cursor:pointer;\">" + r + "</a></li>";
	        			}
	        		}
	        		beginstr += endstr;
	        	}else {
	        		for(var r = 1; r < 3; r++) {
	        			from = start - r * 8;
	        			beginstr += "<li><a onclick=\"loading('talk', " + (nowpage-r-1) + ", 0)\" style=\"color:grey;cursor:pointer;\">" + (nowpage-r) + "</a></li>";
	        		}
	        		beginstr += "<li class=\"active\"><span>" + nowpage + " <span class=\"sr-only\">(current)</span></span></li>";
	        		for(var r = 0; r < 2; r++) {
	        			from = end + r * 8;
	        			if(from < num) {
	        				beginstr += "<li><a onclick=\"loading('talk', " + (nowpage + r) + ", 0)\" style=\"color:grey;cursor:pointer;\">" + (nowpage + r + 1) + "</a></li>";
	        			}        			
	        		}
	        		beginstr += endstr;
	        	}
	        	
	        	document.getElementById('page2').innerHTML = beginstr;
			} 
			if(type == 'work2') {
				msg = ' <div class="row title">资源二级标签<button onclick="loading(\'work1\', 0, 0)">返回</button><button onclick="addTag(\'' + type + '\', ' + id + ')">添加标签</button></div><table class="table">';
				msg += '<tr><th class="col-md-1">#</th><th class="col-md-4">标签</th><th class="col-md-1">操作</th></tr>';
				for(var i = 0; i < item.work2.Tag.length; i++) {
					msg += '<tr><td class="col-md-1">' + (i+1) + '</td>' +
		               		'<td class="col-md-4" id="work2' + i + '">' + item.work2.Tag[i].tag + '</td>' +
		               		'<td class="col-md-1" id="op_work' + i + '"><span class="glyphicon glyphicon-pencil change_tag" aria-hidden="true"  onclick="changeTag(\'work2\', ' + i + ', ' + item.work2.Tag[i].value + ')"></span></td></tr>';
				}
				msg += '</table>';
				document.getElementById('part1').innerHTML = msg;
				
//	        	页码计算
	        	var beginstr, endstr;
	        	var num = item.work2.tag;
	        	var start = page * 8;
	        	var end = start + 8;
	        	if(start == 0) {
	        		beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	      	      		       "<li class=\"active\"><span>1 <span class=\"sr-only\">(current)</span></span></li>";  
	        		if(num > 40) {
	        			endstr = "<li><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        		} else {
	        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>"
	        		}
	        	} else {
	        		if(num > 40) {
	        			if(start >= 24) {
	        				beginstr = "<li><span><span aria-hidden=\"true\">&laquo;</span></span></li>";
	        				if((start + 24) < num) {
	        					endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        				} else {
	        					endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        				}
	        			} else {
	        				beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	  	                               "<li><a onclick=\"loading('work2' , 0, " + id +")\" style=\"color:grey;cursor:pointer;\">1</a></li>";
	        				endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        			}
	        		} else {
	        			beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
	                               "<li><a onclick=\"loading('work2', 0, " + id +")\" style=\"color:grey;\">1</a></li>";
	        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
	        		}
	        	}
	        	
	        	var nowpage = (start + 8) / 8;
	        	
	        	if(nowpage <= 3) {
	        		for(var r = 2; r <= 5; r++) {
	        			from = (r-1) * 8;
	        			if(from >= num) {
	        				break;
	        			}
	        			if(r == nowpage) {
	        				beginstr += "<li class=\"active\"><span>" + r + " <span class=\"sr-only\">(current)</span></span></li>";
	        			} else {
	        				beginstr += "<li><a onclick=\"loading('work2', " + (r-1) + ", " + id +")\" style=\"color:grey; cursor:pointer;\">" + r + "</a></li>";
	        			}
	        		}
	        		beginstr += endstr;
	        	}else {
	        		for(var r = 1; r < 3; r++) {
	        			from = start - r * 8;
	        			beginstr += "<li><a onclick=\"loading('work2', " + (nowpage-r-1) + ", " + id + ")\" style=\"color:grey;cursor:pointer;\">" + (nowpage-r) + "</a></li>";
	        		}
	        		beginstr += "<li class=\"active\"><span>" + nowpage + " <span class=\"sr-only\">(current)</span></span></li>";
	        		for(var r = 0; r < 2; r++) {
	        			from = end + r * 8;
	        			if(from < num) {
	        				beginstr += "<li><a onclick=\"loading('work2', " + (nowpage + r) + ", " + id + ")\" style=\"color:grey;cursor:pointer;\">" + (nowpage + r + 1) + "</a></li>";
	        			}        			
	        		}
	        		beginstr += endstr;
	        	}
	        	document.getElementById('page1').innerHTML = beginstr;
			} 
		}, 
		error:function(json) {
			
		}
	});
}

function saveTag(type, num, id) {
	var str = 'work';
	if(type == 'talk') {
		str = 'talk';
	}
	var str1 = type + num;
	var area = document.getElementById(str1);
	var str2 = 'tag' + num;
	var value = document.getElementsByName(str2)[0].value;
	$.ajax({
		type: "POST",
		url: "/software/ChangeServlet",
		data: {"type": "changeTag", "type2": type, "value": value, "id": id},
		dataType: "json",
		success:function (data) {
			var item = eval(data);
			alert("更改成功");
		},
		error:function (json) {
			
		}
	});
	
	area.style.paddingTop = '8px';
	area.style.paddingBottom = '8px';
	area.innerHTML = value;
	str1 = 'op_' + str + num;
	area = document.getElementById(str1);
	area.innerHTML = '<span class="glyphicon glyphicon-pencil change_tag" aria-hidden="true"  onclick="changeTag(\'' + type + '\', ' + num + ', ' + id + ')"></span>';
}

function addTag(type, id) {
	var tag = prompt("标签名：");
	if (tag!=null && tag!="")
	{
		$.ajax({
			type: "POST",
			url: "/software/ChangeServlet",
			data: {"type": "addTag", "type2": type, "value": tag, "id": id},
			dataType: "json",
			success:function (data) {
				alert('添加成功');
				loading(type, 0, id);
			},
			error:function (json) {
				
			}
		});
	} 
}

function changeTag(type, num, id){ //type: 0 work  1 talk
	var str = 'work';
	if(type == 'talk') {
		str = 'talk';
	}
	var str1 = type + num;
	var area = document.getElementById(str1);
	var value = area.innerHTML;
	area.style.paddingTop = '5px';
	area.style.paddingBottom = '5px';
	area.innerHTML='<input type="text" name="tag' + num + '" value="' + value + '" class="tag-input">';
	str1 = 'op_' + str + num;
	area = document.getElementById(str1);
	area.innerHTML = '<span class="glyphicon glyphicon-ok change_tag" aria-hidden="true" id="op_' + str + num +'" onclick="saveTag(\'' + type + '\', ' + num + ', ' + id + ')"></span>';
}