var toId = 0, username = -1, toUser = "", level = 1, now = 0, talk_id = 0, onwer="";
var close1 = 0, close2 = 0;
function loadingDis() {
	var x, id;
	id = getParams("id");
	now = id;
	talk_id = id;
	x = parseInt(getParams("page"));
	$.ajax({
		type: "GET",
		url: "/software/SingelServlet",
        data: {'type': 'talk', 'id': id, "page": x},  
        dataType:"json",  
		success:function(data) {
			var item = eval(data);
			onwer = item.discuss[0].user;
        	//用户名
			var nav = "<ul>" +
					"<li><a href=\"./index.html\">首页</a></li>" +
					"<li><a href=\"./sort.html\">排行</a></li>" +
					"<li><a href=\"./classify.html\">分类</a></li>" +
					"<li><a href=\"talk.html?page=0&type=0&base=0\">话题</a></li>";
 					  
        	if(item.name[0].username == "")
        	{
        		nav += "<li><a href=\"./login.html\">登录</a></li>";
        	} else {
        		username = item.name[0].username;
        		nav += "<li><a href=\"./myself.html\">" + username + "</a></li>" +
        			   "<li><a href=\"/software/ExitServlet\">登出</a></li>";
        	}
        	nav += "</ul>";
        	var area = document.getElementById('nav');
        	area.innerHTML = nav;
        	//title
        	var str = "<li><span>" + item.discuss[0].title + "</span><button onclick=\"replyPerson(0, " + id + ", 0)\">回复</button></li>";
        	str += "<li><div class=\"user_own\"><img src=\"../UserPic/" + item.discuss[0].img + "\"><span>楼主</span><p>" + item.discuss[0].user + "</p></div>" +
        			"<div class=\"talk_content\"><div class=\"user_talk\">" +
 					"<p>" + item.discuss[0].content + "</p></div>" +
 					"<div class=\"other_user_look\"><p><span>" + item.discuss[0].time + "</span></p></div></div></li>";
 					
 			for(var i = 1; i < item.discuss.length; i++) {
 				str += "<li><div class=\"user_own\"><img src=\"../UserPic/" + item.discuss[i].img + "\"><p>" + item.discuss[i].user + "</p></div>" + 
 						"<div class=\"talk_content\"><div class=\"user_talk\"><p>" + item.discuss[i].content + "</p></div>" +
 						"<div class=\"other_user_look\"><p><button onclick=\"moreReply.onetotwo(" + i + ", " + item.discuss[i].id + ");\"><img src=\"../img/discuss/reply.png\">" + item.discuss[i].reply + "</button><span>" + item.discuss[i].time + "</span><button onclick=\"replyPerson('" + item.discuss[i].user + "', " + item.discuss[i].id + ", 1)\">回复</button></p></div>";
 				
 				if(item.discuss[i].reply > 0) {
 					str += "<div class=\"other_people_reply\" id=\"already_replys" + i + "\"></div>";
 				}
 				str += "</div></li>";
 			}
 			document.getElementById('box').innerHTML = str;
 			
 			//页码加载
			x = x + 1;
			var sum = parseInt(item.discuss[0].reply);
			str = "<ul>";
			if(sum%5 > 0) {
				sum = parseInt(sum/5) + 1;
			} else {
				sum = parseInt(sum/5);
			}
			var cnt = 4;
			if(x == 1) {
				str += "<li class=\"noactive\"><a>...</a></li>" + 
				       "<li class=\"noactive\"><a>1</a></li>";
			} else {
				str += "<li><a href=\"discuss.html?id=" + talk_id + "&page=" + (x-2) + "\">...</a></li>";
				var y = 2;
				if(sum-x < 2) {
					y = 4 - sum + x;
				}
				for(var i = x-y; i < x; i++) {
					if(i <= 0) {
						continue;
					}
					str += "<li><a href=\"discuss.html?id=" + talk_id + "&page=" + (i-1) + "\">" + i + "</a></li>";
					cnt--;
				}
				str += "<li class=\"noactive\"><a>" + x + "</a></li>";
			}
			for(var i = x; cnt > 0; i++) {
				if(i+1 <= sum) {
					str += "<li><a href=\"discuss.html?id=" + talk_id + "&page=" + (i) + "\">" + (i+1) + "</a></li>";
					cnt--;
				} else {
					break;
				}
			}
			if(cnt == 0 && x+2 < sum) {
				str += "<li><a href=\"discuss.html?id=" + talk_id + "&page=" + (x) + "\">...</a></li>";
			} else {
				str += "<li class=\"noactive\"><a>...</a></li>";
			}
			str += "</ul>";
			document.getElementById('page').innerHTML = str;
		},
		error:function(json) {
			
		}
	});
}

function getParams(key) {
    var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

function replyPerson(name, id, x) {
	toId = id;
	level = x;
	if(x == 0) {
		toUser = "";
	} else {
		var area = document.getElementById("talk");
		area.focus(); 
		area.value = "To " + name + ": ";
		toUser = name;
	}	
	window.location.hash = "#talk";
}

function uploadUserTalk() {
	var content = document.getElementById('talk').value;
	if(username == -1) {
		alert("还未登录，请登录后评论");
	} else {
		var n = "", p = 0, conT = "";
		if(content[0] == 'T' && content[1] == 'o' && content[2] == ' ') {
			for(var i = 3; i < content.length; i++) {
				if(content[i] == ':') {
					if(i == 3) {
						i = content.length;
					} else {
						p = i;
						i++;
					}
				} else {
					if(p == 0) {
						n += content[i];
					} else {
						conT += content[i];
					}
				}
				
			}
		}
		
		if(n == "" || p == 0) {
			level = 0;
			toId = now;
			toUser = "";
		} else {
			if(toId != 0) {
				content = conT;
			}
		}
		
		$.ajax({
			type: "POST",
			url: "/software/ChangeServlet",
			data: {"type": "uploadDiscuss", "to": toId, "toUser": toUser, "content": content, "level": level},
			dataType: "json",
			success:function(data) {
				item = eval(data);
				
				if(item.status == "false") {
					alert("还未登录，请登录后评论");
				} else {
					alert("回复成功");
					window.location.href = "discuss.html?id=" + talk_id + "&page=0";
				}
				
			},
			error:function(json) {
				
			}
		});
	}
}

var moreReply = function() { 
	return {
		onetotwo:function(x, id) {
			if(close1 == 0) {
				close1 = 1;
				var area = 'already_replys' + x;			
	   			document.getElementById(area).style.display = "";
				$.ajax({
					type: "GET",
					url: "/software/SingelServlet",
					data: {"type": "level2", "id": id},
					dataType: "json",
					success:function(data) {
						item = eval(data);
						var str = "<ul>";
						for(var i = 0; i < item.Reply.length; i++) {
							str += '<li>'+
									'<div class="small_user_head"><img src="../UserPic/' + item.Reply[i].img + '" alt=""><p>' + item.Reply[i].user + '</p></div>'+
									'<div class="small_talk_content">'+
									'<div class="small_user_talk">'+
			 						'<p>' + item.Reply[i].content + '</p>'+
			 						'</div>'+
			 						'<div class="small_user_look">'+
			 						'<p><button onclick="replyPerson(\'' + item.Reply[i].user + '\', ' + item.Reply[i].id + ', 2)">回复</button><span>' + item.Reply[i].time + '</span><button onclick="moreReply.twotothree(' + i + ', ' + item.Reply[i].id + ');"><img src="../img/discuss/reply.png">' + item.Reply[i].reply + '</button>'+
			 						'</div>';
							if(item.Reply[i].reply > 0) {
								str += '<div class="small_other_people_reply" id="more_already_replys' + i + '"></div>'+
			 							'</div>';
							}
			 						
			 				str += '</li>';
						}
						str += '</ul>';
							
			   			document.getElementById(area).innerHTML = str;
					},
					error:function(json) {
						
					}
				});
			} else {
				close1 = 0;
				var area = 'already_replys' + x;			
	   			document.getElementById(area).style.display = "none";
			}
			
		},
		twotothree:function(x, id) {
			if(close2 == 0) {
				close2 = 1;
				var area = 'more_already_replys' + x;			
			   	document.getElementById(area).style.display = "";
				$.ajax({
					type: "GET",
					url: "/software/SingelServlet",
					data: {"type": "level3", "id": id},
					dataType: "json",
					success:function(data) {
						item = eval(data);
						var str = "<ul>";
						for(var i = 0; i < item.Reply.length; i++) {
							str += '<li>'+
								   '<div class="small_user_head"><img src="../UserPic/' + item.Reply[i].img + '"><p>' + item.Reply[i].user + '</p></div>'+
								   '<div class="s_small_user_talk">'+
								   '<div style="width: auto;float: left;color: #64b185;font-size: 15px;font-weight: bold;white-space: nowrap;">To ' + item.Reply[i].to + '：</div><p style="text-indent: 0em;">' + item.Reply[i].content + '</p>'+
								   '</div>'+
								   '<div class="small_user_look">'+
								   '<p><button onclick="replyPerson(\'' + item.Reply[i].user + '\', ' + id + ', 3)">回复</button><span>' + item.Reply[i].time + '</span></p>'+
								   '</div>';
			 						
			 				str += '</li>';
						}
						str += '</ul>';
										  
						document.getElementById(area).innerHTML = str;				 
			 			
					},
					error:function(json) {
						
					}
				});
			} else {
				close2 = 0;
				var area = 'more_already_replys' + x;			
			   	document.getElementById(area).style.display = "none";
			}
								
		}
	};
}();