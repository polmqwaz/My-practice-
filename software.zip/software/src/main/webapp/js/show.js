 var flag = 0, num, id = 0, tem = 0, user_name, work_name;
var toId = 0, username = -1, toUser = "";
var work_pic = document.getElementById('work_pic');
var work_talk = document.getElementById('work_talk');
var down = document.getElementById('downbut');
var onUser = false;
document.getElementById('img2').style.visibility = "hidden";

function onloadshow() {
	work_name = getParams("name");
	user_name = getParams("user");
	$.ajax({  
        type: "POST",  
        url: "/software/SingelServlet",
        data: {'type': 'work', 'work_name': work_name, "user_name": user_name},  
        dataType:"json",  
        success: function(data){ 
        	var item = eval(data);
        	id = item.work.id;
        	//用户名
        	var nav = "<ul>" +
					"<li><a href=\"./index.html\">首页</a></li>" +
					"<li><a href=\"./sort.html\">排行</a></li>" +
					"<li><a href=\"./classify.html\">分类</a></li>" +
					"<li><a href=\"talk.html?page=0&type=0&base=0\">话题</a></li>";
 					  
        	if(item.name[0].username == "")
        	{
        		nav += "<li><a href=\"./login.html\">登录</a></li>";
        		onUser = false;
        	} else {
        		nav += "<li><a href=\"./myself.html\">" + item.name[0].username + "</a></li>" +
        			   "<li><a href=\"/software/ExitServlet\">登出</a></li>";
        		username = item.name[0].username;
        		onUser = true;
        	}
        	nav += "</ul>";
        	var area = document.getElementById('nav');
        	area.innerHTML = nav;
        	
        	var update = '无更新';
        	if(item.work.updatetime != 'null') {
        		update = item.work.updatetime;
        	}
        	
        	var tem = "../img/show/goodBefore.png";
        	if(item.work.userlove == "true") {
        		tem = "../img/show/goodAfter.png";
        		flag = 1;
        	}
        	
        	//作品基本信息
        	var  info = "<div class=\"work_pic\">" +
 						"<img src=\"../WorkPic/" + item.work.workimg + "\" alt=\"hahahah\"></div>" +
 						"<div class=\"work_basic\">" +
 						"<p style=\"font-weight: bolder; font-size: 30px; line-height: 30px; height:35px; margin-top: 35px;\">" + item.work.name + "</p>" +
 						"<p style=\"font-weight: bolder; font-size: 21px; line-height: 21px; height:24px;\">" + item.work.user + "</p>" +
 						"<p>" + "系统：" + item.work.os + "</p>" +
 						"<p>评分：" + item.work.grade +"</p>" +
 						"<p>上传日期：" + item.work.time +"</p>" +
 						"<p>更新日期：" + update +"</p>" +
 						"<div class=\"score\"></div>" +
 						"<div class=\"s_basic\"><div class=\"part\"><img id=\"good\" src=\"" + tem + "\">" +
 						"<span id=\"goodnum\">" + item.work.goodnum + "</span></div>" +
 						"<div class=\"part\"><a id=\"downbut\" target=\"_blank\" href=\"/software/DownLoadServlet?filename=" + item.work.addr + "&type=2\"><img id=\"down\" src=\"../img/show/down.png\"></a>" +
 						"<span id=\"downnum\">" + item.work.downnum + "</span></div></div>" +
 						"</div>";
        	area = document.getElementById('part1');
        	var numG = parseInt(item.work.goodnum);
        	var numD = parseInt(item.work.downnum)
        	area.innerHTML = info;
        	
        	$(function() {
      			$("#good").on("click", function() {
      				if(flag == 1) {
      					alert('已收藏过了');
      					return false;
      				}
      				
      				if(onUser == false) {
      					alert('请先登录！');
      					return false;
      				}
      				
            		document.getElementById('good').src = "../img/show/goodAfter.png";
            		numG = numG + 1;
       	 			
       	 			$.ajax({  
       	 				type: "GET",  
       	 				url: "/software/ChangeServlet",
       	 				data: { 'type': 'good', 'id': id, 'num': numG},  
       	 				dataType:"json",  
       	 				success: function(data){
       	 					$("#goodnum").text(numG);
       	 				},  
       	 				error: function(json){
       	 					alert("ajax返回出错");
       	 				}  
       	 			});  
      			});
      			
      			
      			$("#downbut").on("click", function() {
      				if(onUser == false) {
      					alert('请先登录！');
      					return false;
      				}
      				
      				numD = numD + 1;
       	 			$.ajax({
       	 				type: "GET",  
       	 				url: "/software/ChangeServlet",
						data: { 'type': 'down', 'id': id, 'num': numD},  
						dataType:"json",  
						success: function(data){
							$("#downnum").text(numD);
							document.getElementById('down').src = "../img/show/load.png";
						},  
						error: function(json){
							alert("ajax返回出错");
						}  
       	 			});
      			});
    		});
        	
        	//描述加载
        	var color = new Array("#6BF9AC","#98F8FB","#E0F978","#FC8F8F","#F0BDBD","#FEBD91","#EEBFF4");
        	var str = "";
        	for(var i = 0; i < item.tagNum; i++) {
        		str += "<a href=\"search.html?value=" + item.tag[i].value + "&base=关键字&num=0\";><div style=\"background-color: " + color[(i+1)%7] + "\">" + item.tag[i].value + "</div></a>"
        	}
        	str += "<p>" + item.work.describe + "</p>";
        	if(item.work.updatetime != 'null') {
        		str += "<br/><p>更新部分：" + item.work.updatecontent + "</p>";
        	}
        	document.getElementById('part2').innerHTML = str;
        	
        	getPic(0);
        	
        	//相似作品
        	str = '<ul>';
        	for(var i = 0; i < 5; i++) {
        		str += '<li><a href="show.html?name=' + item.alike[i].name + '&user=' + item.alike[i].user + '"><img src="../WorkPic/' + item.alike[i].workimg + '"><div class="details">' +
	 					'<p>' + item.alike[i].name + '</p><p>作者：' + item.alike[i].user + '</p>' +
	 					'<p>分类：' + item.alike[i].lable + '</p><p>下载量：' + item.alike[i].downnum + '</p></div></a></li>';
        	}
        	str += '</ul>';
        	document.getElementById('like').innerHTML = str;
        	
        	//排行榜作品
        	str = '<ul>';
        	for(var i = 0; i < 5; i++) {
        		str += '<li><a href="show.html?name=' + item.sort[i].name + '&user=' + item.sort[i].user + '"><img src="../WorkPic/' + item.sort[i].workimg + '"><div class="details">' +
	 					'<p>' + item.sort[i].name + '</p><p>作者：' + item.sort[i].user + '</p>' +
	 					'<p>分类：' + item.sort[i].lable + '</p><p>下载量：' + item.sort[i].downnum + '</p></div></a></li>';
        	}
        	str += '</ul>';
        	document.getElementById('best').innerHTML = str;
        },  
        error: function(json){
        }  
    });
}

function getParams(key) {
    var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
    var l = decodeURI(window.location.search);  
    var r = l.substr(1).match(reg);   
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

function getPic(x) {
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {'page': 'show', 'id': id, "num": x },
		dataType: "json",
		success: function(data) {
			var item = eval(data);
			
			var str = "<div class=\"user_show\" id=\"user_show\"><ul>";
			var num = item.num;
			
			for(var i = 0; i < num; i++) {
				var picW = 20;
				if(item.work[i].size == 2) {
					picW = 31;
				}
				if(item.work[i].size == 3) {
					picW = 43;
				}
				var title = "";
				if(item.work[i].title != 'null') {
					title = item.work[i].title;
				}
				if(i%2 == 0) {
					str += "<li><div style=\"width: " + (80-picW) + "%;\" class=\"picp\"><p style=\"text-indent: 0em; text-align: right;\"><b>" + title + "</b></p><p style=\" text-align: right; \">" + item.work[i].des + "</p></div><img style=\"width: " + picW + "%;\" src=\"../WorkPic/" + item.work[i].pic + "\" ></li>";
				} else {
					str += "<li><img style=\"width: " + picW + "%;\" src=\"../WorkPic/" + item.work[i].pic + "\" ><div style=\"width: " + (80 - picW) + "%;\" class=\"picp\"><p style=\"text-indent: 0em;\"><b>" + title + "</b></p><p>" + item.work[i].des + "</p></div></li>";
				}
			}
			str += "</ul><div class=\"showBtn\">";
			
			if(x > 0) {
				str += "<button onclick=\"getPic(" + (x - 1) + ")\">上一页</button>";
			}
			if((x*3 + 3) < item.sum){
				str += "<button onclick=\"getPic(" + (x + 1) + ")\">下一页</button>";
			}
			str += "</div></div>";
			document.getElementById('add_part').innerHTML = str;
			
			if(tem == 1){
				window.location.hash = "#part3";
			} else {
				tem = 1;
			}
			
		},
		error: function(json) {
			
		}
	});
}

function replyUser(str, x) {
	if(onUser == false) {
			alert('请先登录！');
			return false;
	}
	
	var area = document.getElementById("talk");
	area.focus(); 
	area.value = "To " + str + ": ";
	toId = x;
	toUser = str;
}

function showReply(x) {
	var str = 'subUl' + x;
	var area = document.getElementById(str);
	if(area.style.display == "none"){
		area.style.display = "";
	} else {
		area.style.display = "none";
	}
}

function uploadUserTalk() {
	var content = document.getElementById('talk').value;
	if(username == -1) {
		alert("还未登录，请登录后评论");
	} else {
		var n = "", p = 0, conT = "";
		if(content[0] == 'T' && content[1] == 'o' && content[2] == ' ') {
			for(var i = 3; i < content.length; i++) {
				if(content[i] == ':') {
					if(i == 3) {
						i = content.length;
					} else {
						p = i;
						i++;
					}
				} else {
					if(p == 0) {
						n += content[i];
					} else {
						conT += content[i];
					}
				}
				
			}
		}
		
		if(n == "" || p == 0) {
			toId = 0;
			toUser = "";
		} else {
			if(toId != 0) {
				content = conT;
			}
		}
		
		$.ajax({
			type: "POST",
			url: "/software/ChangeServlet",
			data: {"type": "uploadComment", "to": toId, "work_id": id, "toUser": toUser, "content": content},
			dataType: "json",
			success:function(data) {
				item = eval(data);
				
				if(item.status == "false") {
					alert("还未登录，请登录后评论");
				} else {
					getTalk(0);
				}
				
			},
			error:function(json) {
				
			}
		});
	}
}

function getTalk(x) {
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {"page": "comment", "id": id, "num": x},
		dataType: "json",
		success:function(data) {
			item = eval(data);
			
			var str = "<div class=\"user_talk\" id=\"user_talk\">";
			str += "<div class=\"write\"><textarea name=\"talk\" id=\"talk\"></textarea><button onclick=\"uploadUserTalk()\">发表</button></div>";
			
			str += "<div class=\"read\"><ul class=\"Ul\">";
			for(var i = 0; i < item.sum; i++) {
				str += "<li class=\"Li\"><div class=\"chat_content\"><span>" + item.say[i].user + "：</span>" + item.say[i].content + "</div>" +
						"<div class=\"chat_other\"><span>" + item.say[i].time + "</span>&nbsp;&nbsp;<button onclick=\"replyUser('" + item.say[i].user + "', " + item.say[i].id + ")\">回复</button>&nbsp;&nbsp;<img src=\"../img/show/reply.png\" onclick=\"showReply(" + i + ")\"><span style=\"color: #5DA9C5;\">" + item.say[i].num + "</span></div>";
				
				if(item.say[i].num > 0) {
					str += "<ul class=\"subUl\" style=\"display: none\" id=\"subUl" + i + "\">";
				}
				for(var j = 0; j < item.say[i].num; j++) {
					str += "<li><div class=\"chat_content\"><span>" + item.say[i].reply[j].from + " To " + item.say[i].reply[j].to + "：</span>" + item.say[i].reply[j].con + "</div>" +
							"<div class=\"chat_other\"><span>" + item.say[i].reply[j].ti + "</span>&nbsp;&nbsp;<button onclick=\"replyUser('" + item.say[i].reply[j].from + "', " + item.say[i].id + ")\">回复</button></div></li>";
				}
				if(item.say[i].num > 0) {
					str += "</ul>";
				}
				
				str += "</li>";
			}
			
			str += "</ul><div class=\"showBtn\" style=\"margin-top: 40px;\">";
			
			if(x > 0) {
				str += "<button onclick=\"getTalk(" + (x - 1) + ")\">上一页</button>";
			}
			if((x*9 + 9) < item.all){
				str += "<button onclick=\"getTalk(" + (x + 1) + ")\">下一页</button>";
			}
			str += "</div></div>";
			document.getElementById('add_part').innerHTML = str;
			
			if(tem == 1){
				window.location.hash = "#part3";
			} else {
				tem = 1;
			}
		},
		error:function(json) {
		}
	});
}

work_pic.onclick = function() {
	document.getElementById('img2').style.visibility = "hidden";
	document.getElementById('img1').style.visibility = "";
	getPic(0);
	tem = 1;
};
work_talk.onclick = function() {
	document.getElementById('img1').style.visibility = "hidden";
	document.getElementById('img2').style.visibility = "";
	getTalk(0);
};
