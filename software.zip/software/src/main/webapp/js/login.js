var loginer = document.getElementById('login_button');
var regisiter = document.getElementById('regisiter_button');
var prepart = document.getElementById('login_part');
var login = document.getElementById('login');
var upBut = document.getElementById('up_but');
var uname = document.getElementById("uname");
var pass = document.getElementById("userpassword");

function loading() {
	var ans = getParams("ans");
	if(ans != null) {
		alert("用户注册成功，请登录！");
	}
}

function getParams(key) {
	var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

loginer.onclick = function() {
	
	if(uname.value == "" || pass.value == "")
    {
        alert('用户名和密码不能为空')
    }else{
    	$.ajax({  
	        type: "POST",  
	        url: "/software/UserServlet",
	        data: {'type': 'login', 'name': uname.value, 'pass': pass.value, 'flag': 'user'},  
	        dataType:"json",  
	        success: function(data){ 
	        	var msg = eval(data);
	        	if(msg[0].ans == "true") {
	        		window.location.href = 'index.html';
	        		
	        	} else {
	        		alert("用户名或密码错误");
	        	}
	        },  
	        error: function(json){
	        }  
	    });  
    }
};
regisiter.onclick = function() {
	login.style.display = "none";
	prepart.style.height = "0%";
	prepart.style.transition = "height 1s";
};
function runup() {
	prepart.style.height = "50%";
	prepart.style.transition = "height 1s";
	login.style.display = "";
}
function checkname() {
	 var name = document.getElementById('username');
	 $.ajax({
		 type: 'GET',
		 url: '/software/UserServlet',
		 data: {'type': 'check', 'name': name.value},
		 dataType: 'json',
		 success:function(data) {
			 var item = eval(data);
			 if(item.ans == 'false') {
				 name.value = '';
			     name.setAttribute("placeholder","用户名已存在，请更改！");
			 }
		 },
		 error:function(json) {
			 
		 }
	 });
}
function checkPassL() {
    var pass = document.getElementsByName('userpass')[0];
    if(pass.value.length < 6)
    {
        pass.value = '';
        pass.setAttribute("placeholder","密码长度需达到6位以上");
    }else{
        var rulenum = /[0-9]/; 
        var ruleen = /[a-z]/i;
        if(!rulenum.test(pass.value) || !ruleen.test(pass.value))
        {
            pass.value = '';
            pass.setAttribute("placeholder","密码需包含数字和英文");
        }
    }
    
}
function checkPass() {
    var surepass = document.getElementsByName('besurepass')[0];
    if(document.getElementsByName('userpass')[0].value != surepass.value)
    {
        surepass.value = '';
        surepass.setAttribute("placeholder","确认密码与密码不相等，请重新输入");
    }
}

function checkAd() {
	$.ajax({
		type: "GET",  
        url: "/software/UserServlet",
        data: {'type': 'nav'},  
        dataType:"json", 
        success: function(data) {
        	var item = eval(data);
        	if(item.status == '0') {
        		window.location.href = "ad_login.html";
        	}
        	if(item.status == '2') {
        		document.getElementById('tad').style.display = "";
        		document.getElementById('uad').style.display = "";
        	}
        },
        erroe: function(json) {
        	
        }
    });
}