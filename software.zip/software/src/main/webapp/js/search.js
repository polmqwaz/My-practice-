var value;
var base;
var num;
var on = "time";
function loading() {
	value = getParams("value");
	base = getParams("base");
	num = getParams("num");
	document.getElementById('search').value = value;
	document.getElementById('searchContent').innerHTML = base;
	loadAns(value, base, num, on);
}

function getParams(key) {
    var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
    var l = decodeURI(window.location.search);  
    var r = l.substr(1).match(reg);   
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}

function smallSelect() {
	var radio = document.getElementsByName("select");  
    for (i=0; i<radio.length; i++) {  
        if (radio[i].checked) {  
            on = radio[i].value;
            loadAns(value, base, num, on);
        }  
    } 
}

function loadAns(value, base, num, on) {
	var xx = 5;
	$.ajax({
		type: "POST",
		url: "/software/LoadServlet",
		data: {"page": "search", "value": value, "base": base, "num": num, "on": on},
		dataType: "json",
		success:function(data) {
			var item = eval(data);
			//用户名
			var nav = "<ul>" +
					"<li><a href=\"./index.html\">首页</a></li>" +
					"<li><a href=\"./sort.html\">排行</a></li>" +
					"<li><a href=\"./classify.html\">分类</a></li>" +
					"<li><a href=\"talk.html?page=0&type=0&base=0\">话题</a></li>";
 					  
        	if(item.name == "")
        	{
        		nav += "<li><a href=\"./login.html\">登录</a></li>";
        	} else {
        		nav += "<li><a href=\"./myself.html\">" + item.name + "</a></li>" +
        			   "<li><a href=\"/software/ExitServlet\">登出</a></li>";
        	}
        	nav += "</ul>";
        	var area = document.getElementById('nav');
        	area.innerHTML = nav;
			
        	var user = "";
        	if(base == '用户') {
        		if(item.status == 'true') {
        			user += '<div class="person"><div class="personpic">' +
        					'<img src="../UserPic/' + item.img + '"></div><div class="persondetail">' +
        					'<p><b>用户名：</b>' + item.username + '</p>' +
        					'<p><b>专业：</b>' + item.usermajor + '</p>' +
        					'<p><b>身份：</b>' + item.position + '</p>' +
        					'<p><b>邮箱：</b>' + item.mail + '</p>' +
        					'<p><b>个性签名：</b>' + item.word + '</p></div></div>';
        			xx = 4;
        		}
        	}
			var str = "<ul>";
			for(var i = 1; i < item.work.length; i++) {
				str += '<li><a href=\"show.html?name=' + item.work[i].name + '&user=' + item.work[i].user + '\"><div class="workpic"><img src="../WorkPic/' + item.work[i].img + '"></div>' +
						'<div class="workdes"><div class="des-li"><p>' + item.work[i].name + '</p></div>' +
						'<div class="des-li"><p>' + item.work[i].user + '</p></div>' +
 						'<div class="des-li"><p>' + item.work[i].word + '</p></div></div>' +
 						'<div class="workother"><div class="other"><span>收藏次数:' + item.work[i].good + '</span>&nbsp;<span>下载次数:' + item.work[i].down + '</span></div>' +
 						'<div class="other">' + item.work[i].time + '</div></div></a></li>';
			}
			str += '</ul>';
			if(item.work[0].id == 0) {
				str = '<img src="../img/empty.png"/ style="width: 400px; height: 400px;">';
			}
			document.getElementById('ans').innerHTML = user + str;
			
			//页码加载
			num = parseInt(num) + 1;
			var sum = parseInt(item.work[0].id);
			str = "<ul>";
			if(sum%xx > 0) {
				sum = parseInt(sum/xx) + 1;
			} else {
				sum = parseInt(sum/xx);
			}
			var cnt = 4;
			if(num == 1) {
				str += "<li class=\"noactive\"><a>...</a></li>" + 
				       "<li class=\"noactive\"><a>1</a></li>";
			} else {
				str += "<li><a href=\"search.html?value=" + value + "&base=" + base + "&num=" + (num-2) + "\">...</a></li>";
				var y = 2;
				if(sum-num < 2) {
					y = 4 - sum + num;
				}
				for(var i = num-y; i < num; i++) {
					if(i <= 0) {
						continue;
					}
					str += "<li><a href=\"search.html?value=" + value + "&base=" + base + "&num=" + (i-1) + "\">" + i + "</a></li>";
					cnt--;
				}
				str += "<li class=\"noactive\"><a>" + num + "</a></li>";
			}
			for(var i = num; cnt > 0; i++) {
				if(i+1 <= sum) {
					str += "<li><a href=\"search.html?value=" + value + "&base=" + base + "&num=" + (i) + "\">" + (i+1) + "</a></li>";
					cnt--;
				} else {
					break;
				}
			}
			if(cnt == 0 && num+2 < sum) {
				str += "<li><a href=\"search.html?value=" + value + "&base=" + base + "&num=" + (num) + "\">...</a></li>";
			} else {
				str += "<li class=\"noactive\"><a>...</a></li>";
			}
			str += "</ul>";
			document.getElementById('page').innerHTML = str;
		},
		error:function(json) {
			
		}
	});
}