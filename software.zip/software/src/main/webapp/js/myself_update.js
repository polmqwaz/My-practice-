var pass;
function loadingMe() {
	ans = getParams("ans");
	if(ans == 1) {
		alert("信息更改成功");
		window.location.href = "myself_update.html";
		return false;
	}
	$.ajax({
		 type: 'GET',
		 url: '/software/UserServlet',
		 data: {"type": "userUpdate"},
		 dataType: 'json',
		 success:function(data) {
			 var item = eval(data);
				if(item.ans == "false") {
					alert("用户已下线，请重新登陆后操作");
					window.location.href = "login.html";
				} else {
					pass = item.pass;
					document.getElementsByName('name')[0].value = item.name;
					document.getElementsByName('major')[0].value = item.major;
					document.getElementsByName('mail')[0].value = item.mail;
					document.getElementsByName('word')[0].value = item.word;
				}
		 },
		 error:function(json) {
			 
		 }
	 });
}
function getParams(key) {
    var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
    var l = decodeURI(window.location.search);  
    var r = l.substr(1).match(reg);   
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}
function showUp() {
	var area = document.getElementById('showOut');
	area.style.display = "";
}
function changeClose() {
	var area = document.getElementById('close');
	area.src = "../img/myself/close2.png";
}
function changeBackClose() {
	var area = document.getElementById('close');
	area.src = "../img/myself/close.png";
}
function checkOldPass() {
	var old = document.getElementsByName('prePass')[0];
	if(pass != old.value) {
		old.value = '';
        old.setAttribute("placeholder","密码错误");
	} 
}
function checkNewPass() {
	var pass = document.getElementsByName('nowPass')[0];
    if(pass.value.length < 6)
    {
        pass.value = '';
        pass.setAttribute("placeholder","密码长度需达到6位以上");
    }else{
        var rulenum = /[0-9]/; 
        var ruleen = /[a-z]/i;
        if(!rulenum.test(pass.value) || !ruleen.test(pass.value))
        {
            pass.value = '';
            pass.setAttribute("placeholder","密码需包含数字和英文");
        }
    }
}
function checkRepeatPass() {
	var surepass = document.getElementsByName('rePass')[0];
    if(document.getElementsByName('nowPass')[0].value != surepass.value)
    {
        surepass.value = '';
        surepass.setAttribute("placeholder","确认密码与密码不相等");
    }
}
function showClose(x) {
	if(x == 1) {
		var old = document.getElementsByName('prePass')[0];
		var surepass = document.getElementsByName('rePass')[0];
		var pass = document.getElementsByName('nowPass')[0];
		if(old.value == "" || surepass.value == "" || pass.value == "") {
			alert("信息尚未完整");
			return false; 
		}
		
		$.ajax({
			type: "GET",
			url: "/software/UserServlet",
			data: {"type": "changePass", "pass": pass.value},
			dataType: "json",
			success:function(data) {
				var item = eval(data);
				if(item.ans == "true") {
					alert("修改密码成功");
				} else {
					alert("用户未登陆，请登陆后操作");
				}
			},
			error:function(json) {
				alert("更改失败，请刷新重试");
			}
		});
	}
	var area = document.getElementById('showOut');
	area.style.display = "none";
}

var update = function() {
	return {
		changePic:function() {
			document.getElementById('pic').style.visibility = "visible";
		},
		outPic:function() {
			document.getElementById('pic').style.visibility = "hidden";
		}
	};
}();