var userType = 0;
function loading(type, x) {   //type: 0 全部  1 新增
	userType = type;
	$.ajax({
		type: "GET",
		url: "/software/UserServlet",
		data: {"type": "show", "limit": type, "page": x},
		dataType: "json",
		success:function(data) {
			var item = eval(data);
			
			var str = '<tr><th class="col-md-2 span-center">昵称</th><th class="col-md-2 span-center">专业</th>' +
						'<th class="col-md-2 span-center">邮箱</th><th class="col-md-2 span-center">身份</th>' +
						'<th class="col-md-1 span-center">操作</th></tr>';
			for(var i = 0; i < item.user.length; i++) {
				var mail = '无';
				var tem = 0;
				if(item.user[i].mail != 'null' && item.user[i].mail != "") {
					mail = item.user[i].mail;
				}
				if(item.user[i].position == '管理员') {
					tem = 1;
				}
				if(item.user[i].position == '教师') {
					tem = 2;
				}
				str += '<tr><td class="col-md-2 span-center" >' + item.user[i].name + '</td>' +
                        '<td class="col-md-2 span-center" >' + item.user[i].major + '</td>' +
                       	'<td class="col-md-2 span-center" >' + mail + '</td>' +
                        '<td class="col-md-2 span-center" id="changePart' + i + '">' + item.user[i].position + '</td>' +
                        '<td class="col-md-2 do_something span-center" id="change' + i + '"><span class="glyphicon glyphicon-pencil" aria-hidden="true" onclick="changeUser(' + i + ', ' + item.user[i].id + ', ' + tem + ')"></span><span class="glyphicon glyphicon-remove" aria-hidden="true" onclick="deleUser(' + item.user[i].id + ', ' + type +', ' + x + ')"></span></td></tr>';
			}
	        document.getElementById('Ul').innerHTML = str;   
	        
//        	页码计算
        	var beginstr, endstr;
        	var num = item.sum;
        	var start = x;
        	
        	if(start == 0) {
        		beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
      	      		       "<li class=\"active\"><span>1 <span class=\"sr-only\">(current)</span></span></li>";  
        		if(num > 40) {
        			endstr = "<li><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        		} else {
        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>"
        		}
        	} else {
        		if(num > 40) {
        			if(start >= 24) {
        				beginstr = "<li><span><span aria-hidden=\"true\">&laquo;</span></span></li>";
        				if((start + 24) < num) {
        					endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        				} else {
        					endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        				}
        			} else {
        				beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
  	                               "<li><a onclick=\"loading(" + type + ", 0)\" style=\"color:grey;cursor:pointer;\">1</a></li>";
        				endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        			}
        		} else {
        			beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
                               "<li><a onclick=\"loading(" + type + ", 0)\" style=\"color:grey;\">1</a></li>";
        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        		}
        	}
        	var nowpage = (start + 8) / 8;
        	
        	if(nowpage <= 3) {
        		for(var r = 2; r <= 5; r++) {
        			from = (r-1) * 8;
        			if(from >= num) {
        				break;
        			}
        			if(r == nowpage) {
        				beginstr += "<li class=\"active\"><span>" + r + " <span class=\"sr-only\">(current)</span></span></li>";
        			} else {
        				beginstr += "<li><a onclick=\"loading(" + type + ", " + from + ")\" style=\"color:grey; cursor:pointer;\">" + r + "</a></li>";
        			}
        		}
        		beginstr += endstr;
        	}else {
        		for(var r = 1; r < 3; r++) {
        			from = start - r * 8;
        			beginstr += "<li><a onclick=\"loading(" + type + ", " + from + ")\" style=\"color:grey;cursor:pointer;\">" + (nowpage-r) + "</a></li>";
        		}
        		beginstr += "<li class=\"active\"><span>" + nowpage + " <span class=\"sr-only\">(current)</span></span></li>";
        		for(var r = 0; r < 2; r++) {
        			from = end + r * 8;
        			if(from < num) {
        				beginstr += "<li><a onclick=\"loading(" + type + ", " + from + ")\" style=\"color:grey;cursor:pointer;\">" + (nowpage + r + 1) + "</a></li>";
        			}        			
        		}
        		beginstr += endstr;
        	}
        	document.getElementById('page').innerHTML = beginstr;
		},
		error:function(json) {
			
		}
	});
}

function deleUser(id, type, x) {
	if (confirm("是否删除该用户")) {  
		$.ajax({
			type: "POST",
			url: "/software/UserServlet",
			data: {"type": "dele", "id": id},
			dataType: "json",
			success:function(data) {
				alert('删除成功');
				loading(type, x);
			},
			error:function(json) {
				alert('删除失败，请刷新重试');
			}
		});
	}  
	else {  
	}  
}

function changeUser(x, id, y) {  //x: 第几行  id：用户id  y：身份
	var str = 'changePart' + x;
	var area = document.getElementById(str);
	area.innerHTML = '<div class="radio" style="margin: 0px;"><label style="float:left; clear:both;"><input type="radio" name="type' + x + '" value="0" checked="checked">用户</label><label style="float:left; clear:both;"><input type="radio" name="type' + x + '" value="1">管理员</label><label style="float:left; clear:both;"><input type="radio" name="type' + x + '" value="2">教师</label></div>';
	str = 'change' + x;
	area = document.getElementById(str);
	area.innerHTML = '<span class="glyphicon glyphicon-remove" aria-hidden="true" onclick="changeResult(' + x + ', ' + id + ', 0, ' + y + ')"></span><span class="glyphicon glyphicon-ok" aria-hidden="true" onclick="changeResult(' + x + ', ' + id + ', 1, 0)"></span>';
}

function changeResult(num, id, x, y) {  //x: 0false 1true  y:  0用户 1管理员2教师     num:第几行  id：用户id
	var type = '用户';
	var str = 'changePart' + num;
	var area = document.getElementById(str);
	if(x == 0) {
		if(y == 1) type = '管理员';
		if(y == 2) type = '教师';
	} else {
		str = 'type' + num;
		var item = document.getElementsByName(str);
		for(var i = 0; i < item.length; i++) {
			if(item[i].checked) {
				y = item[i].value;
			}
		}
		if(y == 1) {
			type = '管理员';
		}
		if(y == 2) {
			type = '教师';
		}
		
		$.ajax({
			type: "POST",
			url: "/software/UserServlet",
			data: {"type": "position", "position": y, "id": id},
			dataType: "json",
			success:function(data) {
				alert('更改成功');
				loading(userType, 0);
			},
			error:function(json) {
				alert('更改失败，请刷新重试');
			}
		});
	}
	area.innerHTML = type;
	
	str = 'change' + num;
	area = document.getElementById(str);
	area.innerHTML = '<span class="glyphicon glyphicon-pencil" aria-hidden="true" onclick="changeUser(' + num + ', ' + id + ', ' + y + ')"></span><span class="glyphicon glyphicon-remove" aria-hidden="true" onclick="deleUser(1)"></span>';
}
