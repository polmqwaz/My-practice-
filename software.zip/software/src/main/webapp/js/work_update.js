var name;
function loading() {
	name = getParams("name");
	$.ajax({
		type: "POST",
		url: "/software/SingelServlet",
		data: {"type": "work_update", "name": name},
		dataType: "json",
		success:function (data) {
			item = eval(data);
			if(item.name == 'null') {
				alert('无该作品');
				window.location.href = "myself_mywork.html";
				
				return false;
			}
			document.getElementById('workname').value = item.name;
			document.getElementById('workname2').value = item.name;
			document.getElementById('workos').value = item.os; 
		},
		error:function (json) {
			
		}
	});
	
}

function getParams(key) {
    var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
    var l = decodeURI(window.location.search);  
    var r = l.substr(1).match(reg);   
    if (r != null) {
        return unescape(r[2]);
    }
    return null;
}


//图文说明
var size = []; //图片大小
var exp = []; //解说
var count = 0, tempic = -1, temexp = -1, now = -1; //count为总数量，tempic为此时所需图片的pic，temexp为tempic所对应的解说，now为tempic的count值。
//点击input框，跳出list
function jumpListBox() {
	document.getElementById('jumpex').style.display = "";
}
//点击list中的“+”，跳出添加框
function jumpExBox() {
	now = count;
	var usualhtml = '<span class="glyphicon glyphicon-ok ok" aria-hidden="true" onclick="sureExplain()"></span><span class="glyphicon glyphicon-remove move" aria-hidden="true" onclick="closeExplain()"></span>' +
				'<div class="pictitle"><div class="inputword">图解标题：</div><input type="text" id="title' + now + '" name="title' + now + '"></div>' +
				'<div class="selectpic"><div class="inputword">图片上传：</div><input type="file" id="file'+ now +'" name="pic'+ now +'" onchange="showPic('+ now +')" required="required"></div>' +
				'<div class="changesize"><p>长宽比</p><a onclick="changewidth(70)">1:2</a><a onclick="changewidth(140)">2:2</a><a onclick="changewidth(280)">4:2</a><input name="picsize'+ now +'" id="picsize' + now + '" style="display:none;"></div>' +
				'<div class="picshow" id="picshow'+ now +'"><img src="../img/myself/wait.png" id="show'+ now +'"></div>' +
				'<div class="writeexplain"><div class="inputword">图片解说：</div><textarea name="picdes'+ now +'" id="picexp'+ now +'" onfocus="if(value==\'此处应写图片的说明，限200字\'){value=\'\'}" onblur="if (value ==\'\'){value=\'此处应写图片的说明，限200字\'}">此处应写图片的说明，限200字</textarea></div>';
	var div = document.createElement('div');
	div.setAttribute("class", "myexplain");
	div.setAttribute("id", "myexplain");
	document.getElementById('hiddenpic').appendChild(div);
	document.getElementById('myexplain').innerHTML = usualhtml;
	document.getElementById('jumpex').style.display = "none";
	changewidth(140);
	size[now] = 1;
}
//添加框中图片大小选择（长方形 or 正方形）
function changewidth(x) {
	var str = 'picshow' + now;
	var pic = document.getElementById(str);
	pic.style.width = x + "px";
	size[now] = parseInt(x/70);
	str = 'picsize' + now;
	document.getElementById(str).value = size[now];
}
//选择图片后图片预览
function showPic(x) {
	var pic = new FileReader();
	var str = 'file' + x;
	var file = document.getElementById(str).files[0];
	pic.readAsDataURL(file);
	pic.onload = function(e) {
		tempic = this.result;
		str = 'show' + x;
		document.getElementById(str).src = this.result;
	};
}
//上传或确认修改
function sureExplain() {
	if(tempic == -1) {
		alert("需选择图片");
		return ;
	}
	var rightId = "myexplain" + now;
	if(now == count) {
		var rightnow = document.getElementById('myexplain');
		rightnow.id = rightId;
		count++;
	}
	var str = 'picexp' + now;
	exp[now] = document.getElementById(str).value;
	now = -1;
	str = "<ul>";
	for(var i = 0; i < count; i++) {
		if(size[i] == -1) {
			continue;
		}
		str += '<li id="pic'+ i +'"  onclick="lookPic('+ i +')"><span class="glyphicon glyphicon-remove delepic" aria-hidden="true" onclick="delePicList(' + i + ')"></span>pic'+ i +'</li>';
	}
	str += '<li><span class="glyphicon glyphicon-plus addlist" aria-hidden="true" onclick="jumpExBox()" ></span></li>';
	str += '</ul>';
	str += '<button onclick="sureList()">确定</button>';
	
	document.getElementById('piclist').innerHTML = str;
	document.getElementById('jumpex').style.display = "";
	document.getElementById(rightId).style.display = "none";
}
//取消输入框
function closeExplain() {
	if(now == count)
	{
		var fa = document.getElementById('hiddenpic');
		var ch = document.getElementById('myexplain');
		fa.removeChild(ch);
	} else {
		var str = 'myexplain' + now;
		document.getElementById(str).style.display = "none";
	}
	size[count] = -1;
	now = -1;
	document.getElementById('jumpex').style.display = "";
}
//删除已在list中的pic
var flag = -1;
function delePicList(x) {
	flag = 1;
	var str = 'myexplain' + x;
	size[x] = -1;
	var fa = document.getElementById('hiddenpic');
	var ch = document.getElementById(str);
	fa.removeChild(ch);
	str = 'pic' + x;
	document.getElementById(str).style.display = "none";
	event.cancelBubble = true;
}
//查看已在list中的pic
function lookPic(x) {
	if(flag == 1) {
		flag = -1;
		event.cancelBubble = true;
	}
	now = x;
	var str = 'picexp' + now;
	document.getElementById(str).value = exp[now];
	str = "myexplain" + x;
	document.getElementById(str).style.display = "";
	document.getElementById('jumpex').style.display = "none";
}
//确认list，所有有效pic将写入input
function sureList() {
	document.getElementById('jumpex').style.display = "none";
	var str = "";
	for(var i = 0; i < count; i++) {
		if(size[i] == -1) {
			continue;
		}
		var tem = 'picexp' + i;
		document.getElementById(tem).value = exp[i];
		str += "pic" + i + " ";
	}
	document.getElementById('finallist').value = str;
}

//确认上传资源的后缀
function checkWorkExt(filename)
{
	var flag = false; 
	var arr = ["rar", "zip", "arj", "z"];
	var index = filename.lastIndexOf(".");
	var ext = filename.substr(index+1);

	for(var i=0;i<arr.length;i++){
		if(ext == arr[i]){
			flag = true; 
			break;
		}
	}
	
	if(!flag){
		alert("资源类型不合法");
		var file = document.getElementById('uploadwork');
		if (file.outerHTML) {
            file.outerHTML = file.outerHTML;
        } else { 
            file.value = "";
        }
	}
}