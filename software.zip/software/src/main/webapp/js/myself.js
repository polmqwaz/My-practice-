var bubble = 0;
var gradeItems = new Array(0, 0, 0, 0, 0, 0);
var now = 0;
function loadingMyself() {
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {'page': 'myself'},  
        dataType:"json",
        success:function(data){
        	var item = eval(data);
			var msg = '<div class="user_img"><img src="../UserPic/' + item.user[0].img + '"></div>' +
					  '<div class="user_name"><div class="name_block">' + item.user[0].name + '</div></div>' +
					  '<div class="user_word"><span>' + item.user[0].word + '</span></div><div class="footer"></div>';
			document.getElementById('userPart').innerHTML = msg;
        },
        error: function(json) {
        	
        }
	});
}

var Mywork = function() {
	return {
		loading:function(x) {
			x = parseInt(x);
			$.ajax({
				type: "GET",
				url: "/software/SingelServlet",
				data: {"type": "mywork", "page": x},
				dataType: "json",
				success:function(data) {
					var item = eval(data);
					
					var str = '<li><ul class="smallUl"><li>作品名</li><li>下载量</li><li>收藏量</li><li>上传时间</li><li>更新时间</li><li>操作</li></ul></li>';
					for(var i = 0; i < item.work.length; i++) {
						var update = item.work[i].update;
						if(item.work[i].update == 'null') {
							update = '无更新';
						}
						
						str += '<li><a href="show.html?name=' + item.work[i].name + '&user=' + item.name + '" onclick="if(bubble==1){ bubble=0; return false;}"><ul class="smallUl">' +
            					'<li>' + item.work[i].name + '</li><li>' + item.work[i].down + '</li><li>' + item.work[i].good + '</li>' +
            			        '<li>' + item.work[i].time + '</li><li>' + update + '</li><li><span onclick="Mywork.jump(\'' + item.work[i].name + '\')">更新</span><span onclick="Mywork.dele(' + item.work[i].id + ', 3, ' + x + ')">删除</span></li></ul></a></li>';
					}
					document.getElementById('bigUl').innerHTML = str;
					
					//页码加载
					x = x + 1;
					var sum = item.sum;
					str = "<ul>";
					if(sum%6 > 0) {
						sum = parseInt(sum/6) + 1;
					} else {
						sum = parseInt(sum/6);
					}
					var cnt = 4;
					if(x == 1) {
						str += "<li class=\"noactive\"><a>...</a></li>" + 
						       "<li class=\"noactive\"><a>1</a></li>";
					} else {
						str += "<li><a href=\"myself_mywork.html?page=" + (x-2) + "\">...</a></li>";
						var y = 2;
						if(sum-x < 2) {
							y = 4 - sum + x;
						}
						for(var i = x-y; i < x; i++) {
							if(i <= 0) {
								continue;
							}
							str += "<li><a href=\"talk.html?page=" + (i-1) + "\">" + i + "</a></li>";
							cnt--;
						}
						str += "<li class=\"noactive\"><a>" + x + "</a></li>";
					}
					for(var i = x; cnt > 0; i++) {
						if(i+1 <= sum) {
							str += "<li><a href=\"talk.html?page=" + (i) + "\">" + (i+1) + "</a></li>";
							cnt--;
						} else {
							break;
						}
					}
					if(cnt == 0 && x+2 < sum) {
						str += "<li><a href=\"talk.html?page=" + (x) + "\">...</a></li>";
					} else {
						str += "<li class=\"noactive\"><a>...</a></li>";
					}
					str += "</ul>";
					document.getElementById('page').innerHTML = str;
				},
				error:function(json) {
					
				}
			});
		},
		loadingWait:function(x, temp) {
			var flag="wait";
			var msg = "新作品";
			if(temp == 0) {
				flag = "update";
				msg = "待更新";
			}
			if(temp == 2) {
				flag = "notpass";
			}
			$.ajax({
				type: "GET",
				url: "/software/SingelServlet",
				data: {"type": "myotherwork", "page": x, "flag":flag},
				dataType: "json",
				success:function(data) {
					var item = eval(data);
					var str = '<li><ul class="smallUl"><li>作品名</li><li style="width:15%;">分类</li><li style="width:15%;">类型</li><li>上传时间</li><li style="width:15%;">状态</li><li style="width:10%;">操作</li></ul></li>';
					for(var i = 0; i < item.work.length; i++) {
						var tem = "待审核";
						var color = "white";
						if(temp == 2) {
							tem = "未通过";
							color = "red";
							msg = item.work[i].status;
						}
						
						str += '<li><a href="javascript:void(0);"><ul class="smallUl">' +
            					'<li>' + item.work[i].name + '</li><li style="width:15%;">' + item.work[i].lable + '</li><li style="width:15%;">' + msg + '</li>' +
            			        '<li>' + item.work[i].time + '</li><li style="width:15%;color:' + color + ';">' + tem + '</li><li style="width:10%;"><span onclick="Mywork.dele(' + item.work[i].id + ', ' + temp + ', ' + x + ')">删除</span></li></ul></a></li>';
					}
					document.getElementById('bigUl').innerHTML = str;
					
					//页码加载
					x = x + 1;
					var sum = item.sum;
					str = '<ul>';
					if(sum%6 > 0) {
						sum = parseInt(sum/6) + 1;
					} else {
						sum = parseInt(sum/6);
					}
					var cnt = 4;
					if(x == 1) {	
						str += '<li class="noactive"><a>...</a></li>' + 
						       '<li class="noactive"><a>1</a></li>';
					} else {
						str += '<li><a href="javascript:void(0);" onclick="Mywork.loadingWait(' + (x-2) + ', ' + temp + ')">...</a></li>';
						var y = 2;
						if(sum-x < 2) {
							y = 4 - sum + x;
						}
						for(var i = x-y; i < x; i++) {
							if(i <= 0) {
								continue;
							}
							str += '<li><a href="javascript:void(0);" onclick="Mywork.loadingWait(' + (i-1) + ', ' + temp + ')">' + i + '</a></li>';
							cnt--;
						}
						str += '<li class="noactive"><a>' + x + '</a></li>';
					}
					for(var i = x; cnt > 0; i++) {
						if(i+1 <= sum) {
							str += '<li><a href="javascript:void(0);" onclick="Mywork.loadingWait(' + i + ', ' + temp + ')">' + (i+1) + '</a></li>';
							cnt--;
						} else {
							break;
						}
					}
					if(cnt == 0 && x+2 < sum) {
						str += '<li><a href="javascript:void(0);" onclick="Mywork.loadingWait(' + (x) + ', ' + temp + ')">...</a></li>';
					} else {
						str += '<li class="noactive"><a>...</a></li>';
					}
					str += '</ul>';
					document.getElementById('page').innerHTML = str;
				},
				error:function(json) {
					
				}
			});
		},
		jump:function(x) {
			bubble = 1;
			window.location.href="work_update.html?name=" + x; 
		},
		//x: 1正式  2更新  3通过  4未通过
		changeWork:function(x) {
			if(x == 1) {
				$("#but1").addClass("active");
				$("#but2").removeClass("active");
				$("#but3").removeClass("active");
				$("#but4").removeClass("active");
				Mywork.loading(0);
			} else {
				if(x == 2) {
					$("#but2").addClass("active");
					$("#but3").removeClass("active");
					$("#but1").removeClass("active");
					$("#but4").removeClass("active");
					Mywork.loadingWait(0, 0);
				} else {
					if(x == 3) {
						$("#but3").addClass("active");
						$("#but2").removeClass("active");
						$("#but1").removeClass("active");
						$("#but4").removeClass("active");
						Mywork.loadingWait(0, 1);
					} else {
						$("#but4").addClass("active");
						$("#but2").removeClass("active");
						$("#but1").removeClass("active");
						$("#but3").removeClass("active");
						Mywork.loadingWait(0, 2);
					}
					
				}
			}
		},
		//x:id   y:0更新，1新作品，3正式，2未通过     z:page
		dele:function(x, y, z) {   //0 update; 1 notpass; 3 pass
			bubble = 1;
			var con=confirm("是否确认删除该作品?"); 
			if(con==true) {
				$.ajax({
					type: "GET",
					url: "/software/ChangeServlet",
					data: {"type": "deleMywork", "status":y, "id":x},
					dataType: "json",
					success:function(data) {
						var item = eval(data);
						alert("删除成功");
						if(y == 3) {
							Mywork.loading(z);
						}
						Mywork.loadingWait(z, y);
					},
					error:function(json) {
						alert("删除失败，请刷新重试");
						if(y == 3) {
							Mywork.loading(z);
						}
						Mywork.loadingWait(z, y);
					}
				});
			} else {
				
			}
			if(y == 3) {
				Mywork.loading(z);
			} else {
				Mywork.loadingWait(y, z);
			}
			return false;
		}
	};
}();

var Mydown = function() {
	return {
		loading:function(x, type) {  //type  1 下载   2 收藏
			var flag = "down";
			if(type == 2) {
				flag = "love";
			}
			$.ajax({
				type: "POST",
				url: "/software/LoadServlet",
				data: {"page": "downOrlove", "type": flag, "num": x},
				dataType: "json",
				success:function(data){
					var item = eval(data);
					if(item.status == "false") {
						alert("用户已下线，请先登录");
					} else {
						var str = '<li><ul class="smallUl"><li>作品名</li><li>作者</li><li>分类</li><li>下载时间</li><li>操作</li></ul></li>';
						for(var i = 0; i < item.work.length; i++) {
							str += '<li><a href="show.html?name=' + item.work[i].name + '&user=' + item.work[i].user + '" onclick="if(bubble==1){ bubble=0; return false;}"><ul class="smallUl"><li>' + item.work[i].name + '</li><li>' + item.work[i].user + '</li>' +
									'<li>' + item.work[i].lable + '</li><li>' + item.work[i].time + '</li>' + 
									'<li>';
							if(type == 1 ) {
								str += '<span onclick="Mydown.postGrade(' + i + ',' + item.work[i].workId + ')">评分</span>';
							}
							str += '<span onclick="Mydown.postComment(\'' + item.work[i].name + '\', \'' + item.work[i].user + '\')">评论</span><span onclick="Mydown.deleWork(' + type + ', ' + item.work[i].id + ', ' + x + ')">删除</span></li></ul></a></li>';
							
							gradeItems[i] = item.work[i].grade;
						}
						document.getElementById('Ul').innerHTML = str;
						
						//页码加载
						x = x + 1;
						var sum = item.sum;
						str = '<ul>';
						if(sum%6 > 0) {
							sum = parseInt(sum/6) + 1;
						} else {
							sum = parseInt(sum/6);
						}
						var cnt = 4;
						if(x == 1) {	
							str += '<li class="noactive"><a>...</a></li>' + 
							       '<li class="noactive"><a>1</a></li>';
						} else {
							str += '<li><a href="javascript:void(0);" onclick="Mydown.loading(' + (x-2) + ', ' + type + ')">...</a></li>';
							var y = 2;
							if(sum-x < 2) {
								y = 4 - sum + x;
							}
							for(var i = x-y; i < x; i++) {
								if(i <= 0) {
									continue;
								}
								str += '<li><a href="javascript:void(0);" onclick="Mydown.loading(' + (i-1) + ', ' + type + ')">' + i + '</a></li>';
								cnt--;
							}
							str += '<li class="noactive"><a>' + x + '</a></li>';
						}
						for(var i = x; cnt > 0; i++) {
							if(i+1 <= sum) {
								str += '<li><a href="javascript:void(0);" onclick="Mydown.loading(' + i + ', ' + type + ')">' + (i+1) + '</a></li>';
								cnt--;
							} else {
								break;
							}
						}
						if(cnt == 0 && x+2 < sum) {
							str += '<li><a href="javascript:void(0);" onclick="Mydown.loading(' + (x) + ', ' + type + ')">...</a></li>';
						} else {
							str += '<li class="noactive"><a>...</a></li>';
						}
						str += '</ul>';
						document.getElementById('page').innerHTML = str;
					}
				},
				error:function(json) {
					
				}
			});
		},
		postGrade:function(i, x, y) {
			var area = document.getElementById('setgrade');
			area.style.display = "";
			document.getElementById('getgrade').innerHTML = gradeItems[i]+'.0';
			now = i;
			document.getElementById('workId').innerHTML = x;
			Mydown.halfStar(gradeItems[i]);
			bubble = 1;
		},
		halfStar: function(x) {
			var star = document.getElementById('star');
			var items = star.getElementsByTagName("li");
			x = parseInt(x) - 1;
			var tem = -1;
			for(var i = 0; i < items.length; i++) {
				if(x > i*2) {
					items[i].style.background = "url('../img/myself/full.png') no-repeat";
					items[i].style.backgroundSize = "100% 100%";
				} else {
					if(tem == -1) {
						tem = i;
					} 
					items[i].style.background = "url('../img/myself/empty.png') no-repeat";
					items[i].style.backgroundSize = "100% 100%";
				}
			}
			if(x == parseInt(tem)*2) {
				items[tem].style.background = "url('../img/myself/half.png') no-repeat";
				items[tem].style.backgroundSize = "100% 100%";
			}
			document.getElementById('getgrade').innerHTML = parseInt(x)+1+'.0';
		},
		cancelGrade:function () {
			var area = document.getElementById('setgrade');
			area.style.display = "none";
			now = 0;
		},
		sureGrade:function () {
			var score = document.getElementById('getgrade').innerHTML;
			score = parseInt(score);
			var workId = document.getElementById('workId').innerHTML;
			$.ajax({
				type: "POST",
				url: "/software/ChangeServlet",
				data: {"type": "grade", "grade": score, "work": workId},
				dataType: "json",
				success:function (data) {
					var item = eval(data);
					if(item.status == false) {
						alert("用户一下线，请重新登录");
					} else {
						alert("评分成功");
						gradeItems[now] = score;
					}
					Mydown.cancelGrade();
				},
				error:function (json) {
					
				}
			});
		},
		postComment:function(name, user) {
			window.location.href = "show.html?name=" + name + "&user=" + user + "#part3";
			bubble = 1;
		},
		deleWork:function(x, y, page) {  //x  type  y  id
			var con=confirm("是否确认删除记录?"); 
			if(con==true) {
				$.ajax({
					type: "POST",
					url: "/software/ChangeServlet",
					data: {"type": "deleRecord", "page": x, "id": y},
					dataType: "json",
					success:function(data) {
						var item = eval(data);
						if(item.status == "false") {
							alert("用户已下线，请重新登陆");
						} else {
							alert("删除成功");
							Mydown.loading(page, x);
						}
					},
					error:function(json) {
						
					}
				}); 
			}
			
			bubble = 1;
		}
	};
}();

var Mytalk = function() {
	return {
		loading:function(x) {
			$.ajax({
				type: "GET",
				url: "/software/LoadServlet",
				data: {"page": "Mytalk", "num": x},
				dataType: "json", 
				success:function(data) {
					var item = eval(data);
					if(item.status == "false") {
						alert("用户已下线，请先登录");
					} else {
						var str = '<li><ul class="smallUl"><li>标题</li><li>点击量</li><li>点评量</li><li>发表时间</li><li>操作</li></ul></li>';					
						for(var i = 0; i < item.talk.length; i++) {
							str += '<li><a href="./discuss.html?id=' + item.talk[i].id + '&page=0" onclick="if(bubble==1){ bubble=0; return false;}"><ul class="smallUl"><li>' + item.talk[i].title + '</li>' +
									'<li>' + item.talk[i].look + '</li><li>' + item.talk[i].reply + '</li>' +
									'<li>' + item.talk[i].time + '</li><li><span onclick="Mytalk.dele(' + item.talk[i].id + ', ' + x + ')">删除</span></li></ul></a></li>';
						}
						document.getElementById('Ul').innerHTML = str;
						
						//页码加载
						x = x + 1;
						var sum = item.sum;
						str = '<ul>';
						if(sum%6 > 0) {
							sum = parseInt(sum/6) + 1;
						} else {
							sum = parseInt(sum/6);
						}
						var cnt = 4;
						if(x == 1) {	
							str += '<li class="noactive"><a>...</a></li>' + 
							       '<li class="noactive"><a>1</a></li>';
						} else {
							str += '<li><a href="javascript:void(0);" onclick="Mytalk.loading(' + (x-2) + ')">...</a></li>';
							var y = 2;
							if(sum-x < 2) {
								y = 4 - sum + x;
							}
							for(var i = x-y; i < x; i++) {
								if(i <= 0) {
									continue;
								}
								str += '<li><a href="javascript:void(0);" onclick="Mytalk.loading(' + (i-1) + ')">' + i + '</a></li>';
								cnt--;
							}
							str += '<li class="noactive"><a>' + x + '</a></li>';
						}
						for(var i = x; cnt > 0; i++) {
							if(i+1 <= sum) {
								str += '<li><a href="javascript:void(0);" onclick="Mytalk.loading(' + i + ')">' + (i+1) + '</a></li>';
								cnt--;
							} else {
								break;
							}
						}
						if(cnt == 0 && x+2 < sum) {
							str += '<li><a href="javascript:void(0);" onclick="Mytalk.loading(' + (x) + ')">...</a></li>';
						} else {
							str += '<li class="noactive"><a>...</a></li>';
						}
						str += '</ul>';
						document.getElementById('page').innerHTML = str;
					}
					
				},
				error:function(json) {
					alert("请刷新重试");
				}
			});
		},
		dele:function(id, x) {
			var con=confirm("是否确认删除该作品?"); 
			if(con==true) {
				$.ajax({
					type: "GET",
					url: "/software/ChangeServlet",
					data: {"type": "deleMytalk", "id": id},
					dataType: "json",
					success:function(data) {
						var item = eval(data);
						if(item.status == "true") {
							alert("删除成功");
							Mytalk.loading(x);
						} else {
							alert("删除失败，请刷新重试");
						}
					},
					error:function(json) {
						alert("删除失败，请稍后再试");
					}
				});
			}
			bubble = 1;
		}
	};
}();