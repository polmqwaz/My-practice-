var pageType = 0, flag = 0;
function loadingTalk(y, x) {  //y 0当天  1所有
	for(var i = 0; i < 2; i++) {
		var area = 'bnt' + i;
		var item = document.getElementById(area);
		if(i == y) {
			item.style.backgroundColor = "rgb(110,155,194)";
			item.style.borderColor = "rgb(110,155,194)";
		} else {
			item.style.backgroundColor = "rgb(208,207,207)";
			item.style.borderColor = "rgb(208,207,207)";
		}
	}
	
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {"page": "adtalk", "type": y, "num": x},
		dataType: "json",
		success:function(data) {
			var item = eval(data);
			pageType = y;
			
			var str = '<tr><th class="col-md-1"><input type="checkbox" id="checkAllbox" onclick="check_all()"></th>' +
                      '<th class="col-md-5" style="text-align: center ">话题</th>' +
                      '<th class="col-md-1" style="text-align: center ">作者</th>' +
                      '<th class="col-md-2" style="text-align: center ">时间</th>' +
                      '<th class="col-md-1" style="text-align: center ">操作</th></tr>';
            
			for(var i = 0; i < item.talk.length; i++) {
				str += '<tr onclick="jump(' + item.talk[i].id + ')"><td class="col-md-1"><input type="checkbox" name="selectall" id="blankCheckbox" value="' + item.talk[i].id + '"></td>' +
						'<td class="col-md-5">' + item.talk[i].title + '<span></td>' +
						'<td class="col-md-1"  style="text-align: center ">' + item.talk[i].user + '</td>' +
						'<td class="col-md-2" style="text-align: center ">' + item.talk[i].time + '</td>' +
						'<td class="col-md-1 do_something" style="text-align: center;"><span class="glyphicon glyphicon-remove" aria-hidden="true" onclick="dele_talk(' + item.talk[i].id + ', ' + x + ')"></span></td></tr>';
			}
			document.getElementById('Table').innerHTML = str;
			
//        	页码计算
        	var beginstr, endstr;
        	var num = item.sum;
        	var start = x;
        	if(start == 0) {
        		beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
      	      		       "<li class=\"active\"><span>1 <span class=\"sr-only\">(current)</span></span></li>";  
        		if(num > 30) {
        			endstr = "<li><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        		} else {
        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>"
        		}
        	} else {
        		if(num > 30) {
        			if(start >= 18) {
        				beginstr = "<li><span><span aria-hidden=\"true\">&laquo;</span></span></li>";
        				if((start + 18) < num) {
        					endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        				} else {
        					endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        				}
        			} else {
        				beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
  	                               "<li><a onclick=\"loadingTalk(" + y + ", 0)\" style=\"color:grey;cursor:pointer;\">1</a></li>";
        				endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        			}
        		} else {
        			beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
                               "<li><a onclick=\"loadingTalk(" + y + ", 0)\" style=\"color:grey;\">1</a></li>";
        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        		}
        	}
        	
        	var nowpage = (start + 6) / 6;
        	
        	if(nowpage <= 3) {
        		for(var r = 2; r <= 5; r++) {
        			from = (r-1) * 6;
        			if(from >= num) {
        				break;
        			}
        			if(r == nowpage) {
        				beginstr += "<li class=\"active\"><span>" + r + " <span class=\"sr-only\">(current)</span></span></li>";
        			} else {
        				beginstr += "<li><a onclick=\"loadingTalk(" + y + ", " + from + ")\" style=\"color:grey; cursor:pointer;\">" + r + "</a></li>";
        			}
        		}
        		beginstr += endstr;
        	}else {
        		for(var r = 1; r < 3; r++) {
        			from = start - r * 6;
        			beginstr += "<li><a onclick=\"loadingTalk(" + y + ", " + from + ")\" style=\"color:grey;cursor:pointer;\">" + (nowpage-r) + "</a></li>";
        		}
        		beginstr += "<li class=\"active\"><span>" + nowpage + " <span class=\"sr-only\">(current)</span></span></li>";
        		for(var r = 0; r < 2; r++) {
        			from = end + r * 6;
        			if(from < num) {
        				beginstr += "<li><a onclick=\"loadingTalk(" + y + ", " + from + ")\" style=\"color:grey;cursor:pointer;\">" + (nowpage + r + 1) + "</a></li>";
        			}        			
        		}
        		beginstr += endstr;
        	}
        	document.getElementById('pageUl').innerHTML = beginstr;
        	
        	var select_all = document.getElementById('checkAllbox');
        	var check_box = document.getElementsByName('selectall');
        	for (var i = check_box.length - 1; i >= 0; i--) {
        		check_box[i].onclick = function() {
        			flag = 1;
        			select_all.checked = false;
        		};
        	};
		},
		error:function(json) {
			
		}
	});
}

function dele_talk(id, num) {
	flag = 1;
	var r = confirm("是否删除该话题");
	if(r == true) {
		$.ajax({
			type: "GET",
			url: "/software/ChangeServlet",
			data: {"type": "deletalk", "id": id},
			dataType: "json",
			success: function(data) {
				var item = eval(data);
				alert("删除成功");
				loadingWait(pageType, num);
			},
			error: function(json) {
				
			}
		});
	}
}

function check_all() {
	var check_box = document.getElementsByName('selectall');
	var select_all = document.getElementById('checkAllbox');
	
	if(select_all.checked == true)
	{
		for (var i = check_box.length - 1; i >= 0; i--) {
			check_box[i].checked = true;
		}
	}else {
		for (var i = check_box.length - 1; i >= 0; i--) {
			check_box[i].checked = false;
		}
	}
}

function jump(id) {
	if(flag == 1) {
		flag = 0;
		return false;
	}
	
	window.location.href = "./discuss.html?id=" + id + "&page=0";
}

function deleSome() {
	var check_box = document.getElementsByName('selectall');
	var select_all = document.getElementById('checkAllbox');
	var num = new Array();
	for (var i = check_box.length - 1; i >= 0; i--) {
		if(check_box[i].checked == true) {
			num.push(check_box[i].value);
		}
	}
	var sum = num.length;
	
	$.ajax({
		type: "POST",
		traditional: true,
		url: "/software/ChangeServlet",
		data: {"type": "delesometalk", "num": num},
		dataType: "json",
		success:function(data) {
			alert("已删除" + sum + "条记录");
			loadingTalk(pageType, 0);
		},
		error:function(json) {
			alert("请刷新重试");
		}
	});
}