var start = 0, flag = 0, status = 1;
function loadingWait(x, num1, num2) {
	status = x;
	for(var i = 1; i <= 4; i++) {
		var area = 'select-btn' + i;
		var item = document.getElementById(area);
		if(i == x) {
			item.style.backgroundColor = "rgb(110,155,194)";
			item.style.borderColor = "rgb(110,155,194)";
		} else {
			item.style.backgroundColor = "rgb(208,207,207)";
			item.style.borderColor = "rgb(208,207,207)";
		}
	}
	var fa = document.getElementById('loadTable');
	start = num1;
	var end = num2;
	
	$.ajax({
		type: "GET",  
        url: "/software/WorkOperationServlet",
        data: {'type': 'adwork', 'page': x, 'start': start, 'end': end},  
        dataType:"json", 
        success: function(data) {
        	var item = eval(data);
        	
        	var tem = '操作';
        	if(x == 4) {
        		tem = '状态';
        	}
        	var str = "<tr><th class=\"col-md-1\"><input type=\"checkbox\" id=\"checkAllbox\" aria-label=\"...\" onclick=\"check_all()\"></th>" +
        	          "<th class=\"col-md-4\" style=\"text-align: center;cursor: pointer; \">作品</th>" +
        	          "<th class=\"col-md-4\" style=\"text-align: center;cursor: pointer; \">时间</th>" +
        	          "<th class=\"col-md-2\" style=\"text-align: center;cursor: pointer; \">" + tem + "</th></tr>";
        	
        	for(var i = 0; i < item.work.length; i++) {
        		
        		str += "<tr onclick=\"showWork(" + item.work[i].id + ", " + x + ")\"><td class=\"col-md-1\"><input type=\"checkbox\" name=\"selectall\" id=\"blankCheckbox\" value=\"" + item.work[i].id + "\"></td>";
        		str += "<td class=\"col-md-4\" style=\"text-align: center;cursor: pointer; \">" + item.work[i].name + "</td>";
        		str += "<td class=\"col-md-4\" style=\"text-align: center;cursor: pointer; \">" + item.work[i].time + "</td>";
        		
        		var op1 = "<td class=\"col-md-2 do_something\" style=\"text-align: center;cursor: pointer;\"><span onclick=\"allow_work(" + item.work[i].id + ", '" + item.work[i].addr + "', " + start + ", " + x + ")\">审核</span></td></tr>";
            	var op2 = "<td class=\"col-md-2 do_something\" style=\"text-align: center;cursor: pointer;\"><span onclick=\"dele_work(" + item.work[i].id + ", '" + item.work[i].addr + "', " + start + ")\">删除</span></td></tr>";
            	var op3 = "<td class=\"col-md-2 do_something\" style=\"text-align: center;cursor: pointer;\"><span style=\" color:red; \">" + "未通过" + "</span></td></tr>";
        		if(x == 1 || x == 3) {
        			str += op1;
        		} else {
        			if(x == 2) {
        				str += op2;
        			} else {
        				str += op3;
        			}
        		}
        	}
        	fa.innerHTML = str;
        	
//        	页码计算
        	var beginstr, endstr;
        	var num = item.page[0].num;
        	
        	if(start == 0) {
        		beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
      	      		       "<li class=\"active\"><span>1 <span class=\"sr-only\">(current)</span></span></li>";  
        		if(num > 40) {
        			endstr = "<li><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        		} else {
        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>"
        		}
        	} else {
        		if(num > 40) {
        			if(start >= 24) {
        				beginstr = "<li><span><span aria-hidden=\"true\">&laquo;</span></span></li>";
        				if((start + 24) < num) {
        					endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        				} else {
        					endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        				}
        			} else {
        				beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
  	                               "<li><a onclick=\"loadingWait(" + x + ", 0, 8)\" style=\"color:grey;cursor:pointer;\">1</a></li>";
        				endstr = "<li><a href=\"#\" style=\"color:grey;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        			}
        		} else {
        			beginstr = "<li class=\"disabled\"><span><span aria-hidden=\"true\">&laquo;</span></span></li>" +
                               "<li><a onclick=\"loadingWait(" + x + ", 0, 8)\" style=\"color:grey;\">1</a></li>";
        			endstr = "<li class=\"disabled\"><a href=\"#\" style=\"color:grey;cursor:pointer;\" aria-label=\"Next\"><span aria-hidden=\"true\">&raquo;</span></a></li>";
        		}
        	}
        	
        	var nowpage = (start + 8) / 8;
        	
        	if(nowpage <= 3) {
        		for(var r = 2; r <= 5; r++) {
        			from = (r-1) * 8;
        			if(from >= num) {
        				break;
        			}
        			if(r == nowpage) {
        				beginstr += "<li class=\"active\"><span>" + r + " <span class=\"sr-only\">(current)</span></span></li>";
        			} else {
        				beginstr += "<li><a onclick=\"loadingWait(" + x + ", " + from + ", 8)\" style=\"color:grey; cursor:pointer;\">" + r + "</a></li>";
        			}
        		}
        		beginstr += endstr;
        	}else {
        		for(var r = 1; r < 3; r++) {
        			from = start - r * 8;
        			beginstr += "<li><a onclick=\"loadingWait(" + x + ", " + from + ", 8)\" style=\"color:grey;cursor:pointer;\">" + (nowpage-r) + "</a></li>";
        		}
        		beginstr += "<li class=\"active\"><span>" + nowpage + " <span class=\"sr-only\">(current)</span></span></li>";
        		for(var r = 0; r < 2; r++) {
        			from = end + r * 8;
        			if(from < num) {
        				beginstr += "<li><a onclick=\"loadingWait(" + x + ", " + from + ", 8)\" style=\"color:grey;cursor:pointer;\">" + (nowpage + r + 1) + "</a></li>";
        			}        			
        		}
        		beginstr += endstr;
        	}
        	document.getElementById('pageUl').innerHTML = beginstr;
        	
        	var select_all = document.getElementById('checkAllbox');
        	var check_box = document.getElementsByName('selectall');
        	for (var i = check_box.length - 1; i >= 0; i--) {
        		check_box[i].onclick = function() {
        			flag = 1;
        			select_all.checked = false;
        		};
        	};
        },
        error: function(json) {

        }
	});
}

function showWork(id, type) {
	if(flag == 1) {
		flag = 0;
		return false;
	}
	
	if(type == 4) {
		return false;
	}
	
	$.ajax({
		type: "POST",
		url: "/software/WorkOperationServlet",
		data: {"type": "show", "id": id, "status": type},
		dataType: "json",
		success:function(data) {
			var item = eval(data);
			var str = "";
			var btn = "";
			$('#myModalLabel').text(item.name);
			$('#myModal').modal('show');
			if(type == 1) {
				str = '<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">作者：</div><div class="col-md-7 work-show-value">' + item.user + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">操作系统：</div><div class="col-md-7 work-show-value">' + item.os + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">标签：</div><div class="col-md-7 work-show-value">' + item.lable + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">关键字：</div><div class="col-md-7 work-show-text">' + item.keyword + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">描述：</div><div class="col-md-7 work-show-text" id="describe">' + item.des + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">上传作品：</div><div class="col-md-7 work-show-name"><a id="downbut" target="_blank" href="/software/DownLoadServlet?filename=' + item.addr + '&type=1"><button class="btn btn-default" type="submit" style="float: left;">下载</button></a></div></div>';
				
				btn = '<button type="button" class="btn btn-default" data-dismiss="modal" onclick="audit_false(' + id + ', \'' + item.addr + '\', ' + start + ', 1)">否决</button>' + 
						'<button type="button" class="btn btn-primary" onclick="audit_true(' + id + ', \'' + item.addr + '\', 1, ' + start + ')">通过</button>';
				
			}
			if(type == 2) {
				var tag = '';
				for(var i = 0; i < item.keyword.length; i++) {
					tag += '<span>' + item.keyword[i].value + '</span>';
				}
				str = '<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">作者：</div><div class="col-md-7 work-show-value">' + item.user + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">操作系统：</div><div class="col-md-7 work-show-value">' + item.os + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">标签：</div><div class="col-md-7 work-show-value">' + item.lable + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">关键字：</div><div class="col-md-7 work-show-text">' + tag + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">描述：</div><div class="col-md-7 work-show-text" id="describe">' + item.des + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">上传作品：</div><div class="col-md-7 work-show-name"><a id="downbut" target="_blank" href="/software/DownLoadServlet?filename=' + item.addr + '&type=2"><button class="btn btn-default" type="submit" style="float: left;">下载</button></a></div></div>';
				
				btn = "<button type=\"button\" class=\"btn btn-primary\" onclick=\"dele_work(" + item.id + ", '" + item.addr + "', " + start + ")\">删除</button>";
				
			}
			if(type == 3) {
				str = '<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">作者：</div><div class="col-md-7 work-show-value">' + item.user + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">操作系统：</div><div class="col-md-7 work-show-value">' + item.os + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">标签：</div><div class="col-md-7 work-show-value">' + item.lable + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">描述：</div><div class="col-md-7 work-show-text" id="describe">' + item.des + '</div></div>' +
				'<div class="row"><div class="col-md-offset-1 col-md-3 work-show-name">上传作品：</div><div class="col-md-7 work-show-name"><a id="downbut" target="_blank" href="/software/DownLoadServlet?filename=' + item.addr + '&type=1"><button class="btn btn-default" type="submit" style="float: left;">下载</button></a></div></div>';
				
				btn = '<button type="button" class="btn btn-default" data-dismiss="modal" onclick="audit_false(' + id + ', \'' + item.addr + '\', ' + start + ', 3)">否决</button>' + 
						'<button type="button" class="btn btn-primary" onclick="audit_true(' + id + ', \'' + item.addr + '\', 3, ' + start + ')">通过</button>';
				
			}
			$('#modal-body').html(str);
			$('#modal-btn').html(btn);
		},
		error:function(json) {
			
		}
	});
	
}

function audit_true(id, addr, type, num1) {
	flag = 1;
	
	$.ajax({
		type: "POST",
		url: "/software/WorkOperationServlet",
		data: {"type": "allow", "id": id, "addr": addr, "status": type},
		dataType: "json",
		success: function(data) {
			var item = eval(data);
			$('#myModal').modal('hide');
			if(item.ans) {
				alert("该作品已审核通过，可在已通过作品列表中查找");
				loadingWait(type, num1, 8);
			}else {
				alert("审核操作出现故障，请稍后再试");
			}
		},
		error: function(json) {
		}
	});
	
}

function audit_false(id, addr, num1, type) {
	flag = 1;
	
	$.ajax({
		type: "GET",
		url: "/software/WorkOperationServlet",
		data: {"type": "allowDele", "id": id, "addr": addr, "status": type},
		dataType: "json",
		success: function(data) {
			var item = eval(data);
			alert("该作品已审批为不合格作品");
			loadingWait(type, num1, 8);
		},
		error: function(json) {
			
		}
	});
}

function allow_work(id, addr, num1, type)
{
	var r=confirm("是否通过该作品");
	if (r==true) {
		audit_true(id, addr, type, num1);
	} else {
	}
}

function dele_work(id, addr, num1) {
	var r = confirm("是否删除该作品");
	if(r == true) {
		$.ajax({
			type: "GET",
			url: "/software/WorkOperationServlet",
			data: {"type": "haveDele", "id": id, "addr": addr},
			dataType: "json",
			success: function(data) {
				var item = eval(data);
				alert("删除成功");
				loadingWait(2, num1, 8);
			},
			error: function(json) {
				
			}
		});
	}
}

function check_all() {
	var check_box = document.getElementsByName('selectall');
	var select_all = document.getElementById('checkAllbox');
	
	if(select_all.checked == true)
	{
		for (var i = check_box.length - 1; i >= 0; i--) {
			check_box[i].checked = true;
		}
	}else {
		for (var i = check_box.length - 1; i >= 0; i--) {
			check_box[i].checked = false;
		}
	}
}

function deleSome() {
	var check_box = document.getElementsByName('selectall');
	var select_all = document.getElementById('checkAllbox');
	var num = new Array();
	for (var i = check_box.length - 1; i >= 0; i--) {
		if(check_box[i].checked == true) {
			num.push(check_box[i].value);
		}
	}
	var sum = num.length;
	
	$.ajax({
		type: "POST",
		traditional: true,
		url: "/software/WorkOperationServlet",
		data: {"type": "delesome", "num": num, "status": status},
		dataType: "json",
		success:function(data) {
			alert("已删除" + sum + "条记录");
			loadingWait(status, 0, 8);
		},
		error:function(json) {
			alert("请刷新重试");
		}
	});
}