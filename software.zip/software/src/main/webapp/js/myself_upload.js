var tag = [];
var num = 0;

function loadingBTag() {
	$.ajax({
		type: "GET",
		url: "/software/LoadServlet",
		data: {"page": "upload"},
		dataType: "json",
		success: function(data) {
			var item = eval(data);
			var num = item.tag;
			
			var str = "";
			for(var i = 0; i < num; i++) {
				str += "<option value =\"" + item.Tag[i].value + "\">" + item.Tag[i].tag + "</option>";
			}
			document.getElementById("Blable").innerHTML = str;
			loadingTag();
		},
		error: function(json) {
			
		}
	});
}

function loadingTag(){
	x = document.getElementsByName('Blable')[0].value;
	$.ajax({
		type: "GET",
		url: "/software/SingelServlet",
		data: {"type": "upload", "id": x},
		dataType: "json",
		success: function(data) {
			var item = eval(data);
			var num = item.tag;
			
			var str = "";
			for(var i = 0; i < num; i++) {
				str += "<option value =\"" + item.Tag[i].value + "\">" + item.Tag[i].tag + "</option>";
			}
			document.getElementById("lable").innerHTML = str;
		},
		error: function(json) {
			
		}
	});
}

function mytag() {
	document.getElementById('mytag').style.display = "";

	for(var i = 0; i < num; i++)
	{
		if(tag[i] == -1) {
			continue;
		}
		var delefor = document.getElementById('addtag');
		// delefor.innerHTML += '<div class="tag" id="tag' + i + '"><span class="glyphicon glyphicon-remove dele" onclick="smalldele('+ i +')"></span><span>&nbsp;' + tag[i] + '</span></div>';
	}
}

function addTag() {
	var newlable = prompt("请输入自定义标签","");

	if(newlable)
	{
		tag[num] = newlable;
		var delefor = document.getElementById('addtag');
		delefor.innerHTML += '<div class="tag" id="tag' + num + '"><span class="glyphicon glyphicon-remove dele" onclick="smalldele('+ num +')"></span><span>&nbsp;' + newlable + '&nbsp;</span></div>';
		num++;
	}
}

function smalldele(x) {
	tag[x] = -1;
	var str = "tag" + x;
	document.getElementById(str).style.display = "none";
}

function cancelTag() {
	document.getElementById('mytag').style.display = "none";
}

function sureTag() {
	var str = "";
	for(var i = 0; i < num; i++)
	{
		if(tag[i] == -1) {
			continue;
		}
		str += tag[i] + " ";
	}
	document.getElementById('finaltag').value = str;
	document.getElementById('mytag').style.display = "none";
}

//图文说明
var size = []; //图片大小
var exp = []; //解说
var count = 0, tempic = -1, temexp = -1, now = -1; //count为总数量，tempic为此时所需图片的pic，temexp为tempic所对应的解说，now为tempic的count值。
//点击input框，跳出list
function jumpListBox() {
	document.getElementById('jumpex').style.display = "";
}
//点击list中的“+”，跳出添加框
function jumpExBox() {
	now = count;
	var usualhtml = '<span class="glyphicon glyphicon-ok ok" aria-hidden="true" onclick="sureExplain()"></span><span class="glyphicon glyphicon-remove move" aria-hidden="true" onclick="closeExplain()"></span>' +
				'<div class="pictitle"><div class="inputword">图解标题：</div><input type="text" id="title' + now + '" name="title' + now + '"></div>' +
				'<div class="selectpic"><div class="inputword">图片上传：</div><input type="file" id="file'+ now +'" name="pic'+ now +'" onchange="showPic('+ now +')" required="required"></div>' +
				'<div class="changesize"><p>长宽比</p><a onclick="changewidth(70)">1:2</a><a onclick="changewidth(140)">2:2</a><a onclick="changewidth(280)">4:2</a><input name="picsize'+ now +'" id="picsize' + now + '" style="display:none;"></div>' +
				'<div class="picshow" id="picshow'+ now +'"><img src="../img/myself/wait.png" id="show'+ now +'"></div>' +
				'<div class="writeexplain"><div class="inputword">图片解说：</div><textarea name="picdes'+ now +'" id="picexp'+ now +'" onfocus="if(value==\'此处应写图片的说明，限200字\'){value=\'\'}" onblur="if (value ==\'\'){value=\'此处应写图片的说明，限200字\'}">此处应写图片的说明，限200字</textarea></div>';
	var div = document.createElement('div');
	div.setAttribute("class", "myexplain");
	div.setAttribute("id", "myexplain");
	document.getElementById('hiddenpic').appendChild(div);
	document.getElementById('myexplain').innerHTML = usualhtml;
	document.getElementById('jumpex').style.display = "none";
	changewidth(140);
	size[now] = 1;
}
//添加框中图片大小选择（长方形 or 正方形）
function changewidth(x) {
	var str = 'picshow' + now;
	var pic = document.getElementById(str);
	pic.style.width = x + "px";
	if(x == 70) {
		size[now] = 1;
	} else {
		if(x == 140) {
			size[now] = 2;
		} else {
			size[now] = 3;
		}
		
	}
	str = 'picsize' + now;
	document.getElementById(str).value = size[now];
}
//选择图片后图片预览
function showPic(x) {
	var pic = new FileReader();
	var str = 'file' + x;
	var file = document.getElementById(str).files[0];
	pic.readAsDataURL(file);
	pic.onload = function(e) {
		tempic = this.result;
		str = 'show' + x;
		document.getElementById(str).src = this.result;
	};
}
//上传或确认修改
function sureExplain() {
	if(tempic == -1) {
		alert("需选择图片");
		return ;
	}
	var rightId = "myexplain" + now;
	if(now == count) {
		var rightnow = document.getElementById('myexplain');
		rightnow.id = rightId;
		count++;
	}
	var str = 'picexp' + now;
	exp[now] = document.getElementById(str).value;
	now = -1;
	str = "<ul>";
	for(var i = 0; i < count; i++) {
		if(size[i] == -1) {
			continue;
		}
		str += '<li id="pic'+ i +'"  onclick="lookPic('+ i +')"><span class="glyphicon glyphicon-remove delepic" aria-hidden="true" onclick="delePicList(' + i + ')"></span>pic'+ i +'</li>';
	}
	str += '<li><span class="glyphicon glyphicon-plus addlist" aria-hidden="true" onclick="jumpExBox()" ></span></li>';
	str += '</ul>';
	str += '<button onclick="sureList()">确定</button>';
	
	document.getElementById('piclist').innerHTML = str;
	document.getElementById('jumpex').style.display = "";
	document.getElementById(rightId).style.display = "none";
}
//取消输入框
function closeExplain() {
	if(now == count)
	{
		var fa = document.getElementById('hiddenpic');
		var ch = document.getElementById('myexplain');
		fa.removeChild(ch);
	} else {
		var str = 'myexplain' + now;
		document.getElementById(str).style.display = "none";
	}
	size[count] = -1;
	now = -1;
	document.getElementById('jumpex').style.display = "";
}
//删除已在list中的pic
var flag = -1;
function delePicList(x) {
	flag = 1;
	var str = 'myexplain' + x;
	size[x] = -1;
	var fa = document.getElementById('hiddenpic');
	var ch = document.getElementById(str);
	fa.removeChild(ch);
	str = 'pic' + x;
	document.getElementById(str).style.display = "none";
	event.cancelBubble = true;
}
//查看已在list中的pic
function lookPic(x) {
	if(flag == 1) {
		flag = -1;
		event.cancelBubble = true;
	}
	now = x;
	var str = 'picexp' + now;
	document.getElementById(str).value = exp[now];
	str = "myexplain" + x;
	document.getElementById(str).style.display = "";
	document.getElementById('jumpex').style.display = "none";
}
//确认list，所有有效pic将写入input
function sureList() {
	document.getElementById('jumpex').style.display = "none";
	var str = "";
	for(var i = 0; i < count; i++) {
		if(size[i] == -1) {
			continue;
		}
		var tem = 'picexp' + i;
		document.getElementById(tem).value = exp[i];
		str += "pic" + i + " ";
	}
	document.getElementById('finallist').value = str;
}

//确认上传图片的后缀
function checkFileExt(filename)
{
	var flag = false; 
	var arr = ["jpg", "png", "gif", "PNG"];
	var index = filename.lastIndexOf(".");
	var ext = filename.substr(index+1);

	for(var i=0;i<arr.length;i++){
		if(ext == arr[i]){
			flag = true; 
			break;
		}
	}
	
	if(!flag){
		alert("图片类型不合法");
		var file = document.getElementById('workpic');
		if (file.outerHTML) {
            file.outerHTML = file.outerHTML;
        } else { 
            file.value = "";
        }
	}
}
//确认上传资源的后缀
function checkWorkExt(filename)
{
	var flag = false; 
	var arr = ["rar", "zip", "arj", "z"];
	var index = filename.lastIndexOf(".");
	var ext = filename.substr(index+1);

	for(var i=0;i<arr.length;i++){
		if(ext == arr[i]){
			flag = true; 
			break;
		}
	}
	
	if(!flag){
		alert("资源类型不合法");
		var file = document.getElementById('uploadwork');
		if (file.outerHTML) {
            file.outerHTML = file.outerHTML;
        } else { 
            file.value = "";
        }
	}
}