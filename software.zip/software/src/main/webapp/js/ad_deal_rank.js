var num = new Array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
function loading() {
	$.ajax({
		type: "GET",
		url: "/software/WorkOperationServlet",
		data: {"type": "rank"},
		dateType: "json",
		success: function(data) {
			var item = eval(data);
			
			var str = '<tr><th class="col-md-1 span-center">名次</th><th class="col-md-4 span-center">作品</th><th class="col-md-4 span-center">操作</th></tr>';
			for(var i = 0; i < item.work.length; i++) {
				num[i] = item.work[i].id;
				str += '<tr><td class="col-md-1 span-center" >' + (i+1) + '</td>'
						+ '<td class="col-md-4 span-center" id="value' + i + '">' + item.work[i].name + '</td>' 
						+ '<td class="col-md-4 span-center do_some" style="padding: 8px;" id="item' + i + '"><span class="glyphicon glyphicon-pencil" aria-hidden="true" onclick="changeInput(' + i + ')"></span></td></tr>';
			}
			document.getElementById('Ul').innerHTML = str;
		},
		error: function(json) {
			
		}
	});
}

function changeInput(x) {
	var str = 'item' + x;
	var area = document.getElementById(str);
	area.style.padding = "4px";
	area.innerHTML = '<input type="text" id="work' + x + '" placeholder="作品名" onkeydown="if(event.keyCode==13) {document.getElementById(\'user' + x + '\').focus();}"><input type="text" id="user' + x + '"  placeholder="上传用户" onkeydown="if(event.keyCode==13) {search(' + x + ')}">';
	str = 'work' + x;
	document.getElementById(str).focus();
}
function search(x) {
	var str = 'work' + x;
	var area = document.getElementById(str);
	var ans = area.value;
	var str2 = 'user' + x;
	var area2 = document.getElementById(str2);
	var ans2 = area2.value;
	$.ajax({
		type: "POST",
		url: "/software/WorkOperationServlet",
		data: {"type": "find", "name": ans, "user": ans2, "num": x},
		dataType: "json",
		success: function(data) {
			var item = eval(data);
			if(item.id == 0) {
				alert('作品不存在');
				return false;
			}
			num[x] = item.id;
			str = 'item' + x;
			area = document.getElementById(str);
			area.style.padding = '8px';
			area.innerHTML = '<span class="glyphicon glyphicon-pencil" aria-hidden="true" onclick="changeInput(' + x + ')"></span>';
			str = 'value' + x;
			area = document.getElementById(str);
			area.innerHTML = item.name;
		}, 
		error: function(json) {
			
		}
	});
}
function saveRank() {
	for(var i = 0; i < 10; i++){
		for(var j = i+1; j < 10; j++) {
			if(num[i] == num[j]) {
				alert('榜上有重复作品，请更改');
				return false;
			}
		}
	}
	
	$.ajax({
		type: "POST",
		traditional: true,
		url: "/software/WorkOperationServlet",
		data: {"type": "updateRank", "num": num},
		dataType: "json",
		success:function(data) {
			alert('更新成功');
		},
		error:function(json) {
			alert("请刷新重试");
		}
	});
}